<?php

namespace AxeptaBnpparibas\Online\Ui\Component\Listing\Column;

use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Sales\Model\Order;
use Magento\Ui\Component\Listing\Columns\Column;

class TransactionOrderActions extends Column
{
    protected $order;
    protected $product;
    private $urlBuilder;

    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        Order $order,
        array $components = [],
        array $data = [],
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->urlBuilder = $urlBuilder;
        $this->order = $order;
    }

    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $name = $this->getData('name');
                if (isset($item['order_id'])) {
                    $this->order->load($item['order_id']);
                    $item[$name] = html_entity_decode('<a target="_blank" href="' . $this->urlBuilder->getUrl('sales/order/view', ['order_id' => $this->order->getEntityId()]) . '"> ' . $this->order->getIncrementId() . '</a>');
                }
            }
        }

        return $dataSource;
    }
}
