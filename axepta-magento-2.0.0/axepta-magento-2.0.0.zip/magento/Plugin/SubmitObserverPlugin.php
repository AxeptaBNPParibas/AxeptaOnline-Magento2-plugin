<?php

namespace AxeptaBnpparibas\Online\Plugin;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Quote\Observer\SubmitObserver;

class SubmitObserverPlugin
{
    public function beforeExecute(SubmitObserver $subject, EventObserver $observer)
    {
        $quote = $observer->getEvent()->getQuote();
        $order = $observer->getEvent()->getOrder();
        if ($quote->getPayment()->getMethod() === 'axepta_online') {
            $order->setCanSendNewEmailFlag(false);
        }
    }
}
