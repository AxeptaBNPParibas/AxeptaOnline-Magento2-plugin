<?php

namespace AxeptaBnpparibas\Online\Plugin;

use Magento\Framework\App\Request\Http;
use Magento\Framework\Session\SessionStartChecker;

class CallbackSessionChecker
{
    /**
     * Array.
     */
    private const PAYMENT_CALLBACK_PATHS = [
        'axepta_online/payment/ipn',
        'axepta_online/payment/success',
        'axepta_online/payment/failure',
        'axepta_online/payment/redirect',
    ];

    /**
     * @var Http
     */
    private $request;

    public function __construct(Http $request)
    {
        $this->request = $request;
    }

    /**
     * Check if session can be started or not.
     */
    public function afterCheck(SessionStartChecker $subject, bool $result): bool
    {
        if ($result === false) {
            return false;
        }

        $inArray = true;
        foreach (self::PAYMENT_CALLBACK_PATHS as $path) {
            if (strpos((string) $this->request->getPathInfo(), $path) !== false) {
                $inArray = false;
                break;
            }
        }

        return $inArray;
    }
}
