<?php

namespace AxeptaBnpparibas\Online\Cron;

use Magento\Backend\Model\Url;
use Magento\Framework\Notification\NotifierInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Psr\Log\LoggerInterface;

class CaptureAlert
{
    protected $loggerAxepta;
    protected $orderCollectionFactory;
    protected $notifierPool;
    protected $backendUrlManager;

    public function __construct(
        LoggerInterface $loggerAxepta,
        CollectionFactory $orderCollectionFactory,
        NotifierInterface $notifierPool,
        Url $backendUrlManager,
    ) {
        $this->loggerAxepta = $loggerAxepta;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->notifierPool = $notifierPool;
        $this->backendUrlManager = $backendUrlManager;
    }

    public function execute()
    {
        $this->loggerAxepta->info('=========== CRON CAPTURE ALERT START ===========');

        $orders = $this->getOrderCollection();

        foreach ($orders as $order) {
            if ($order->hasInvoices()) {
                continue;
            }

            $paymentInformations = $order->getPayment()->getAdditionalInformation();
            if (array_key_exists('captureMode', $paymentInformations)) {
                if ($paymentInformations['captureMode'] === 'manual') {
                    $this->addNotification($order);
                    $this->loggerAxepta->info('Notification envoyée pour la commande #' . $order->getIncrementId());
                }
            }
        }

        $this->loggerAxepta->info('=========== CRON CAPTURE ALERT END ===========');
    }

    public function getOrderCollection()
    {
        date_default_timezone_set('Europe/Paris');
        $date_now = date('Y-m-d');
        $from = strtotime('-7 day', strtotime($date_now));
        $from = date('Y-m-d', $from); // 7 days before

        $collection = $this->orderCollectionFactory->create()
            ->addAttributeToSelect('*')
            ->addFieldToFilter('created_at', ['from' => $from . ' 00:00:00', 'to' => $from . ' 23:59:59']);

        return $collection;
    }

    public function addNotification($order)
    {
        $notificationUrl = $this->backendUrlManager->getUrl('sales/order/view', ['order_id' => $order->getId()]);
        $orderIncrmentId = $order->getIncrementId();

        $this->notifierPool->addCritical(
            'Axepta BNP Paribas order to capture',
            'Order #' . $orderIncrmentId . ' has not been captured by Axepta for 7 days. As a reminder, if this one is not captured before 14 days the capture can no longer be done.',
            $notificationUrl
        );
    }
}
