<?php

namespace AxeptaBnpparibas\Online\Cron;

use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Psr\Log\LoggerInterface;

class CancelPendingOrder
{
    protected $loggerAxepta;
    protected $orderCollectionFactory;
    protected $orderRepository;

    public function __construct(
        LoggerInterface $loggerAxepta,
        CollectionFactory $orderCollectionFactory,
        OrderRepositoryInterface $orderRepository,
    ) {
        $this->loggerAxepta = $loggerAxepta;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->orderRepository = $orderRepository;
    }

    public function execute()
    {
        $this->loggerAxepta->info('=========== CRON CANCEL PENDING ORDER START ===========');

        $orders = $this->getPendingAxeptaOrderCollection();

        foreach ($orders as $order) {
            var_dump($order->getId());
            $order = $this->orderRepository->get($order->getId());
            $order->addStatusToHistory(
                $order->getStatus(),
                // keep order status/state cancel
                __('Order automatically cancelled')
            )->cancel()->save();
        }

        $this->loggerAxepta->info('=========== CRON CANCEL PENDING ORDER END ===========');
    }

    public function getPendingAxeptaOrderCollection()
    {
        $date_now = date('Y-m-d H:i:s');
        $to = strtotime('-24 hour', strtotime($date_now));
        $to = date('Y-m-d H:i:s', $to);

        $collection = $this->orderCollectionFactory->create()
            ->addAttributeToSelect('*')
            ->addFieldToFilter('created_at', ['from' => '2000-01-01 00:00:00', 'to' => $to])
            ->addFieldToFilter('status', ['eq' => 'pending'])
            ->addFieldToFilter('state', ['eq' => 'new']);

        $collection->getSelect()
            ->join(
                ['sop' => 'sales_order_payment'],
                'main_table.entity_id = sop.parent_id',
                ['method']
            )
            ->where('sop.method = ?', 'axepta');

        return $collection;
    }
}
