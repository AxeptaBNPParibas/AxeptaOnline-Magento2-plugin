<?php

namespace AxeptaBnpparibas\Online\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use AxeptaBnpparibas\Online\Model\TransactionFactory;
use AxeptaBnpparibas\Online\Model\Api\Service;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Message\ManagerInterface;

class OrderCancel implements ObserverInterface
{
    protected $logger;
    protected $service;
    protected $scopeConfig;
    protected $transactionFactory;
    protected $messageManager;

    public function __construct(
        LoggerInterface $logger,
        Service $service,
        ScopeConfigInterface $scopeConfig,
        TransactionFactory $transactionFactory,
        ManagerInterface $messageManager
    ) {
        $this->logger = $logger;
        $this->service = $service;
        $this->scopeConfig = $scopeConfig;
        $this->transactionFactory = $transactionFactory;
        $this->messageManager = $messageManager;
    }

    public function execute(Observer $observer)
    {
        /** @var \Magento\Sales\Model\Order $order */
        $order = $observer->getEvent()->getOrder();

        $payment = $order->getPayment();
        if (!$payment || $payment->getMethod() !== 'axepta_online') {
            return;
        }

        $transactions = $this->transactionFactory->create();
        $transaction = $transactions->getCollection()
            ->addFieldToFilter('order_id', ['eq' => $order->getId()])
            ->getFirstItem();

        if (!$transaction || !$transaction->getId()) {
            return;
        }

        $paymentInformations = $payment->getAdditionalInformation();
        $trigram = $paymentInformations['axeptaMethodData']['code'] ?? '';
        if ($order->getBillingAddress()->getCountryId() != 'FR' && $trigram == 'CVM') {
            $trigram = 'VIM';
        }

        try {
            $data = $this->service->getPaymentDetails($transaction->getPayId(), $this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') ? strtoupper($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode')) : 'DEMO', $this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation'));

            if (!isset($data['status']) || $data['status'] === 'Failed') {
                $this->messageManager->addErrorMessage(__('You cannot cancel this order.'));
                return;
            }

            $cancel = $this->service->cancelPayment($this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key'), $transaction->getPayId(), $this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') ? strtoupper($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode')) : 'DEMO', $order->getGrandTotal() * 100, $paymentInformations['amount.currency'], $paymentInformations['billingAddress.country'], $paymentInformations['transId'], $trigram, $paymentInformations['orderReference'], $paymentInformations['cartId'], $paymentInformations['shopName'], $paymentInformations['customerInfo.lastName'], $paymentInformations['billingAddress.city']);
            $cancel = json_decode($cancel, true);

            $newTransaction = $this->transactionFactory->create();
            $newTransaction->setData([
                'order_id' => $transaction->getOrderId(),
                'merchant_id' => $data['merchantId'] ?? '',
                'transaction_reference' => $data['transId'] ?? '',
                'transaction_date' => date('Y-m-d H:i:s'),
                'pay_id' => $data['payId'] ?? '',
                'bid' => '',
                'xid' => $data['xId'] ?? '',
                'transaction_type' => 'cancellation',
                'payment_mean_brand' => $data['paymentMethods']['card']['brand'] ?? '',
                'response_code' => $cancel['responseCode'] ?? '',
                'pcnr' => $data['paymentMethods']['card']['first6Digits'] ?? '',
                'ccexpiry' => $data['paymentMethods']['card']['expiryDate'] ?? '',
                'status' => $cancel['status'] ?? '',
                'description' => $cancel['responseDescription'] ?? '',
                'amount' => $order->getGrandTotal(),
                'raw_data' => json_encode($data),
                'ref_nr' => $data['refNr'] ?? '',
                'scheme_reference_id' => '',
                'holder_name' => $data['paymentMethods']['card']['cardHolderName'] ?? '',
            ]);
            $newTransaction->save();
        } catch (\Exception $e) {
            $this->logger->critical($e->getMessage());
        }
    }
}
