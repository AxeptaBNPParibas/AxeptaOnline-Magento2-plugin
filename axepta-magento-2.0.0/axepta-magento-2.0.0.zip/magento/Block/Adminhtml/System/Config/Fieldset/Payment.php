<?php

namespace AxeptaBnpparibas\Online\Block\Adminhtml\System\Config\Fieldset;

use AxeptaBnpparibas\Online\Model\Api\Service;
use Magento\Backend\Block\Context;
use Magento\Backend\Model\Auth\Session;
use Magento\Config\Block\System\Config\Form\Fieldset;
use Magento\Config\Model\Config;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\Module\Dir;
use Magento\Framework\Module\PackageInfo;
use Magento\Framework\View\Helper\Js;
use Psr\Log\LoggerInterface;

class Payment extends Fieldset
{
    protected $backendConfig;

    protected $packageInfos;

    protected $moduleDir;

    protected $scopeConfig;

    protected $productMetadata;

    protected $service;

    protected $logger;

    public function __construct(
        Context $context,
        Session $authSession,
        Js $jsHelper,
        Config $backendConfig,
        PackageInfo $packageInfos,
        Dir $moduleDir,
        ScopeConfigInterface $scopeConfig,
        ProductMetadataInterface $productMetadata,
        Service $service,
        LoggerInterface $logger,
        array $data = [],
    ) {
        $this->backendConfig = $backendConfig;
        $this->packageInfos = $packageInfos;
        $this->moduleDir = $moduleDir;
        $this->scopeConfig = $scopeConfig;
        $this->productMetadata = $productMetadata;
        $this->service = $service;
        $this->logger = $logger;
        parent::__construct($context, $authSession, $jsHelper, $data);
    }

    /**
     * Add custom css class.
     *
     * @param AbstractElement $element
     *
     * @return string
     */
    protected function _getFrontendClass($element)
    {
        $enabledString = $this->_isPaymentEnabled($element) ? ' enabled' : '';

        return parent::_getFrontendClass($element) . ' with-button' . $enabledString;
    }

    /**
     * Check whether current payment method is enabled.
     *
     * @param AbstractElement $element
     *
     * @return bool
     */
    protected function _isPaymentEnabled($element)
    {
        $groupConfig = $element->getGroup();
        $activityPaths = isset($groupConfig['activity_path']) ? $groupConfig['activity_path'] : [];

        if (!is_array($activityPaths)) {
            $activityPaths = [$activityPaths];
        }

        $isPaymentEnabled = false;
        foreach ($activityPaths as $activityPath) {
            $isPaymentEnabled = $isPaymentEnabled
                || (bool) (string) $this->backendConfig->getConfigDataValue($activityPath);
        }

        return $isPaymentEnabled;
    }

    /**
     * Return header title part of html for payment solution.
     *
     * @param AbstractElement $element
     *
     * @return string
     *
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    protected function _getHeaderTitleHtml($element)
    {
        $version = $this->packageInfos->getVersion('AxeptaBnpparibas_Online');

        $filename = 'CHANGELOG.md';
        $file = fopen($this->moduleDir->getDir('AxeptaBnpparibas_Online') . '/' . $filename, 'r');

        $changes = $release = $section = [];
        while (!feof($file)) {
            $result = fgets($file);

            if (preg_match('/^## \[(.*)\] - (.*)$/', $result, $matches)) {
                if (!empty($release)) {
                    if (!empty($section)) {
                        $release['section'][] = $section;
                        $section = [];
                    }
                    $changes[] = $release;
                }
                $release['version'] = $matches[1];
                $release['date'] = $matches[2];
                $release['section'] = [];
            } elseif (preg_match('/^### (.*)$/', $result, $matches)) {
                if (!empty($section)) {
                    $release['section'][] = $section;
                }
                $section['title'] = $matches[1];
                $section['changelog'] = [];
            } elseif (preg_match('/^- (.*)$/', $result, $matches)) {
                $section['changelog'][] = $matches[1];
            }
        }

        if (!empty($section)) {
            $release['section'][] = $section;
        }
        if (!empty($release)) {
            $changes[] = $release;
        }

        fclose($file);

        $isDemoMode = false;
        $mode = $this->scopeConfig->getValue('payment/axepta_online/conf_account/mode');
        if ($mode == 'DEMO') {
            $isDemoMode = true;
        }

        $html = '<div class="config-heading">';
        if ($isDemoMode) {
            $html .= '<div class="block-demo-mode">' . __('You are in demo mode') . '</div>';
            $html .= '<div class="link-card-test"><a target="_blank" href="https://docs.axepta.bnpparibas/display/DOCBNP/Cartes+de+test+-+Autorisation">' . __('See test cards') . '</a></div>';
        }
        $html .= '<div class="heading">';

        if ($element->getComment()) {
            $html .= '<span class="heading-intro">' . $element->getComment() . '</span>';
        }
        $html .= '<div class="config-alt">Version ' . $version . '</div>';
        $html .= '</div></div>';

        $html .= '<div class="config-content">';
        $html .= '<div class="link-axepta"><a href="https://docs.axepta.bnpparibas/pages/viewpage.action?pageId=15073289" target="_blank" class="action-default link-docu">' . __('Documentation Axepta Bnp Paribas') . '</a></div>';
        $html .= '<div class="link-axepta"><a class="action-default contact-assistance">' . __('Contact the assistance') . '</a></div>';
        $html .= '<div class="link-axepta"><a class="action-default test-config">' . __('Check the configuration') . '</a></div>';
        $html .= '<div class="link-axepta"><a href="' . $this->getUrl('axeptaonline/download/logs') . '" class="action-default download-logs">' . __('Download logs') . '</a>';
        $html .= '</div></div>';

        $html .= '<div id="popup-modal-assistance" class="accordion" style="display: none">';
        $html .= '<fieldset class="config"><table><tbody>';
        $html .= '<tr><td class="label"><label for="name"><span>' . __('Firstname & Lastname') . '</span></label></td><td class="value"><input id="name" name="name" type="text" class="input-text admin__control-text" /></td></tr>';
        $html .= '<tr><td class="label"><label for="email"><span>' . __('Email') . '</span></label></td><td class="value"><input id="email" name="email" type="email" class="input-text admin__control-text" pattern="/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/" required/></td></tr>';
        $html .= '<tr><td class="label"><label for="description"><span>' . __('Description') . '</span></label></td><td class="value"><textarea id="description" name="description" class="admin__control-textarea textarea" rows="5" cols="15"></textarea></td></tr>';
        $html .= '<tr><td class="label"><label for="submit"><span>' . __(' ') . '</span></label></td><td class="value"><a href="' . $this->getUrl('axeptaonline/assistance/send') . '?send=1" id="submit-contact-assistance" class="action-default">' . __('Send my request') . '</a></td></tr>';
        $html .= '<tr class="error-message-assistance"><td class="label"><label><span>' . __(' ') . '</span></label></td><td class="value"><p>' . __('All fields must be completed and the email must be valid') . '</p></td></tr>';
        $html .= '</tbody></table></fieldset></div>';

        $html .= '<div id="popup-modal-configuration" class="accordion" style="display: none">';
        $html .= '<fieldset class="config"><table><tbody>';
        $html .= '<tr><td class="label"><label for="name"><span>' . __('Version PHP') . '</span></label></td><td class="value">' . PHP_VERSION . '</td></tr>';
        $html .= '<tr><td class="label"><label for="name"><span>' . __('Version CMS') . '</span></label></td><td class="value">' . $this->productMetadata->getVersion() . '</td></tr>';
        $html .= '<tr><td class="label"><label for="name"><span>' . __('Version Module') . '</span></label></td><td class="value">' . $version . '</td></tr>';
        $html .= '<tr><td class="label"><label for="name"><span>' . __('Mode') . '</span></label></td><td class="value">' . $mode . '</td></tr>';
        if ($mode == 'production') {
            $validKeys = $this->checkValidKeys();
            $class = $validKeys ? 'icon-valid' : 'icon-error';
            $html .= '<tr><td class="label"><label for="name"><span>' . __('Valid API Keys') . '</span></label></td><td class="value icon-check ' . $class . '"></td></tr>';
        }
        $html .= '</tbody></table></fieldset></div>';

        $html .= '<div id="popup-modal-version" class="accordion" style="display: none">';
        $html .= '<a href="' . $this->getUrl('axeptaonline/download/getfile') . '" class="download-changelog">' . __('Download CHANGELOG.md') . '</a>';
        $html .= '<div class="axepta-changelog-releases">';

        $i = 0;
        $hidden = false;
        foreach ($changes as $change) {
            if ($i == 2) {
                $hidden = true;
                $html .= '<div class="axepta-changelog-release-hidden">';
            }
            $html .= '<div class="axepta-changelog-release"><div class="axepta-changelog-release-version">';
            $html .= '<span>Release v' . $change['version'] . '</span>';
            if (!empty($change['date'])) {
                $html .= ' <span> - ' . $change['date'] . '</span>';
            }
            $html .= '</div>';
            foreach ($change['section'] as $section) {
                $html .= '<div class="axepta-changelog-section">';
                $html .= '<div class="axepta-changelog-section-title">' . $section['title'] . '</div>';
                $html .= '<ul class="axepta-changelog-section-changelog">';
                foreach ($section['changelog'] as $changelog) {
                    $html .= '<li>' . $changelog . '</li>';
                }
                $html .= '</ul></div>';
            }
            $html .= '</div>';
            ++$i;
        }
        if ($hidden) {
            $html .= '</div>';
        }
        $html .= '<div class="content">';
        if ($hidden) {
            $html .= '<span class="open-more">' . __('Show more') . '</span>';
        }
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    /**
     * Return header comment part of html for payment solution.
     *
     * @param AbstractElement $element
     *
     * @return string
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    protected function _getHeaderCommentHtml($element)
    {
        return '';
    }

    /**
     * Get collapsed state on-load.
     *
     * @param AbstractElement $element
     *
     * @return false
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    protected function _isCollapseState($element)
    {
        return false;
    }

    /**
     * @param AbstractElement $element
     *
     * @return string
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    protected function _getExtraJs($element)
    {
        $path = 'payment_us';
        if (!empty($element['original_data']) && !empty($element['original_data']['path'])) {
            $path = $element['original_data']['path'];
        }
        $script = "require([
            'jquery',
            'Magento_Ui/js/modal/modal'
        ],
            function($, modal) {
                var options = {
                    type: 'popup',
                    responsive: true,
                    innerScroll: true,
                    title: $.mage.__('Contact the assistance'),
                    modalClass: 'modal-contact-assistance',
                    buttons: [{
                        text: $.mage.__('Close'),
                        class: '',
                        click: function () {
                            this.closeModal();
                        }
                    }]
                };

                var popup = modal(options, $('#popup-modal-assistance'));
                $('.contact-assistance').on('click', function(event){
                    $('#popup-modal-assistance').modal('openModal');
                });

                var optionsVersion = {
                    type: 'popup',
                    responsive: true,
                    innerScroll: true,
                    title: $.mage.__('Axepta version'),
                    modalClass: 'modal-version-axepta',
                    buttons: [{
                        text: $.mage.__('Close'),
                        class: '',
                        click: function () {
                            this.closeModal();
                        }
                    }]
                };

                var popupVersion = modal(optionsVersion, $('#popup-modal-version'));
                $('.config-alt').on('click', function(event){
                    $('#popup-modal-version').modal('openModal');
                })

                var optionsCheck = {
                    type: 'popup',
                    responsive: true,
                    innerScroll: true,
                    title: $.mage.__('Configuration'),
                    modalClass: 'modal-configuration-axepta',
                    buttons: [{
                        text: $.mage.__('Close'),
                        class: '',
                        click: function () {
                            this.closeModal();
                        }
                    }]
                };

                var popupConfiguration = modal(optionsCheck, $('#popup-modal-configuration'));
                $('.test-config').on('click', function(event){
                    $('#popup-modal-configuration').modal('openModal');
                })

                $(document).ready(function() {
                    $('#name').change(function(){
                        var tmpVal = $('#name').val();
                        var tmphref = $('#submit-contact-assistance').attr('href');
                        tmphref = tmphref + '&name=' + tmpVal;
                        $('#submit-contact-assistance').attr('href',tmphref);
                    });

                    $('#email').change(function(){
                        var tmpVal = $('#email').val();
                        var tmphref = $('#submit-contact-assistance').attr('href');
                        tmphref = tmphref + '&email=' + tmpVal;
                        $('#submit-contact-assistance').attr('href',tmphref);
                    });

                    $('#description').change(function(){
                        var tmpVal = $('#description').val();
                        var tmphref = $('#submit-contact-assistance').attr('href');
                        tmphref = tmphref + '&description=' + tmpVal;
                        $('#submit-contact-assistance').attr('href',tmphref);
                    });

                    $('#submit-contact-assistance').on('click', function() {
                        if (!validateEmail($('#email').val()) || $('#name').val() == '' || $('#description').val() == '' || $('#email').val() == '') {
                            $('.error-message-assistance').show();
                            event.preventDefault();
                        }
                    });

                    function validateEmail(email) {
                        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                        return emailReg.test(email);
                    }

                    $('.open-more').on('click', function () {
                        if ($('.axepta-changelog-release-hidden').hasClass('showed')) {
                            $('.axepta-changelog-release-hidden').slideUp('slow');
                            $('.axepta-changelog-release-hidden').removeClass('showed');
                            $('.open-more').html($.mage.__('Show more'));
                        } else {
                            $('.axepta-changelog-release-hidden').slideDown('slow');
                            $('.axepta-changelog-release-hidden').addClass('showed');
                            $('.open-more').html($.mage.__('Show less'));
                        }
                    });

                    toogleDemoMode();
                    toogleProdMode();
                    toogleTestMode();

                    toogleCaptureMethod();
                    $('#" . $path . "_axepta_online_capture_mode_capture_mode').change(function() {
                        toogleCaptureMethod();
                    });

                    $('#" . $path . "_axepta_online_conf_account_mode').change(function() {
                        toogleDemoMode();
                        toogleProdMode();
                        toogleTestMode();
                    });

                    function toogleProdMode() {
                        if ($('#" . $path . "_axepta_online_conf_account_mode').val() === 'production') {
                            $('#row_" . $path . "_axepta_online_conf_account_private_key').show();
                            $('#row_" . $path . "_axepta_online_conf_account_public_key').show();
                        }
                    }

                    function toogleTestMode() {
                        if ($('#" . $path . "_axepta_online_conf_account_mode').val() === 'test') {
                            $('#row_" . $path . "_axepta_online_conf_account_private_key').show();
                            $('#row_" . $path . "_axepta_online_conf_account_public_key').show();
                        }
                    }

                    function toogleDemoMode() {
                        if ($('#" . $path . "_axepta_online_conf_account_mode').val() === 'DEMO') {
                            $('#" . $path . "_axepta_online_conf_account_mode').nextAll('.note').show();
                            $('#row_" . $path . "_axepta_online_conf_account_private_key').hide();
                            $('#row_" . $path . "_axepta_online_conf_account_public_key').hide();
                        } else {
                            $('#" . $path . "_axepta_online_conf_account_mode').nextAll('.note').hide();
                        }
                    }

                    function toogleCaptureMethod() {
                        if ($('#" . $path . "_axepta_online_capture_mode_capture_mode').val() === 'manual') {
                            $('#" . $path . "_axepta_online_capture_mode_capture_mode').nextAll('.note').show();
                        } else {
                            $('#" . $path . "_axepta_online_capture_mode_capture_mode').nextAll('.note').hide();
                        }
                    }
                });
            }
        );";

        return $this->_jsHelper->getScript($script);
    }

    protected function checkValidKeys()
    {
        if (!$this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key') || !$this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key')) {
            return false;
        }

        try {
            $token = $this->service->getToken($this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key'));
        } catch (\Exception $e) {
            $this->logger->critical($e);

            return false;
        }

        if (isset($token)) {
            return true;
        }

        return false;
    }
}
