<?php

namespace AxeptaBnpparibas\Online\Block\Adminhtml\Transaction;

use AxeptaBnpparibas\Online\Model\TransactionFactory;
use Magento\Backend\Block\Template;
use Magento\Backend\Block\Widget\Context;
use Magento\Framework\Registry;

class View extends Template
{
    /**
     * @var TransactionFactory
     */
    protected $model;

    /**
     * @var Registry
     */
    protected $coreRegistry;

    public function __construct(
        Context $context,
        Registry $registry,
        TransactionFactory $model,
        array $data = [],
    ) {
        $this->coreRegistry = $registry;
        $this->model = $model;

        parent::__construct($context, $data);
    }

    /**
     * Check permission for passed action.
     *
     * @return bool
     */
    protected function _isAllowedAction()
    {
        return true;
    }

    /**
     * @return TransactionFactory
     */
    public function getTransactionsDataById()
    {
        $id = $this->getRequest()->getParam('id');
        $transaction = $this->model->create()->load($id);

        $transactions = $this->model
            ->create()
            ->getCollection()
            ->addFieldToFilter('transaction_reference', ['eq' => $transaction->getTransactionReference()])
            ->addFieldToFilter('xid', ['eq' => $transaction->getXid()])
            ->addFieldToFilter('pay_id', ['eq' => $transaction->getPayId()]);

        $transactions->getSelect()->group('transaction_reference')->order('id DESC');

        return $transactions;
    }
}
