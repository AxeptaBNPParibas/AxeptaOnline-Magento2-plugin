<?php

namespace AxeptaPaygate;

use AxeptaPaygate\Exception\FeatureNotSupportedException;
use AxeptaPaygate\Payment\AmericanExpressPaymentMethod;
use AxeptaPaygate\Payment\CvmPaymentMethod;
use AxeptaPaygate\Payment\PaymentMethod;
use AxeptaPaygate\Payment\PaypalPaymentMethod;
use AxeptaPaygate\Payment\VimPaymentMethod;

class Utils
{
    public static function getEnv(string $key, $default)
    {
        return getenv($key) !== false ? getenv($key) : $default;
    }

    public static function nestArray(&$array)
    {
        // Transform "flatten" keys into nested arrays:
        // e.g.
        // [
        //     "foo" => "bar",
        //     "amount.value" => "100",
        //     "amount.currency" => "EUR",
        // ]
        // becomes:
        // [
        //     "foo" => "bar",
        //     "amount" => [
        //         "value" => "100",
        //         "currency" => "EUR",
        //     ]
        // ]
        // This is useful for JSON params

        $result = [];
        foreach ($array as $key => $value) {
            $keys = explode('.', $key);
            $current = &$result;
            foreach ($keys as $nested_key) {
                /* @phpstan-ignore-next-line */
                if (!isset($current[$nested_key])) {
                    $current[$nested_key] = [];
                }
                $current = &$current[$nested_key];
            }

            if (is_array($current) && is_array($value)) {
                $current = array_merge($current, $value);
            } else {
                $current = $value;
            }
        }

        $array = $result;
    }

    public static function randomString($length = 20)
    {
        // Each byte will be converted to two hex characters, so we need half the length in bytes
        $bytes = random_bytes($length / 2);

        return bin2hex($bytes);
    }

    public static function getPaymentMethodFromTrigram(?string $trigram)
    {
        if ($trigram === null) {
            // Use the base class as a generic payment method
            return PaymentMethod::class;
        }

        switch ($trigram) {
            case 'AMX': return AmericanExpressPaymentMethod::class;
            case 'CVM': return CvmPaymentMethod::class;
            case 'PAL': return PaypalPaymentMethod::class;
            case 'VIM': return VimPaymentMethod::class;
        }

        throw new FeatureNotSupportedException("The trigram '$trigram' is not supported");
    }

    public static function getPayTypesFromTrigram(?string $trigram)
    {
        switch ($trigram) {
            case 'AMX': return ['AMEX'];
            case 'CVM': return ['VISA', 'MASTERCARD', 'CARTESBANCAIRES'];
            case 'VIM': return ['VISA', 'MASTERCARD'];
        }

        throw new FeatureNotSupportedException("The trigram '$trigram' is not supported");
    }

    public static function removeNestedValues(array &$array, $targetValue)
    {
        foreach ($array as $key => &$value) {
            if (is_array($value)) {
                self::removeNestedValues($value, $targetValue); // Recursively call function for nested arrays
                if (empty($value)) {
                    unset($array[$key]); // Remove empty arrays
                }
            } elseif ($value === $targetValue) {
                unset($array[$key]); // Remove the value
            }
        }
    }
}
