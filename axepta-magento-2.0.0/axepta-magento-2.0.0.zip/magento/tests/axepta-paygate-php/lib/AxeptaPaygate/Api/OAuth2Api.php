<?php

namespace AxeptaPaygate\Api;

use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\PaymentMode;
use AxeptaPaygate\Exception\ApiCallException;

class OAuth2Api
{
    // Convenient way to make a request and pass the accessToken
    public static function buildJsonRequest(string $accessToken, string $url, string $method = 'GET', array $data = [], array $headers = [])
    {
        $headers = [
            "authorization: Bearer $accessToken",
            'content-type: application/json',
        ];
        $data = json_encode($data);

        // TODO: support accessToken expiration?
        return new OAuth2ApiRequest($url, $method, $headers, $data);
    }

    public static function getAccessToken(string $mid, string $apiKey, $paymentMode = PaymentMode::PRODUCTION)
    {
        if ($paymentMode == PaymentMode::PRODUCTION) {
            $url = 'https://paymentpage.axepta.bnpparibas/authorization/oauth/token';
        } else {
            $url = 'https://test.paymentpage.axepta.bnpparibas/authorization/oauth/token';
        }

        $headers = [
            'content-type: application/x-www-form-urlencoded',
        ];
        $data = http_build_query([
            'grant_type' => 'client_credentials',
            'client_id' => $mid,
            'client_secret' => $apiKey,
            // 'audience' => 'YOUR_API_IDENTIFIER',
        ]);

        $request = new OAuth2ApiRequest($url, 'POST', $headers, $data);
        $response = $request->call();
        $response_data = json_decode($response, true);

        if (!array_key_exists('access_token', $response_data)) {
            throw new ApiCallException('Missing key: access_token. Response: ' . $response);
        }
        if (!array_key_exists('token_type', $response_data)) {
            throw new ApiCallException('Missing key: token_type. Response: ' . $response);
        }
        if (!array_key_exists('expires_in', $response_data)) {
            throw new ApiCallException('Missing key: expires_in. Response: ' . $response);
        }
        if ($response_data['token_type'] !== 'Bearer') {
            throw new ApiCallException('Invalid token_type. Expected "Bearer". Response: ' . $response);
        }

        // TODO: validate token
        // https://auth0.com/docs/secure/tokens/json-web-tokens/validate-json-web-tokens

        return $response_data;
    }

    public static function getBaseurl()
    {
        $cfg = AxeptaPaygate::getConfiguration();
        if ($cfg['paymentMode'] == PaymentMode::PRODUCTION) {
            return 'https://paymentpage.axepta.bnpparibas/api/v2';
        }

        return 'https://test.paymentpage.axepta.bnpparibas/api/v2';
    }
}
