<?php

namespace AxeptaPaygate\Payment\Traits;

use AxeptaPaygate\Api\OAuth2Api;
use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentRenderingMode;
use AxeptaPaygate\ParamsValidator;

trait CardTrait
{
    use RefundAndReversalTrait {
        buildOrNull as buildOrNullRefundAndReversal;
    }

    public static function buildOrNull()
    {
        if (($operation = self::buildOrNullRefundAndReversal()) != null) {
            return $operation;
        }

        $cfg = AxeptaPaygate::getConfiguration();

        $apiUrl = OAuth2Api::getBaseurl() . '/payments';
        $apiMethod = 'POST';

        switch ($cfg['operationType']) {
            case OperationType::ONE_CLICK_PAYMENT:
                $paramKeys = [
                    '$.amount.value',
                    '$.amount.currency',
                    '$.captureMethod',
                    '$.credentialOnFile',
                    '$.externalIntegrationId',
                    '$.paymentMethods',
                    '$.refNr',
                    '$.requestId',
                    '$.statementDescriptor',
                    '$.transId',
                    '$.metadata',
                ];

                if ($cfg['paymentRenderingMode'] == PaymentRenderingMode::REDIRECT) {
                    $paramKeys = array_merge($paramKeys, [
                        '$.language',
                        '$.billingAddress',
                        '$.customerInfo',
                        '$.customFields',
                        '$.shipping.address',
                        '$.urls.cancel',
                        '$.urls.webhook',
                        '$.urls.return',
                    ]);
                }
                break;

            case OperationType::RECURRING_PAYMENT_SUBSCRIPTION:
                self::_assertPaymentRenderingModeEquals(PaymentRenderingMode::DIRECT);

                $paramKeys = [
                    '$.amount.value',
                    '$.amount.currency',
                    '$.captureMethod',
                    '$.credentialOnFile',
                    '$.externalIntegrationId',
                    '$.paymentMethods',
                    '$.refNr',
                    '$.requestId',
                    '$.transId',
                    '$.metadata',
                ];
                break;

            case OperationType::SIMPLE_PAYMENT:
                if ($cfg['paymentRenderingMode'] == PaymentRenderingMode::HPP) {
                    // HPP mode is supported in the PaymentMethod class.
                    return parent::build();
                }

                $paramKeys = [
                    '$.amount.value',
                    '$.amount.currency',
                    '$.captureMethod',
                    '$.customerInfo',
                    '$.externalIntegrationId',
                    '$.paymentMethods',
                    '$.refNr',
                    '$.requestId',
                    '$.statementDescriptor',
                    '$.transId',
                    '$.metadata',
                ];

                if ($cfg['paymentRenderingMode'] == PaymentRenderingMode::REDIRECT) {
                    $paramKeys = array_merge($paramKeys, [
                        '$.language',
                        '$.billingAddress',
                        '$.customFields',
                        '$.shipping.address',
                        '$.urls.cancel',
                        '$.urls.webhook',
                        '$.urls.return',
                    ]);
                }
                if ($cfg->get('saveCard', false) || $cfg->get('initializeSubscription', false)) {
                    $paramKeys[] = '$.credentialOnFile';
                }
                break;

            default:
                return null;
        }

        $params = ParamsValidator::validateParams($paramKeys);

        return [
            'request' => OAuth2Api::buildJsonRequest($cfg['api_access_token'], $apiUrl, $apiMethod, $params),
            'params' => $params,
        ];
    }
}
