<?php

namespace AxeptaPaygate\Payment;

use AxeptaPaygate\Api\OAuth2Api;
use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentRenderingMode;
use AxeptaPaygate\ParamsValidator;

class SofortPaymentMethod extends PaymentMethod
{
    public static function build()
    {
        $cfg = AxeptaPaygate::getConfiguration();

        $apiUrl = OAuth2Api::getBaseurl() . '/payments';
        $apiMethod = 'POST';

        switch ($cfg['operationType']) {
            case OperationType::SIMPLE_PAYMENT:
                if ($cfg['paymentRenderingMode'] == PaymentRenderingMode::HPP) {
                    // We only support "redirect" mode in here.
                    // HPP mode is supported in the PaymentMethod class.
                    return parent::build();
                }

                self::_assertPaymentRenderingModeEquals(PaymentRenderingMode::REDIRECT);

                $paramKeys = [
                    '$.amount.value',
                    '$.amount.currency',
                    '$.billing',
                    '$.billing.addressInfo',
                    '$.order.id',
                    '$.order.description',
                    '$.payment.method',
                    '$.payment.sofort.sofortAction',
                    '$.transactionId',
                    '$.metadata.userData',
                    '$.urls.cancel',
                    '$.urls.failure',
                    '$.urls.notify',
                    '$.urls.success',
                ];

                break;

            default:
                return parent::build();
        }

        $params = ParamsValidator::validateParams($paramKeys);

        return [
            'request' => OAuth2Api::buildJsonRequest($cfg['api_access_token'], $apiUrl, $apiMethod, $params),
            'params' => $params,
        ];
    }

    public static function isAvailableForCountry(string $iso2CountryCode)
    {
        return in_array($iso2CountryCode, [
            'AT', // Austria
            'BE', // Belgium
            // 'FR', // France: Listed as available but does not work
            'DE', // Germany
            'IT', // Italy
            'NL', // Netherlands
            'SK', // Slovakia
            'ES', // Spain
            'GB', // United Kingdom
        ]);
    }

    public static function isCurrencySupported(string $isoCurrency)
    {
        return $isoCurrency == 'EUR';
    }
}
