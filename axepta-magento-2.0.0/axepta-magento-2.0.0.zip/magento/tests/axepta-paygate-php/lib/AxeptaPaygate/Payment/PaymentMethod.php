<?php

namespace AxeptaPaygate\Payment;

use AxeptaPaygate\Api\OAuth2Api;
use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentRenderingMode;
use AxeptaPaygate\Exception\ConfigurationException;
use AxeptaPaygate\Exception\FeatureNotSupportedException;
use AxeptaPaygate\ParamsValidator;

abstract class PaymentMethod
{
    public static function build()
    {
        $cfg = AxeptaPaygate::getConfiguration();

        $apiUrl = OAuth2Api::getBaseurl() . '/payments';
        $apiMethod = 'POST';

        switch ($cfg['operationType']) {
            case OperationType::SIMPLE_PAYMENT:
                self::_assertPaymentRenderingModeEquals(PaymentRenderingMode::HPP);
                $apiUrl .= '/sessions';

                $paramKeys = [
                    '$.amount.value',
                    '$.amount.currency',
                    '$.billingAddress',
                    '$.captureMethod',
                    '$.customerInfo',
                    '$.customFields',
                    '$.externalIntegrationId',
                    '$.language',
                    '$.metadata',
                    '$.paymentMethods',
                    '$.customerInfo',
                    '$.customFields',
                    '$.refNr',
                    '$.requestId',
                    '$.shipping.address',
                    '$.statementDescriptor',
                    '$.transId',
                    '$.urls.cancel',
                    '$.urls.webhook',
                    '$.urls.return',
                ];

                break;
            case OperationType::CAPTURE_PAYMENT:
                self::_assertPaymentRenderingModeNotSet();

                $paramKeys = [
                    '$.amount.value',
                    '$.amount.currency',
                    '$.transId',
                    '$.finishAuth',
                ];
                $apiUrl .= '/' . $cfg['paymentId'] . '/captures';
                break;

            default:
                throw new FeatureNotSupportedException("The operation '" . $cfg['operationType'] . "' is not supported. Maybe you forgot to set the trigram?");
        }

        $params = ParamsValidator::validateParams($paramKeys);

        return [
            'request' => OAuth2Api::buildJsonRequest($cfg['api_access_token'], $apiUrl, $apiMethod, $params),
            'params' => $params,
        ];
    }

    public static function isAvailableForCountry(?string $iso2CountryCode)
    {
        // This is supported everywhere
        return true;
    }

    public static function isCurrencySupported(string $isoCurrency)
    {
        // This is supported everywhere
        return true;
    }

    protected static function _assertPaymentRenderingModeEquals($requiredMode)
    {
        $cfg = AxeptaPaygate::getConfiguration();

        if ($cfg['paymentRenderingMode'] !== $requiredMode) {
            throw new FeatureNotSupportedException("The payment rendering mode '" . $cfg['paymentRenderingMode'] . "' is not supported");
        }
    }

    protected static function _assertPaymentRenderingModeIn(...$allowedModes)
    {
        $cfg = AxeptaPaygate::getConfiguration();

        if (!in_array($cfg['paymentRenderingMode'], $allowedModes)) {
            throw new FeatureNotSupportedException("The payment rendering mode '" . $cfg['paymentRenderingMode'] . "' is not supported");
        }
    }

    protected static function _assertPaymentRenderingModeNotSet()
    {
        $cfg = AxeptaPaygate::getConfiguration();

        if ($cfg->has('paymentRenderingMode')) {
            $message = "Payment rendering mode should not be set. It is currently set to '" . $cfg['paymentRenderingMode'] . "'";
            throw new ConfigurationException($message);
        }
    }
}
