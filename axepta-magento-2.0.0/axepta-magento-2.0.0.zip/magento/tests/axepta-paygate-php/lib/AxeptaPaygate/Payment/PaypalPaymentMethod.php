<?php

namespace AxeptaPaygate\Payment;

use AxeptaPaygate\Api\OAuth2Api;
use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentRenderingMode;
use AxeptaPaygate\ParamsValidator;
use AxeptaPaygate\Payment\Traits\RefundAndReversalTrait;

class PaypalPaymentMethod extends PaymentMethod
{
    use RefundAndReversalTrait {
        buildOrNull as buildOrNullRefundAndReversal;
    }

    public static function build()
    {
        if (($operation = self::buildOrNullRefundAndReversal()) != null) {
            return $operation;
        }

        $cfg = AxeptaPaygate::getConfiguration();

        $apiUrl = OAuth2Api::getBaseurl() . '/payments';
        $apiMethod = 'POST';

        switch ($cfg['operationType']) {
            case OperationType::SIMPLE_PAYMENT:
                if ($cfg['paymentRenderingMode'] == PaymentRenderingMode::HPP) {
                    // We only support "redirect" mode in here.
                    // HPP mode is supported in the PaymentMethod class.
                    return parent::build();
                }

                self::_assertPaymentRenderingModeEquals(PaymentRenderingMode::REDIRECT);

                $paramKeys = [
                    '$.amount.value',
                    '$.amount.currency',
                    '$.billingAddress',
                    '$.captureMethod',
                    '$.customerInfo',
                    '$.externalIntegrationId',
                    '$.language',
                    '$.metadata',
                    '$.paymentMethods',
                    '$.refNr',
                    '$.requestId',
                    '$.shipping.address',
                    '$.statementDescriptor',
                    '$.transId',
                    '$.urls.cancel',
                    '$.urls.webhook',
                    '$.urls.return',
                ];

                break;
            default:
                return parent::build();
        }

        $params = ParamsValidator::validateParams($paramKeys);

        return [
            'request' => OAuth2Api::buildJsonRequest($cfg['api_access_token'], $apiUrl, $apiMethod, $params),
            'params' => $params,
        ];
    }
}
