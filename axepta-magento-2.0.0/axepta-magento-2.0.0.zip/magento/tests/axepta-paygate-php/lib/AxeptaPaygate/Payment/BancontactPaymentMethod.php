<?php

namespace AxeptaPaygate\Payment;

use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentRenderingMode;
use AxeptaPaygate\Payment\Traits\RefundAndReversalTrait;

class BancontactPaymentMethod extends PaymentMethod
{
    use RefundAndReversalTrait;

    public static function build()
    {
        if (($operation = self::buildOrNull()) != null) {
            return $operation;
        }

        $cfg = AxeptaPaygate::getConfiguration();

        if ($cfg['operationType'] == OperationType::SIMPLE_PAYMENT) {
            // The API paygate does not support Bancontact in redirect mode yet.
            self::_assertPaymentRenderingModeEquals(PaymentRenderingMode::HPP);
        }

        return parent::build();
    }

    public static function isAvailableForCountry(string $iso2CountryCode)
    {
        return $iso2CountryCode == 'BE';
    }

    public static function isCurrencySupported(string $isoCurrency)
    {
        return $isoCurrency == 'EUR';
    }
}
