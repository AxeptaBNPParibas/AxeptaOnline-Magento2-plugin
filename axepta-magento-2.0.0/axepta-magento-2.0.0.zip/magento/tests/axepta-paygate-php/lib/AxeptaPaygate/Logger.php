<?php

namespace AxeptaPaygate;

class Logger
{
    const LEVEL_DEBUG = 'DEBUG';
    const LEVEL_INFO = 'INFO';
    const LEVEL_WARNING = 'WARNING';
    const LEVEL_ERROR = 'ERROR';

    private $filepath;

    public function __construct(string $filepath)
    {
        $this->filepath = $filepath;
    }

    public function log(string $level, string $message)
    {
        $timestamp = date('Y-m-d H:i:s');
        $formattedMessage = "[$timestamp][$level] $message" . PHP_EOL;
        file_put_contents($this->filepath, $formattedMessage, FILE_APPEND | LOCK_EX);
    }

    public function debug($message)
    {
        $this->log(self::LEVEL_DEBUG, $message);
    }

    public function info($message)
    {
        $this->log(self::LEVEL_INFO, $message);
    }

    public function warning($message)
    {
        $this->log(self::LEVEL_WARNING, $message);
    }

    public function error($message)
    {
        $this->log(self::LEVEL_ERROR, $message);
    }
}
