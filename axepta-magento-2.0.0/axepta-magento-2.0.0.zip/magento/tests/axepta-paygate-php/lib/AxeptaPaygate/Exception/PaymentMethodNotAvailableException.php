<?php

namespace AxeptaPaygate\Exception;

class PaymentMethodNotAvailableException extends AxeptaPaygateException
{
}
