<?php

namespace AxeptaPaygate\Exception;

class FeatureNotSupportedException extends AxeptaPaygateException
{
}
