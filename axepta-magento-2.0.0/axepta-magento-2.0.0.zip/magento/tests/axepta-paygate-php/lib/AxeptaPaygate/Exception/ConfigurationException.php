<?php

namespace AxeptaPaygate\Exception;

class ConfigurationException extends AxeptaPaygateException
{
}
