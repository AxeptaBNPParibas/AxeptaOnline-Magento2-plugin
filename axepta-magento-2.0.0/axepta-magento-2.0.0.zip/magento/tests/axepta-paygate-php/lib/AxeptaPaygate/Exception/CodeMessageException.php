<?php

namespace AxeptaPaygate\Exception;

class CodeMessageException extends AxeptaPaygateException
{
}
