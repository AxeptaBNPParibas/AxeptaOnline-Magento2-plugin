<?php

namespace AxeptaPaygate\Core;

// BBB: use PHP enums
class PaymentRenderingMode
{
    const DIRECT = 'DIRECT';
    const REDIRECT = 'REDIRECT';
    const HPP = 'HPP';
}
