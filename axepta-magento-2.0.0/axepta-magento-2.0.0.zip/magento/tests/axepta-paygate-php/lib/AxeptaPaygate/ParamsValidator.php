<?php

namespace AxeptaPaygate;

use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\CaptureMode;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentRenderingMode;
use AxeptaPaygate\Exception\FeatureNotSupportedException;
use AxeptaPaygate\Exception\ParamsValidationException;

class ParamsValidator
{
    const MAX_REFNR_LENGTH = 12;

    public static function validateFormat($format, $value)
    {
        if (is_null($format)) {
            return true;
        }

        if ($format === 'JSON') {
            // NB: If the $format is "JSON", the $value must be a regular PHP array.
            //
            // Ideally, $value should be a JSON string, and we would check that
            // it is a valid JSON string like so:
            // >>>> json_decode($value);
            // >>>> return json_last_error() === JSON_ERROR_NONE;
            // but we don't do that.
            //
            // $value must remain a php array troughout the whole process since
            // it will be nested in the final JSON string in case of a REST API
            // call. If $value is already a JSON string, the final JSON would
            // be incorrect.
            //
            // So instead, let's check that $value can be converted to a JSON string.
            json_encode($value);

            return json_last_error() === JSON_ERROR_NONE;
        }

        // Perform the match
        if (!preg_match('/(?P<type>[ans]+)(?P<is_length_fixed>\.\.)?(?P<length>\d+)?/', $format, $matches)) {
            return true;
        }

        // Extract the named groups into an associative array
        $result = [
            'type' => strtolower($matches['type']),
            'is_length_fixed' => isset($matches['is_fixed']),
            'length' => isset($matches['length']) ? intval($matches['length']) : null,
        ];

        // Check length
        $valueLength = strlen($value);
        if ($valueLength === 0) {
            return false;
        }
        if ($result['is_length_fixed'] && $valueLength !== $result['length']) {
            return false;
        }
        if (!$result['is_length_fixed'] && $valueLength > $result['length']) {
            return false;
        }

        switch ($result['type']) {
            case 'a':
                return preg_match('/^[a-zA-Z]+$/', $value) == 1;
            case 'n':
                return preg_match('/^[0-9]+$/', $value) == 1;
            case 'an':
                return preg_match('/^[a-zA-Z0-9]+$/', $value) == 1;
            case 'ans':
                // All chars are allowed
                return true;
            default:
                throw new \Exception('Invalid type: ' . $result['type']);
        }
    }

    public static function validateParams($paramKeys)
    {
        $cfg = AxeptaPaygate::getConfiguration();

        $params = [];
        foreach ($paramKeys as $paramKey) {
            [$paramFormat, $paramValue] = self::_getParamFormatAndValue($paramKey);

            if (!$cfg->isDryRun()) {
                if (!self::validateFormat($paramFormat, $paramValue)) {
                    $message = "Value '$paramValue' from param '$paramKey' does not match the required format '$paramFormat'.";
                    throw new ParamsValidationException($message);
                }
            }

            $params[$paramKey] = $paramValue;
        }

        self::_handleSpecialCases($params);

        Utils::removeNestedValues($params, null);
        Utils::nestArray($params);

        // NB: JSON params keys start with "$.", so all params end up in $params['$']
        return $params['$'];
    }

    // TODO: validate formats
    public static function _buildJsonAddressFromCfg(string $keyPrefix)
    {
        // See https://developer.computop.com/display/EN/address
        $cfg = AxeptaPaygate::getConfiguration();

        $data = [
            'streetName' => $cfg[$keyPrefix . '.streetName'],
            'streetNumber' => $cfg[$keyPrefix . '.streetNumber'],
            'city' => $cfg[$keyPrefix . '.city'],
            'country' => $cfg[$keyPrefix . '.country'],
            'postalCode' => $cfg[$keyPrefix . '.postalCode'],
        ];

        return $data;
    }

    public static function _buildJsonCardFromCfg($keyPrefix)
    {
        $cfg = AxeptaPaygate::getConfiguration();

        $data = [
            'expiryDate' => $cfg[$keyPrefix . '.expiryDate'],
            'number' => $cfg[$keyPrefix . '.number'],
            'brand' => $cfg[$keyPrefix . '.brand'],
        ];

        return $data;
    }

    public static function _buildJsonPaymentMethods($keyPrefix)
    {
        $cfg = AxeptaPaygate::getConfiguration();

        $data = [];
        $type = null;
        $hppEnable = $cfg['paymentRenderingMode'] == PaymentRenderingMode::HPP;

        if ($hppEnable || $cfg['trigram'] == 'VIM') {
            $type = 'CARD';
            $data['card'] = [
                'subType' => Utils::getPayTypesFromTrigram('VIM'),
            ];
        }

        if ($hppEnable || $cfg['trigram'] == 'CVM') {
            $type = 'CARD';
            $data['card'] = [
                'subType' => Utils::getPayTypesFromTrigram('CVM'),
            ];
        }

        if ($hppEnable || $cfg['trigram'] == 'BAN') {
            $type = 'BANCONTACT';
            // TODO : Je suis contre, inutile à mon sens et pourtant mandatory chez computop
            $data['bancontact'] = [
                'account' => [
                    'accountHolderName' => $cfg['customerInfo.firstName'] . ' ' . $cfg['customerInfo.lastName'],
                ],
            ];
        }

        if ($hppEnable || $cfg['trigram'] == 'IDE') {
            $type = 'IDEAL';
            $data['ideal'] = [
                'subType' => 'IDEAL',
            ];
        }

        if ($hppEnable || $cfg['trigram'] == 'AMX') {
            $type = 'CARD';
            $data['card'] = [
                'subType' => Utils::getPayTypesFromTrigram('AMX'),
            ];
        }

        if ($hppEnable || $cfg['trigram'] == 'KLA') {
            $type = 'KLARNA';
            $data['klarna'] = [
                'subType' => 'PAY_NOW',
            ];
        }

        if ($hppEnable || $cfg['trigram'] == 'PAL') {
            $type = 'PAYPAL';
        }

        // ApplePay only in DIRECT FTM
        if (!$hppEnable && $cfg['trigram'] == 'APP') {
            $type = 'APPLEPAY';
        }

        $data['type'] = $type;

        if ($cfg['paymentRenderingMode'] == PaymentRenderingMode::REDIRECT) {
            $data['integrationType'] = 'HOSTED';
        }

        if ($cfg['paymentRenderingMode'] == PaymentRenderingMode::DIRECT) {
            $data['integrationType'] = 'DIRECT';

            switch ($type) {
                case 'CARD':
                    $data['card'] = [
                        'number' => $cfg[$keyPrefix . '.card.number'],
                        'cardHolderName' => $cfg[$keyPrefix . '.card.cardHolderName'],
                        'expiryDate' => $cfg[$keyPrefix . '.card.expiryDate'],
                        'brand' => $cfg[$keyPrefix . '.card.brand'],
                        // 'schemeReferenceId' => $cfg[$keyPrefix . '.card.schemeReferenceId']
                    ];
                    break;

                case 'APPLEPAY':
                    $data['applePay'] = [
                        'token' => $cfg[$keyPrefix . '.applepay.token'],
                        'merchantIdentifierOfPublicKey' => $cfg[$keyPrefix . '.applepay.merchantIdentifierOfPublicKey'],
                    ];
                    break;
                case 'PAYPAL':
                    if ($cfg->get($keyPrefix . '.paypal.accountId', false)) {
                        $data['payPal'] = [
                            'accountId' => $cfg[$keyPrefix . '.paypal.accountId'],
                            'hideAddress' => $cfg->get($keyPrefix . '.paypal.hideAddress', true),
                        ];
                    }
                    break;
            }
        }

        if ($hppEnable) {
            $data['card']['subType'] = [
                'VISA',
                'MASTERCARD',
                'CARTESBANCAIRES',
                'AMEX',
            ];
        }

        return $data;
    }

    public static function _buildJsonCofFromCfg()
    {
        $cfg = AxeptaPaygate::getConfiguration();

        if ($cfg['operationType'] === OperationType::SIMPLE_PAYMENT) {
            if ($cfg->get('saveCard', false)) {
                return [
                    'type' => 'UNSCHEDULED',
                    'unscheduled' => [
                        'subType' => $cfg['paymentRenderingMode'] == PaymentRenderingMode::DIRECT ? 'MIT' : 'CIT',
                    ],
                    'initialPayment' => true,
                ];
            }

            if ($cfg->get('initializeSubscription', false)) {
                return [
                    'type' => 'RECURRING',
                    'initialPayment' => true,
                    'recurring' => [
                        'frequency' => $cfg['recurring.frequency'],
                        'expiryDate' => $cfg['recurring.expiryDate'],
                        'startDate' => $cfg->get('recurring.startDate', date('Y-m-d')),
                        'useCase' => $cfg->get('recurring.useCase', 'FIXED'),
                    ],
                ];
            }
        }

        if ($cfg['operationType'] === OperationType::ONE_CLICK_PAYMENT) {
            return [
                'type' => 'UNSCHEDULED',
                'unscheduled' => [
                    'subType' => 'CIT',
                ],
                'initialPayment' => false,
            ];
        }

        if ($cfg['operationType'] === OperationType::RECURRING_PAYMENT_SUBSCRIPTION) {
            return [
                'type' => 'RECURRING',
                'initialPayment' => false,
                'recurring' => [
                    'frequency' => $cfg['recurring.frequency'],
                    'expiryDate' => $cfg['recurring.expiryDate'],
                    //     'startDate' => $cfg['recurring.startDate'], // TODO : NOT REQUIRED
                    'useCase' => $cfg->get('recurring.useCase', 'FIXED'),
                ],
            ];
        }

        throw new FeatureNotSupportedException('credentialOnFile could not be created correctly');
    }

    // TODO: validate formats
    public static function _buildJsonCustomerInfoFromCfg(string $keyPrefix)
    {
        $cfg = AxeptaPaygate::getConfiguration();

        $data = [
            'merchantCustomerId' => $cfg->get($keyPrefix . '.merchantCustomerId'),
            'customerType' => $cfg->get($keyPrefix . '.customerType'),
            'firstName' => $cfg[$keyPrefix . '.firstName'],
            'lastName' => $cfg[$keyPrefix . '.lastName'],
            'email' => $cfg->get($keyPrefix . '.email'),
            'phone' => [
                'countryCode' => $cfg->get($keyPrefix . '.countryCode'),
                'number' => $cfg->get($keyPrefix . '.number'),
            ],
            'salutation' => $cfg->get($keyPrefix . '.salutation'),
            'title' => $cfg->get($keyPrefix . '.title'),
            'gender' => $cfg->get($keyPrefix . '.gender'),
            'maidenName' => $cfg->get($keyPrefix . '.maidenName'),
            'middleName' => $cfg->get($keyPrefix . '.middleName'),
            'birthDate' => $cfg->get($keyPrefix . '.birthDate'),
            'birthPlace' => $cfg->get($keyPrefix . '.birthPlace'),
            'socialSecurityNumber' => $cfg->get($keyPrefix . '.socialSecurityNumber'),
        ];

        return $data;
    }

    public static function _buildJsonPaysafeCardFromCfg()
    {
        $cfg = AxeptaPaygate::getConfiguration();

        return [
            'connectionViaPPRO' => [
                'accountHolder' => $cfg['paysafeCard.accountHolder'],
                'country' => $cfg['billing.addressInfo.country.countryA2'],
                'service' => $cfg->get('paysafeCard.service', 'products'),
                'sellingPoint' => $cfg->get('paysafeCard.sellingPoint', 'sp'),
            ],
            'customerId' => $cfg['paysafeCard.customerId'],
        ];
    }

    public static function _buildJsonCustomFieldsFromCfg($keyPrefix)
    {
        $cfg = AxeptaPaygate::getConfiguration();

        $data = [
            'customField1' => $cfg->get($keyPrefix . '.customField1', sprintf('%s %s', $cfg['amount.value'], $cfg['amount.currency'])),
            'customField2' => $cfg->get($keyPrefix . '.customField2', $cfg['transId']),
            'customField3' => $cfg[$keyPrefix . '.customField3'],
            'customField4' => $cfg->get($keyPrefix . '.customField4', sprintf('%s Cart N°%s', $cfg['shopName'], $cfg['cartId'])),
            'customField6' => $cfg[$keyPrefix . '.customField6'],
        ];

        for ($i = 5; $i <= 14; ++$i) {
            if ($val = $cfg->get($keyPrefix . '.customField' . $i)) {
                $data['customField' . $i] = $val;
            }
        }

        return $data;
    }

    public static function _buildJsonMetadataFromCfg($keyPrefix)
    {
        $cfgObj = AxeptaPaygate::getConfiguration();

        // Extraction propre du tableau interne, même si _data est privé
        $reflection = new \ReflectionClass($cfgObj);
        $prop = $reflection->getProperty('_data');
        $prop->setAccessible(true);
        $cfg = $prop->getValue($cfgObj);

        // Filtrer les métadonnées (toutes les clés qui commencent par "metadata.")
        $metadata = array_filter(
            $cfg,
            function ($k) {
                return strpos($k, 'metadata.') === 0;
            },
            ARRAY_FILTER_USE_KEY
        );

        // Ajouter le préfixe aux clés metadata
        $metadataPrefixed = [];
        foreach ($metadata as $k => $v) {
            $metaKey = substr($k, strlen('metadata.'));
            $metadataPrefixed[$metaKey] = $v;
        }

        // Fusionner avec les valeurs par défaut
        return array_merge([
            'operationType' => (string) $cfgObj['operationType'],
            'paymentMode' => (string) $cfgObj['paymentMode'],
            'captureMethod' => (string) $cfgObj['captureMethod'],
            'cartId' => (string) $cfgObj['cartId'],
            'paymentRenderingMode' => (string) $cfgObj['paymentRenderingMode'],
            'saveCard' => (string) $cfgObj->get('saveCard', false),
            'trigram' => (string) $cfgObj->get('trigram', ''),
            'iframe' => (string) ($cfgObj->get('customFields.customField14') == 'iframe'),
        ], $metadataPrefixed);
    }

    private static function _getParamFormatAndValue($paramKey)
    {
        $cfg = AxeptaPaygate::getConfiguration();

        // This code basically maps the configuration values to the param values
        switch ($paramKey) {
            case '$.allowedPaymentMethods':
                return ['JSON', $cfg['allowedPaymentMethods']];
            case '$.amount.value':
                return ['n..10', $cfg['amount.value']];
            case '$.amount.currency':
                return ['a3', $cfg['amount.currency']];
            case '$.billingAddress':
                return ['JSON', self::_buildJsonAddressFromCfg('billingAddress')];
            case '$.browserInfo':
                return ['JSON', '{"todo": "todo"}'];
            case '$.captureMethod':
                return ['an..6', $cfg['captureMethod']];
            case '$.cardHolder.name':
                // TODO: format
                return ['ans..64', $cfg['cardHolder.name']];
            case '$.cardHolder.city':
                // TODO: format
                return ['ans..64', $cfg['cardHolder.city']];
            case '$.customerInfo':
                return ['JSON', self::_buildJsonCustomerInfoFromCfg('customerInfo')];
            case '$.credentialOnFile':
                return ['JSON', self::_buildJsonCofFromCfg()];
            case '$.customFields':
                return ['JSON', self::_buildJsonCustomFieldsFromCfg('customFields')];
            case '$.externalIntegrationId':
                return ['ans..64', $cfg['externalIntegrationId']];
            case '$.finishAuth':
                return ['a1', 'Y'];
            case '$.language':
                return ['a2', $cfg['language']];
            case '$.metadata':
                return ['JSON', self::_buildJsonMetadataFromCfg('metadata')];
            case '$.order.id':
                // TODO: format
                return ['ans..32', $cfg['orderId']];
            case '$.paymentMethods':
                return ['JSON', ParamsValidator::_buildJsonPaymentMethods('paymentMethods')];
            case '$.payment.sofort.sofortAction':
                return ['a5', 'Ident'];
            case '$.payment.paysafecard':
            case '$.payment.hostedPaymentPage.paymentData.paysafecard':
                return ['JSON', ParamsValidator::_buildJsonPaysafeCardFromCfg()];
            case '$.refNr':
                return ['an12', str_pad($cfg['orderReference'], self::MAX_REFNR_LENGTH, '0', STR_PAD_LEFT)];
            case '$.requestId':
                return ['ans..32', sprintf('20%s-%s', strlen($cfg['cartId']), strtoupper($cfg['cartId']))];
            case '$.shipping.address':
                return ['JSON', ParamsValidator::_buildJsonAddressFromCfg('shipping.address')];
            case '$.statementDescriptor':
                return ['ans..256', $cfg['statementDescriptor']];
            case '$.transId':
                return ['ans..64', $cfg['transId']];
            case '$.urls.cancel':
                return ['ans..256', $cfg['urlCancel']];
            case '$.urls.webhook':
                return ['ans..256', $cfg['urlWebhook']];
            case '$.urls.return':
                return ['ans..256', $cfg['urlReturn']];
            case '$.wirecardConnection.refundType':
                // TODO: format
                return ['ans..64', $cfg['wirecardConnection.refundType']];
            case '$.wirecardConnection.receiver.firstName':
                // TODO: format
                return ['ans..64', $cfg['wirecardConnection.receiver.firstName']];
            case '$.wirecardConnection.receiver.lastName':
                // TODO: format
                return ['ans..64', $cfg['wirecardConnection.receiver.lastName']];
            case '$.wirecardConnection.sender.accountNumber':
                // TODO: format
                return ['ans..64', $cfg['wirecardConnection.sender.accountNumber']];
            case '$.wirecardConnection.sender.city':
                // TODO: format
                return ['ans..64', $cfg['wirecardConnection.sender.city']];
            case '$.wirecardConnection.sender.country':
                // TODO: format
                return ['ans..64', $cfg['wirecardConnection.sender.country']];
            case '$.wirecardConnection.sender.firstName':
                // TODO: format
                return ['ans..64', $cfg['wirecardConnection.sender.firstName']];
            case '$.wirecardConnection.sender.lastName':
                // TODO: format
                return ['ans..64', $cfg['wirecardConnection.sender.lastName']];
            case '$.wirecardConnection.sender.street':
                // TODO: format
                return ['ans..64', $cfg['wirecardConnection.sender.street']];
            case '$.wirecardConnection.sender.streetNumber':
                // TODO: format
                return ['ans..64', $cfg['wirecardConnection.sender.streetNumber']];
            default:
                throw new FeatureNotSupportedException("Unknown param key '$paramKey'");
        }
    }

    private static function _handleSpecialCases(&$params)
    {
        // Some params keys/values handle differently so we treat these cases
        // here and override the affected values.
        // They can have quirks or incorrect documentation.
        $cfg = AxeptaPaygate::getConfiguration();

        if (array_key_exists('$.captureMethod', $params)) {
            switch ($params['$.captureMethod']) {
                case CaptureMode::AUTO:
                    $params['$.captureMethod'] = ['type' => 'AUTOMATIC'];
                    break;
                case CaptureMode::MANUAL:
                    $params['$.captureMethod'] = ['type' => 'MANUAL'];
                    break;
                default:
                    $params['$.captureMethod'] = [
                        'type' => 'DELAYED',
                        'delayed' => ['delayedHours' => $params['$.captureMethod']],
                    ];
            }
        }

        if (array_key_exists('$.customFields', $params)) {
            if ($cfg['paymentRenderingMode'] == PaymentRenderingMode::HPP) {
                $params['$.template.customFields'] = $params['$.customFields'];
            } elseif ($cfg['paymentRenderingMode'] == PaymentRenderingMode::REDIRECT) {
                $params['$.paymentMethods.card.template.customFields'] = $params['$.customFields'];
            }

            unset($params['$.customFields']);
        }
    }
}
