<?php

// Define the base directory for the library
$baseDir = __DIR__ . '/';

// Simple autoloader function
spl_autoload_register(function ($class) use ($baseDir) {
    // Convert the namespace to the file path
    $file = $baseDir . str_replace('\\', '/', $class) . '.php';

    // Check if the file exists and include it
    if (file_exists($file)) {
        require_once $file;
    }
});
