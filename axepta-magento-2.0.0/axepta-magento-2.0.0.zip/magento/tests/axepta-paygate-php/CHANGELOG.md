# Changelog

Ce format est une version adaptée de [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) pour We+.


## [1.1.1] - 2019-03-02

### Réparé

- Description en langage naturel (#12345)


## [1.1.0] - 2019-02-15

### Ajouté

- Description en langage naturel (#12345)
- Description en langage naturel (#12345)

### Changé

- Description en langage naturel (#12345)
- Description en langage naturel (#12345)
- Description en langage naturel (#12345)

### Déprécié

- Description en langage naturel (#12345)

### Réparé

- Description en langage naturel (#12345)

### Supprimé

- Description en langage naturel (#12345)

### Sécurité

- Description en langage naturel (#12345)
- Description en langage naturel (#12345)
