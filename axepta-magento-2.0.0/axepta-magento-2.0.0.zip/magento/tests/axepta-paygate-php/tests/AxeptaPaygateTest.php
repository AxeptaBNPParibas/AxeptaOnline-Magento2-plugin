<?php

declare(strict_types=1);

namespace AxeptaPaygate\Tests;

use AxeptaPaygate\Api\OAuth2Api;
use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\CaptureMode;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentMode;
use AxeptaPaygate\Core\PaymentRenderingMode;
use AxeptaPaygate\Utils;
use PHPUnit\Framework\TestCase;

class CustomTestCase extends TestCase
{
    protected static $merchantId;
    protected static $apiKey;
    protected static $accessToken;
    protected static $paymentMode;

    public static function setUpBeforeClass(): void
    {
        self::assertNotFalse(self::$merchantId = getenv('MERCHANT_ID'), 'The MERCHANT_ID env var is not set');
        self::assertNotFalse(self::$apiKey = getenv('API_KEY'), 'The API_KEY env var is not set');

        self::$paymentMode = PaymentMode::TEST;
        if (self::$merchantId == 'BNP_AXE_STD_DEMO') {
            self::$paymentMode = PaymentMode::DEMO;
        }

        self::$accessToken = OAuth2Api::getAccessToken(self::$merchantId, self::$apiKey, self::$paymentMode)['access_token'];
    }

    public static function assertArrayHasNestedKeys(string $dotSeparatedKeys, array $array)
    {
        $keys = explode('.', $dotSeparatedKeys);
        $currentArray = $array;
        foreach ($keys as $key) {
            self::assertArrayHasKey($key, $currentArray);
            $currentArray = $currentArray[$key];
        }
    }

    public static function performDirectPayment(string $trigram, bool $saveCard = false, bool $initializeSubscription = false, bool $captureManual = true, bool $shouldCapture = false)
    {
        $configuration = [
            'amount.value' => '1234',
            'amount.currency' => 'EUR',
            'api_access_token' => self::$accessToken,
            'cartId' => Utils::randomString(),
            'captureMethod' => $captureManual ? CaptureMode::MANUAL : CaptureMode::AUTO,
            'customerInfo.firstName' => 'John',
            'customerInfo.lastName' => 'DOE',
            'externalIntegrationId' => 'LIB_VERSION_WE_MODULEVERSION',
            'initializeSubscription' => $initializeSubscription,
            'iso2CountryCode' => 'FR',
            'operationType' => OperationType::SIMPLE_PAYMENT,
            'orderReference' => '1234567890',
            'paymentMode' => self::$paymentMode,
            'paymentRenderingMode' => PaymentRenderingMode::DIRECT,
            'saveCard' => $saveCard,
            'shopName' => 'My Test Shop',
            'statementDescriptor' => 'My Test Shop',
            'transId' => '123456789',
            'trigram' => $trigram,
            'paymentMethods.card.brand' => 'VISA',
            'paymentMethods.card.expiryDate' => '203506',
            'paymentMethods.card.number' => '4111111111111111',
            'paymentMethods.card.cardHolderName' => 'John DOE',
        ];

        // Special parameters for initial payment recurring
        if ($initializeSubscription) {
            $configuration['recurring.frequency'] = 'DAILY'; // TODO : check ENUM "DAILY" "WEEKLY" "MONTHLY" "YEARLY"
            // $configuration['recurring.startDate'] = ''; // NOT REQUIRED
            $configuration['recurring.expiryDate'] = (new \DateTime())->modify('+10 days')->format('Y-m-d');
            // $configuration['recurring.useCase'] = 'FIXED'; // FIXED per default
        }

        AxeptaPaygate::init($configuration);

        $operation = AxeptaPaygate::buildOperation();
        $request = $operation['request'];
        $response = $request->call();
        $payment = json_decode($response, true);

        self::assertArrayHasKey('responseCode', $payment);
        self::assertEquals('00000000', $payment['responseCode']);
        self::assertArrayHasKey('payId', $payment);
        self::assertArrayHasKey('card', $payment['paymentMethods']);

        if ($captureManual && $shouldCapture) {
            self::capturePayment($payment['payId']);
        }

        return $payment;
    }

    protected static function capturePayment(string $paymentId)
    {
        $paymentDetails = AxeptaPaygate::getPaymentDetails(self::$accessToken, $paymentId);

        $configuration = [
            'amount.value' => $paymentDetails['amount']['value'],
            'amount.currency' => $paymentDetails['amount']['currency'],
            'api_access_token' => self::$accessToken,
            'iso2CountryCode' => 'FR',
            'operationType' => OperationType::CAPTURE_PAYMENT,
            'paymentId' => $paymentId,
            'paymentMode' => self::$paymentMode,
            'transId' => $paymentDetails['transId'],
        ];

        AxeptaPaygate::init($configuration);

        $operation = AxeptaPaygate::buildOperation();

        $request = $operation['request'];
        $response = $request->call();
        $json = json_decode($response, true);

        self::assertArrayHasKey('responseCode', $json);
        self::assertEquals('00000000', $json['responseCode']);
    }

    protected function setUp(): void
    {
        parent::setUp();

        // error_reporting(E_ALL);

        // Reset the configuration before each test
        AxeptaPaygate::reset();
    }
}

class AxeptaPaygateTest extends CustomTestCase
{
    public function testDummy()
    {
        $this->markTestSkipped();
    }
}
