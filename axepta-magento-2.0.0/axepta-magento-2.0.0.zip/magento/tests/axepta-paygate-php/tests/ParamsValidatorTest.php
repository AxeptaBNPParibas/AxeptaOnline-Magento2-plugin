<?php

declare(strict_types=1);

namespace AxeptaPaygate\Tests;

use AxeptaPaygate\Exception\ParamsValidationException;
use AxeptaPaygate\ParamsValidator;

class ParamsValidatorTest extends CustomTestCase
{
    public function testValidateParamsWithValidParams()
    {
        $this->markTestSkipped();
        // TODO:
        // ParamsValidator::validateParams([]);
    }

    public function testValidateParamsWithInvalidParams()
    {
        $this->markTestSkipped();
        // TODO:
        // ParamsValidator::validateParams([]);
        // $this->expectException(ParamsValidationException::class);
    }

    public function testValidateFormat()
    {
        // Check alphabetic with fixed length
        $this->assertTrue(ParamsValidator::validateFormat('a6', 'abcdef'));
        $this->assertFalse(ParamsValidator::validateFormat('a6', '123'));
        // Check numeric with fixed length
        $this->assertTrue(ParamsValidator::validateFormat('n6', '123456'));
        $this->assertFalse(ParamsValidator::validateFormat('n6', 'abcdef'));
        // Check alphanumeric with fixed length
        $this->assertTrue(ParamsValidator::validateFormat('an6', 'abc123'));
        $this->assertFalse(ParamsValidator::validateFormat('an6', 'abc12*'));
        // Check alphanumeric with special characters with fixed length
        $this->assertTrue(ParamsValidator::validateFormat('ans6', 'abc12*'));
        // $this->assertFalse(ParamsValidator::validateFormat('ans6', 'abc12*')); // no case

        // Check alphabetic with maximum length
        $this->assertTrue(ParamsValidator::validateFormat('a..6', 'abcde'));
        $this->assertFalse(ParamsValidator::validateFormat('a..6', 'abcdefg'));
        // Check numeric with maximum length
        $this->assertTrue(ParamsValidator::validateFormat('n..6', '12345'));
        $this->assertFalse(ParamsValidator::validateFormat('n..6', '1234567'));
        // Check alphanumeric with maximum length
        $this->assertTrue(ParamsValidator::validateFormat('an..6', 'abc12'));
        $this->assertFalse(ParamsValidator::validateFormat('an..6', 'abc1234'));
        // Check alphanumeric with special characters with maximum length
        $this->assertTrue(ParamsValidator::validateFormat('ans..6', 'abc1*'));
        // $this->assertFalse(ParamsValidator::validateFormat('ans..6', 'abc1*'));

        // Check JSON
        $this->assertTrue(ParamsValidator::validateFormat('JSON', '{"key":"value"}'));
        // $this->assertFalse(ParamsValidator::validateFormat('JSON', 'incorrect value'));

        // Check empty value
        $this->assertFalse(ParamsValidator::validateFormat('a6', ''));
    }
}
