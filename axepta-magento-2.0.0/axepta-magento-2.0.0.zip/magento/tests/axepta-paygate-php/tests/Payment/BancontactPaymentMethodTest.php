<?php

declare(strict_types=1);

namespace AxeptaPaygate\Tests;

use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\CaptureMode;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentMode;
use AxeptaPaygate\Core\PaymentRenderingMode;
use AxeptaPaygate\Utils;

class BancontactPaymentMethodTest extends CustomTestCase
{
    public function testSimplePaymentInHppMode()
    {
        [$prefilledConfiguration, $actualMissingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys(null, OperationType::SIMPLE_PAYMENT, PaymentRenderingMode::HPP);
        $expectedMissingConfigurationKeys = [
            'amount.value',
            'amount.currency',
            'api_access_token',
            'billing.addressInfo.addressLine1.street',
            'billing.addressInfo.city',
            'billing.addressInfo.country.countryA2',
            'billing.addressInfo.country.countryA3',
            'billing.consumer.firstName',
            'billing.consumer.lastName',
            'cartId',
            'capture',
            'customFields.customField3',
            'customFields.customField6',
            'iso2CountryCode',
            'orderId',
            'orderReference',
            'paymentMode',
            'shipping.addressInfo.addressLine1.street',
            'shipping.addressInfo.city',
            'shipping.addressInfo.country.countryA2',
            'shipping.addressInfo.country.countryA3',
            'shipping.consumer.firstName',
            'shipping.consumer.lastName',
            'shopName',
            'transactionId',
            'urlCancel',
            'urlFailure',
            'urlNotify',
            'urlSuccess',
        ];
        self::assertEqualsCanonicalizing($expectedMissingConfigurationKeys, $actualMissingConfigurationKeys);

        $configuration = [
            'amount.value' => '1234',
            'amount.currency' => 'EUR',
            'api_access_token' => self::$accessToken,
            'billing.addressInfo.addressLine1.street' => 'rue du Test',
            'billing.addressInfo.addressLine1.streetNumber' => '1',
            'billing.addressInfo.city' => 'Testville',
            'billing.addressInfo.country.countryA2' => 'FR',
            'billing.addressInfo.country.countryA3' => 'FRA',
            'billing.addressInfo.postalCode' => '12345',
            'billing.consumer.firstName' => 'John',
            'billing.consumer.lastName' => 'Doe',
            'billing.contactInfo.email' => 'john.doe@example.net',
            'cartId' => Utils::randomString(),
            'capture' => CaptureMode::AUTO,
            'customFields.customField3' => 'https://www.example.com/logo.png',
            'customFields.customField6' => 'shipping info',
            'iso2CountryCode' => 'FR',
            'operationType' => OperationType::SIMPLE_PAYMENT,
            'orderId' => '1234567890-1234567890',
            'orderReference' => '1234567890',
            // TODO: should be PaymentMode::TEST
            'paymentMode' => PaymentMode::DEMO,
            'paymentRenderingMode' => PaymentRenderingMode::HPP,
            'shipping.addressInfo.addressLine1.street' => 'rue du Test',
            'shipping.addressInfo.addressLine1.streetNumber' => '2',
            'shipping.addressInfo.city' => 'Testville',
            'shipping.addressInfo.country.countryA2' => 'FR',
            'shipping.addressInfo.country.countryA3' => 'FRA',
            'shipping.addressInfo.postalCode' => '12345',
            'shipping.consumer.firstName' => 'Jane',
            'shipping.consumer.lastName' => 'Doe',
            'shipping.contactInfo.email' => 'jane.doe@example.net',
            'shopName' => 'My Test Shop',
            'transactionId' => '123456789',
            'urlCancel' => Utils::getEnv('URL_SUCCESS', 'https://www.example.com/cancel'),
            'urlFailure' => Utils::getEnv('URL_FAILURE', 'https://www.example.com/failure'),
            'urlNotify' => Utils::getEnv('URL_NOTIFY', 'https://www.example.com/notify'),
            'urlSuccess' => Utils::getEnv('URL_SUCCESS', 'https://www.example.com/success'),
        ];

        // TODO:
        // Bancontact special params
        $configuration['payTypes'] = ['BanconPP'];

        AxeptaPaygate::init($configuration);

        $operation = AxeptaPaygate::buildOperation();

        $this->assertIsArray($operation);
        $this->assertArrayHasKey('request', $operation);
        $this->assertArrayHasKey('params', $operation);

        $params = $operation['params'];

        $this->assertArrayHasNestedKeys('amount.currency', $params);
        $this->assertArrayHasNestedKeys('amount.value', $params);
        $this->assertArrayHasNestedKeys('billing.addressInfo', $params);
        $this->assertArrayHasNestedKeys('capture.auto', $params);
        $this->assertArrayHasNestedKeys('metadata.userData', $params);
        $this->assertArrayHasNestedKeys('order.description', $params);
        $this->assertArrayHasNestedKeys('payment.method', $params);
        $this->assertArrayHasNestedKeys('payment.hostedPaymentPage.accountVerification', $params);
        $this->assertArrayHasKey('referenceNumber', $params);
        $this->assertArrayHasKey('requestId', $params);
        $this->assertArrayHasNestedKeys('shipping.addressInfo', $params);
        $this->assertArrayHasKey('transactionId', $params);
        $this->assertArrayHasNestedKeys('urls.cancel', $params);
        $this->assertArrayHasNestedKeys('urls.failure', $params);
        $this->assertArrayHasNestedKeys('urls.notify', $params);
        $this->assertArrayHasNestedKeys('customFields.customField1', $params);
        $this->assertArrayHasNestedKeys('customFields.customField2', $params);
        $this->assertArrayHasNestedKeys('customFields.customField3', $params);
        $this->assertArrayHasNestedKeys('customFields.customField4', $params);
        $this->assertArrayHasNestedKeys('customFields.customField6', $params);

        $request = $operation['request'];
        $response = $request->call();
        $json = json_decode($response, true);
        $this->assertIsString($json['_Links']['redirect']['href']);
    }

    public function testPaymentRefund()
    {
        // TODO: cannot test, since we need to perform a direct payment first
        $this->markTestSkipped();
    }
}
