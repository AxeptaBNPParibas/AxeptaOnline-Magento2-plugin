<?php

declare(strict_types=1);

namespace AxeptaPaygate\Tests;

use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\CaptureMode;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentMode;
use AxeptaPaygate\Core\PaymentRenderingMode;
use AxeptaPaygate\Utils;

class PaypalPaymentMethodTest extends CustomTestCase
{
    public function testSimplePaymentInRedirectMode()
    {
        [$prefilledConfiguration, $actualMissingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys('pal', OperationType::SIMPLE_PAYMENT, PaymentRenderingMode::REDIRECT);
        $expectedMissingConfigurationKeys = [
            'amount.value',
            'amount.currency',
            'api_access_token',
            'billingAddress.city',
            'billingAddress.country',
            'billingAddress.postalCode',
            'billingAddress.streetName',
            'billingAddress.streetNumber',
            'cartId',
            'captureMethod',
            'customerInfo.firstName',
            'customerInfo.lastName',
            'externalIntegrationId',
            'language',
            'orderReference',
            'paymentMode',
            'shipping.address.city',
            'shipping.address.country',
            'shipping.address.postalCode',
            'shipping.address.streetName',
            'shipping.address.streetNumber',
            'statementDescriptor',
            'transId',
            'urlCancel',
            'urlReturn',
            'urlWebhook',
        ];
        self::assertEqualsCanonicalizing($expectedMissingConfigurationKeys, $actualMissingConfigurationKeys);

        $configuration = [
            'amount.value' => '1234',
            'amount.currency' => 'EUR',
            'api_access_token' => self::$accessToken,
            'billingAddress.city' => 'Testville',
            'billingAddress.country' => 'FRA',
            'billingAddress.postalCode' => '12345',
            'billingAddress.streetName' => 'rue du Test',
            'billingAddress.streetNumber' => '1',
            'cartId' => Utils::randomString(),
            'captureMethod' => CaptureMode::AUTO,
            'customerInfo.merchantCustomerId' => '999',
            'customerInfo.firstName' => 'Max',
            'customerInfo.lastName' => 'Mustermann',
            'customerInfo.email' => 'customer@example.com',
            'customerInfo.phone.countryCode' => '+49',
            'customerInfo.phone.number' => '1236547890',
            'customerInfo.salutation' => 'Miss',
            'customerInfo.gender' => 'female',
            'customerInfo.birthDate' => '2001-01-01',
            'externalIntegrationId' => 'LIB_VERSION_WE_MODULEVERSION',
            'iso2CountryCode' => 'FR',
            'language' => 'fr',
            'operationType' => OperationType::SIMPLE_PAYMENT,
            'orderId' => '1234567890-1234567890',
            'orderReference' => str_pad((string) mt_rand(0, 9999999999), 10, '0', STR_PAD_LEFT), // ! With paypal, refnr is checked (responseCode: 20170032),
            'paymentMode' => self::$paymentMode,
            'paymentRenderingMode' => PaymentRenderingMode::REDIRECT,
            'shipping.address.city' => 'Testville',
            'shipping.address.country' => 'FRA',
            'shipping.address.postalCode' => '12345',
            'shipping.address.streetName' => 'rue du Test',
            'shipping.address.streetNumber' => '1',
            'shopName' => 'My Test Shop',
            'statementDescriptor' => 'My Test Shop',
            'transId' => '123456789',
            'trigram' => 'pal',
            'urlCancel' => Utils::getEnv('URL_SUCCESS', 'https://www.example.com/cancel'),
            'urlWebhook' => Utils::getEnv('URL_NOTIFY', 'https://www.example.com/notify'),
            'urlReturn' => Utils::getEnv('URL_SUCCESS', 'https://www.example.com/success'),
        ];
        AxeptaPaygate::init($configuration);

        $operation = AxeptaPaygate::buildOperation();

        $this->assertIsArray($operation);
        $this->assertArrayHasKey('request', $operation);
        $this->assertArrayHasKey('params', $operation);

        $params = $operation['params'];

        $this->assertArrayHasNestedKeys('amount.currency', $params);
        $this->assertArrayHasNestedKeys('amount.value', $params);
        $this->assertArrayHasKey('billingAddress', $params);
        $this->assertArrayHasNestedKeys('captureMethod.type', $params);
        $this->assertArrayHasNestedKeys('customerInfo.firstName', $params);
        $this->assertArrayHasNestedKeys('customerInfo.lastName', $params);
        $this->assertArrayHasKey('externalIntegrationId', $params);
        $this->assertArrayHasKey('language', $params);
        $this->assertArrayHasNestedKeys('paymentMethods.integrationType', $params);
        $this->assertArrayHasNestedKeys('paymentMethods.type', $params);
        $this->assertArrayHasKey('refNr', $params);
        $this->assertArrayHasKey('requestId', $params);
        $this->assertArrayHasNestedKeys('shipping.address', $params);
        $this->assertArrayHasKey('statementDescriptor', $params);
        $this->assertArrayHasKey('transId', $params);
        $this->assertArrayHasNestedKeys('billingAddress', $params);
        $this->assertArrayHasNestedKeys('shipping.address', $params);
        $this->assertArrayHasNestedKeys('urls.cancel', $params);
        $this->assertArrayHasNestedKeys('urls.return', $params);
        $this->assertArrayHasNestedKeys('urls.webhook', $params);

        $request = $operation['request'];
        $response = $request->call();
        $json = json_decode($response, true);
        $this->assertIsString($json['_links']['redirect']['href']);
    }

    public function testSimplePaymentInHppMode()
    {
        [$prefilledConfiguration, $actualMissingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys(null, OperationType::SIMPLE_PAYMENT, PaymentRenderingMode::HPP);
        $expectedMissingConfigurationKeys = [
            'amount.value',
            'amount.currency',
            'api_access_token',
            'billingAddress.city',
            'billingAddress.country',
            'billingAddress.postalCode',
            'billingAddress.streetName',
            'billingAddress.streetNumber',
            'cartId',
            'captureMethod',
            'customerInfo.firstName',
            'customerInfo.lastName',
            'customFields.customField3',
            'customFields.customField6',
            'externalIntegrationId',
            'language',
            'orderReference',
            'paymentMode',
            'shipping.address.city',
            'shipping.address.country',
            'shipping.address.postalCode',
            'shipping.address.streetName',
            'shipping.address.streetNumber',
            'shopName',
            'statementDescriptor',
            'transId',
            'urlCancel',
            'urlWebhook',
            'urlReturn',
        ];
        self::assertEqualsCanonicalizing($expectedMissingConfigurationKeys, $actualMissingConfigurationKeys);

        $configuration = [
            'amount.value' => '1234',
            'amount.currency' => 'EUR',
            'api_access_token' => self::$accessToken,
            'billingAddress.city' => 'Testville',
            'billingAddress.country' => 'FRA',
            'billingAddress.postalCode' => '12345',
            'billingAddress.streetName' => 'rue du Test',
            'billingAddress.streetNumber' => '1',
            'billing.contactInfo.email' => 'john.doe@example.net',
            'cartId' => Utils::randomString(),
            'captureMethod' => CaptureMode::MANUAL,
            'customerInfo.firstName' => 'John',
            'customerInfo.lastName' => 'Doe',
            'customFields.customField3' => 'https://www.example.com/logo.png',
            'customFields.customField6' => 'shipping info',
            'externalIntegrationId' => 'LIB_VERSION_WE_MODULEVERSION',
            'iso2CountryCode' => 'FR',
            'language' => 'fr',
            'operationType' => OperationType::SIMPLE_PAYMENT,
            'orderId' => '1234567890-1234567890',
            'orderReference' => str_pad((string) mt_rand(0, 9999999999), 10, '0', STR_PAD_LEFT), // ! With paypal, refnr is checked (responseCode: 20170032)
            // TODO: should be PaymentMode::TEST
            'paymentMode' => self::$paymentMode,
            'paymentRenderingMode' => PaymentRenderingMode::HPP,
            'shipping.address.city' => 'Bamberg',
            'shipping.address.country' => 'DEU',
            'shipping.address.postalCode' => '96050',
            'shipping.address.streetName' => 'Schwarzenbergstr',
            'shipping.address.streetNumber' => '4',
            'shipping.consumer.firstName' => 'Jane',
            'shipping.consumer.lastName' => 'Doe',
            'shipping.contactInfo.email' => 'jane.doe@example.net',
            'shopName' => 'My Test Shop',
            'statementDescriptor' => 'My Test Shop',
            'transId' => '123456789',
            'urlCancel' => Utils::getEnv('URL_SUCCESS', 'https://www.example.com/cancel'),
            'urlWebhook' => Utils::getEnv('URL_NOTIFY', 'https://www.example.com/notify'),
            'urlReturn' => Utils::getEnv('URL_SUCCESS', 'https://www.example.com/success'),
        ];
        AxeptaPaygate::init($configuration);

        $operation = AxeptaPaygate::buildOperation();

        $this->assertIsArray($operation);
        $this->assertArrayHasKey('request', $operation);
        $this->assertArrayHasKey('params', $operation);

        $params = $operation['params'];

        $this->assertArrayHasNestedKeys('amount.currency', $params);
        $this->assertArrayHasNestedKeys('amount.value', $params);
        $this->assertArrayHasNestedKeys('billingAddress', $params);
        $this->assertArrayHasNestedKeys('captureMethod.type', $params);
        $this->assertArrayHasNestedKeys('customerInfo.firstName', $params);
        $this->assertArrayHasNestedKeys('customerInfo.lastName', $params);
        $this->assertArrayHasKey('externalIntegrationId', $params);
        $this->assertArrayHasKey('language', $params);
        $this->assertArrayHasKey('refNr', $params);
        $this->assertArrayHasKey('requestId', $params);
        $this->assertArrayHasNestedKeys('shipping.address', $params);
        $this->assertArrayHasKey('statementDescriptor', $params);
        $this->assertArrayHasKey('transId', $params);
        $this->assertArrayHasNestedKeys('urls.cancel', $params);
        $this->assertArrayHasNestedKeys('urls.webhook', $params);
        $this->assertArrayHasNestedKeys('urls.return', $params);
        $this->assertArrayHasNestedKeys('template.customFields', $params);
        $this->assertArrayHasNestedKeys('template.customFields.customField3', $params);
        $this->assertArrayHasNestedKeys('template.customFields.customField6', $params);

        $request = $operation['request'];
        $response = $request->call();
        $json = json_decode($response, true);
        $this->assertIsString($json['_links']['redirect']['href']);
    }

    // public function testPaymentSubscription()
    // {
    //     // TODO:
    // }

    /* Non testable automatiquement */
    // public function testPaymentRefund()
    // {
    //     // ! Manually pay once via HPP or Hosted
    //     $paymentId = '0230d8c138224a05aed52edb5635d381';
    //     $paymentDetails = AxeptaPaygate::getPaymentDetails(self::$accessToken, $paymentId);

    //     [$prefilledConfiguration, $actualMissingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys('pal', OperationType::PAYMENT_REFUND);
    //     $expectedMissingConfigurationKeys = [
    //         'amount.currency',
    //         'amount.value',
    //         'api_access_token',
    //         'iso2CountryCode',
    //         'orderReference',
    //         'paymentMode',
    //         'paymentId',
    //         'transId',
    //     ];
    //     self::assertEqualsCanonicalizing($expectedMissingConfigurationKeys, $actualMissingConfigurationKeys);

    //     $configuration = [
    //         'amount.value' => $paymentDetails['amount']['value'],
    //         'amount.currency' => $paymentDetails['amount']['currency'],
    //         'api_access_token' => self::$accessToken,
    //         'iso2CountryCode' => 'FR',
    //         'operationType' => OperationType::PAYMENT_REFUND,
    //         'orderReference' => $paymentDetails['refNr'],
    //         // TODO: should be PaymentMode::TEST
    //         'paymentId' => $paymentId,
    //         'paymentMode' => self::$paymentMode,
    //         'transId' => $paymentDetails['transId'],
    //         'trigram' => 'pal',
    //     ];
    //     AxeptaPaygate::init($configuration);

    //     $operation = AxeptaPaygate::buildOperation();

    //     $this->assertIsArray($operation);
    //     $this->assertArrayHasKey('request', $operation);
    //     $this->assertArrayHasKey('params', $operation);

    //     $params = $operation['params'];

    //     $this->assertArrayHasNestedKeys('amount.currency', $params);
    //     $this->assertArrayHasNestedKeys('amount.value', $params);
    //     $this->assertArrayHasKey('refNr', $params);
    //     $this->assertArrayHasKey('transId', $params);

    //     $request = $operation['request'];
    //     $response = $request->call();
    //     $json = json_decode($response, true);
    //     self::assertArrayHasKey('responseCode', $json);
    //     self::assertEquals('00000000', $json['responseCode']);
    // }

    /* Non testable automatiquement */
    // public function testPaymentReversal()
    // {
    //     // ! Manually pay once via HPP or Hosted
    //     // ! change captureMethod on Manual

    //     $paymentId = '2d7625e42d9e4af3b6f0b3851b109146';

    //     $paymentDetails = AxeptaPaygate::getPaymentDetails(self::$accessToken, $paymentId);

    //     [$prefilledConfiguration, $actualMissingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys('pal', OperationType::PAYMENT_REVERSAL);
    //     $expectedMissingConfigurationKeys = [
    //         'amount.currency',
    //         'amount.value',
    //         'api_access_token',
    //         'iso2CountryCode',
    //         'orderReference',
    //         'paymentMode',
    //         'paymentId',
    //         'transId',
    //     ];
    //     self::assertEqualsCanonicalizing($expectedMissingConfigurationKeys, $actualMissingConfigurationKeys);

    //     $configuration = [
    //         'amount.value' => $paymentDetails['amount']['value'],
    //         'amount.currency' => $paymentDetails['amount']['currency'],
    //         'api_access_token' => self::$accessToken,
    //         'iso2CountryCode' => 'FR',
    //         'operationType' => OperationType::PAYMENT_REVERSAL,
    //         'orderReference' => $paymentDetails['refNr'],
    //         // TODO: should be PaymentMode::TEST
    //         'paymentId' => $paymentId,
    //         'paymentMode' => self::$paymentMode,
    //         'transId' => $paymentDetails['transId'],
    //         'trigram' => 'pal',
    //     ];
    //     AxeptaPaygate::init($configuration);

    //     $operation = AxeptaPaygate::buildOperation();

    //     $this->assertIsArray($operation);
    //     $this->assertArrayHasKey('request', $operation);
    //     $this->assertArrayHasKey('params', $operation);

    //     $params = $operation['params'];

    //     $this->assertArrayHasNestedKeys('amount.currency', $params);
    //     $this->assertArrayHasNestedKeys('amount.value', $params);
    //     $this->assertArrayHasKey('refNr', $params);
    //     $this->assertArrayHasKey('transId', $params);

    //     $request = $operation['request'];
    //     $response = $request->call();

    //     $json = json_decode($response, true);
    //     self::assertArrayHasKey('responseCode', $json);
    //     self::assertEquals('00000000', $json['responseCode']);
    // }
}
