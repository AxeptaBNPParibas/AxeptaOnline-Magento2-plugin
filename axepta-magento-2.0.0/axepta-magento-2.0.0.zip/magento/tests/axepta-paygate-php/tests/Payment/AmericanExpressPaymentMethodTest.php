<?php

declare(strict_types=1);

namespace AxeptaPaygate\Tests;

use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\CaptureMode;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Core\PaymentMode;
use AxeptaPaygate\Core\PaymentRenderingMode;
use AxeptaPaygate\Utils;

class AmericanExpressPaymentMethodTest extends CustomTestCase
{
    public function testSimplePaymentInRedirectMode()
    {
        [$prefilledConfiguration, $actualMissingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys('amx', OperationType::SIMPLE_PAYMENT, PaymentRenderingMode::REDIRECT);
        $expectedMissingConfigurationKeys = [
            'amount.value',
            'amount.currency',
            'api_access_token',
            'billingAddress.city',
            'billingAddress.country',
            'billingAddress.postalCode',
            'billingAddress.streetName',
            'billingAddress.streetNumber',
            'cartId',
            'captureMethod',
            'customerInfo.firstName',
            'customerInfo.lastName',
            'customFields.customField3',
            'customFields.customField6',
            'externalIntegrationId',
            'language',
            'orderReference',
            'paymentMode',
            'shipping.address.city',
            'shipping.address.country',
            'shipping.address.postalCode',
            'shipping.address.streetName',
            'shipping.address.streetNumber',
            'shopName',
            'statementDescriptor',
            'transId',
            'urlCancel',
            'urlReturn',
            'urlWebhook',
        ];
        self::assertEqualsCanonicalizing($expectedMissingConfigurationKeys, $actualMissingConfigurationKeys);

        $configuration = [
            'amount.value' => '1234',
            'amount.currency' => 'EUR',
            'api_access_token' => self::$accessToken,
            'billingAddress.city' => 'Testville',
            'billingAddress.country' => 'FRA',
            'billingAddress.postalCode' => '12345',
            'billingAddress.streetName' => 'rue du Test',
            'billingAddress.streetNumber' => '1',
            'cartId' => Utils::randomString(),
            'captureMethod' => CaptureMode::AUTO,
            'customerInfo.merchantCustomerId' => '999',
            'customerInfo.customerType' => 'individual',
            'customerInfo.firstName' => 'Max',
            'customerInfo.lastName' => 'Mustermann',
            'customerInfo.email' => 'customer@example.com',
            'customerInfo.phone.countryCode' => '+49',
            'customerInfo.phone.number' => '1236547890',
            'customerInfo.salutation' => 'Ms',
            'customerInfo.title' => 'Dr',
            'customerInfo.gender' => 'female',
            'customerInfo.maidenName' => 'Mustermann',
            'customerInfo.middleName' => 'sam',
            'customerInfo.birthDate' => '2001-01-01',
            'customerInfo.birthPlace' => 'Bamberg',
            'customerInfo.socialSecurityNumber' => '123443534',
            'externalIntegrationId' => 'LIB_VERSION_WE_MODULEVERSION',
            'iso2CountryCode' => 'FR',
            'language' => 'fr',
            'operationType' => OperationType::SIMPLE_PAYMENT,
            'orderId' => '1234567890-1234567890',
            'orderReference' => '1234567890',
            'paymentMode' => PaymentMode::TEST,
            'customFields.customField1' => '9999 EUR',
            'customFields.customField2' => null,
            'customFields.customField3' => 'https://www.example.com/logo.png',
            'customFields.customField6' => 'shipping info',
            'paymentRenderingMode' => PaymentRenderingMode::REDIRECT,
            'shopName' => 'My Test Shop',
            'shipping.address.city' => 'Testville',
            'shipping.address.country' => 'FRA',
            'shipping.address.postalCode' => '12345',
            'shipping.address.streetName' => 'rue du Test',
            'shipping.address.streetNumber' => '1',
            'statementDescriptor' => 'My Test Shop',
            'transId' => '123456789',
            'urlCancel' => Utils::getEnv('URL_SUCCESS', 'https://www.example.com/cancel'),
            'urlWebhook' => Utils::getEnv('URL_NOTIFY', 'https://www.example.com/notify'),
            'urlReturn' => Utils::getEnv('URL_SUCCESS', 'https://www.example.com/success'),
        ];

        // Special AMEX params
        $configuration['trigram'] = 'amx';

        AxeptaPaygate::init($configuration);

        $operation = AxeptaPaygate::buildOperation();

        $this->assertIsArray($operation);
        $this->assertArrayHasKey('request', $operation);
        $this->assertArrayHasKey('params', $operation);

        $params = $operation['params'];

        $this->assertArrayHasNestedKeys('amount.currency', $params);
        $this->assertArrayHasNestedKeys('amount.value', $params);
        $this->assertArrayHasNestedKeys('billingAddress', $params);
        $this->assertArrayHasNestedKeys('captureMethod.type', $params);
        $this->assertArrayHasKey('externalIntegrationId', $params);
        $this->assertArrayHasNestedKeys('paymentMethods', $params);
        $this->assertArrayHasNestedKeys('paymentMethods.card.template', $params);
        $this->assertArrayHasKey('refNr', $params);
        $this->assertArrayHasKey('requestId', $params);
        $this->assertArrayHasNestedKeys('shipping.address', $params);
        $this->assertArrayHasKey('transId', $params);
        $this->assertArrayHasNestedKeys('urls.cancel', $params);
        $this->assertArrayHasNestedKeys('urls.return', $params);
        $this->assertArrayHasNestedKeys('urls.webhook', $params);

        $request = $operation['request'];
        $response = $request->call();
        $json = json_decode($response, true);
        $this->assertIsString($json['_links']['redirect']['href']);
    }

    public function testSimplePaymentInHppMode()
    {
        [$prefilledConfiguration, $actualMissingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys(null, OperationType::SIMPLE_PAYMENT, PaymentRenderingMode::HPP);
        $expectedMissingConfigurationKeys = [
            'amount.value',
            'amount.currency',
            'api_access_token',
            'billingAddress.city',
            'billingAddress.country',
            'billingAddress.postalCode',
            'billingAddress.streetName',
            'billingAddress.streetNumber',
            'cartId',
            'captureMethod',
            'customerInfo.firstName',
            'customerInfo.lastName',
            'customFields.customField3',
            'customFields.customField6',
            'externalIntegrationId',
            'language',
            'orderReference',
            'paymentMode',
            'shipping.address.city',
            'shipping.address.country',
            'shipping.address.postalCode',
            'shipping.address.streetName',
            'shipping.address.streetNumber',
            'shopName',
            'statementDescriptor',
            'transId',
            'urlCancel',
            'urlWebhook',
            'urlReturn',
        ];
        self::assertEqualsCanonicalizing($expectedMissingConfigurationKeys, $actualMissingConfigurationKeys);

        $configuration = [
            'amount.value' => '1234',
            'amount.currency' => 'EUR',
            'api_access_token' => self::$accessToken,
            'billingAddress.city' => 'Testville',
            'billingAddress.country' => 'FRA',
            'billingAddress.postalCode' => '12345',
            'billingAddress.streetName' => 'rue du Test',
            'billingAddress.streetNumber' => '1',
            'billing.contactInfo.email' => 'john.doe@example.net',
            'cartId' => Utils::randomString(),
            'captureMethod' => CaptureMode::AUTO,
            'customerInfo.firstName' => 'John',
            'customerInfo.lastName' => 'Doe',
            'customFields.customField3' => 'https://www.example.com/logo.png',
            'customFields.customField6' => 'shipping info',
            'externalIntegrationId' => 'LIB_VERSION_WE_MODULEVERSION',
            'iso2CountryCode' => 'FR',
            'language' => 'fr',
            'operationType' => OperationType::SIMPLE_PAYMENT,
            'orderId' => '1234567890-1234567890',
            'orderReference' => '1234567890',
            'paymentMode' => PaymentMode::TEST,
            'paymentRenderingMode' => PaymentRenderingMode::HPP,
            'shipping.address.city' => 'Bamberg',
            'shipping.address.country' => 'DEU',
            'shipping.address.postalCode' => '96050',
            'shipping.address.streetName' => 'Schwarzenbergstr',
            'shipping.address.streetNumber' => '4',
            'shipping.consumer.firstName' => 'Jane',
            'shipping.consumer.lastName' => 'Doe',
            'shipping.contactInfo.email' => 'jane.doe@example.net',
            'shopName' => 'My Test Shop',
            'statementDescriptor' => 'My Test Shop',
            'transId' => '123456789',
            'urlCancel' => Utils::getEnv('URL_SUCCESS', 'https://www.example.com/cancel'),
            'urlWebhook' => Utils::getEnv('URL_NOTIFY', 'https://www.example.com/notify'),
            'urlReturn' => Utils::getEnv('URL_SUCCESS', 'https://www.example.com/success'),
        ];
        AxeptaPaygate::init($configuration);

        $operation = AxeptaPaygate::buildOperation();

        $this->assertIsArray($operation);
        $this->assertArrayHasKey('request', $operation);
        $this->assertArrayHasKey('params', $operation);

        $params = $operation['params'];

        $this->assertArrayHasNestedKeys('amount.currency', $params);
        $this->assertArrayHasNestedKeys('amount.value', $params);
        $this->assertArrayHasNestedKeys('billingAddress', $params);
        $this->assertArrayHasNestedKeys('captureMethod.type', $params);
        $this->assertArrayHasNestedKeys('customerInfo.firstName', $params);
        $this->assertArrayHasNestedKeys('customerInfo.lastName', $params);
        $this->assertArrayHasKey('externalIntegrationId', $params);
        $this->assertArrayHasKey('language', $params);
        $this->assertArrayHasKey('refNr', $params);
        $this->assertArrayHasKey('requestId', $params);
        $this->assertArrayHasNestedKeys('shipping.address', $params);
        $this->assertArrayHasKey('statementDescriptor', $params);
        $this->assertArrayHasKey('transId', $params);
        $this->assertArrayHasNestedKeys('urls.cancel', $params);
        $this->assertArrayHasNestedKeys('urls.webhook', $params);
        $this->assertArrayHasNestedKeys('urls.return', $params);
        $this->assertArrayHasNestedKeys('template.customFields', $params);
        $this->assertArrayHasNestedKeys('template.customFields.customField3', $params);
        $this->assertArrayHasNestedKeys('template.customFields.customField6', $params);

        $request = $operation['request'];
        $response = $request->call();
        $json = json_decode($response, true);
        $this->assertIsString($json['_links']['redirect']['href']);
    }

    /**
     * SchemeReferenceID non disponible en mode TEST
     * Direct payment ne fonctionne pas en mode DEMO, [responseCode] => 22943002 [responseDescription] => Invalid parameter browserInfo.
     */
    // public function testOneClickPayment()
    // {
    //     $payment = self::performDirectPayment('amx', true, false, true, true);

    //     $this->assertArrayHasNestedKeys('payment.card.number', $payment);

    //     [$prefilledConfiguration, $actualMissingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys('amx', OperationType::ONE_CLICK_PAYMENT, PaymentRenderingMode::DIRECT);
    //     $expectedMissingConfigurationKeys = [
    //         'amount.value',
    //         'amount.currency',
    //         'api_access_token',
    //         'cartId',
    //         'iso2CountryCode',
    //         'orderId',
    //         'orderReference',
    //         'payment.card.card.brand',
    //         'payment.card.card.expiryDate',
    //         'payment.card.card.number',
    //         'paymentMode',
    //         'shopName',
    //         'transId',
    //     ];

    //     self::assertEqualsCanonicalizing($expectedMissingConfigurationKeys, $actualMissingConfigurationKeys);

    //     $configuration = [
    //         'amount.value' => '1234',
    //         'amount.currency' => 'EUR',
    //         'api_access_token' => self::$accessToken,
    //         'cartId' => Utils::randomString(),
    //         'iso2CountryCode' => 'FR',
    //         'operationType' => OperationType::ONE_CLICK_PAYMENT,
    //         'orderId' => '1234567890-1234567890',
    //         'orderReference' => '1234567890',
    //         // TODO: should be PaymentMode::TEST
    //         'paymentMode' => PaymentMode::DEMO,
    //         'paymentRenderingMode' => PaymentRenderingMode::DIRECT,
    //         'shopName' => 'My Test Shop',
    //         'transId' => '123456789',
    //     ];

    //     // Special AMEX params
    //     $configuration['trigram'] = 'amx';

    //     // OneClick Card data
    //     $configuration['payment.card.card.brand'] = $payment['payment']['card']['brand'];
    //     $configuration['payment.card.card.expiryDate'] = $payment['payment']['card']['expiryDate'];
    //     $configuration['payment.card.card.number'] = $payment['payment']['card']['number'];

    //     AxeptaPaygate::init($configuration);

    //     $operation = AxeptaPaygate::buildOperation();

    //     $this->assertIsArray($operation);
    //     $this->assertArrayHasKey('request', $operation);
    //     $this->assertArrayHasKey('params', $operation);

    //     $params = $operation['params'];

    //     $this->assertArrayHasNestedKeys('amount.currency', $params);
    //     $this->assertArrayHasNestedKeys('amount.value', $params);
    //     $this->assertArrayHasNestedKeys('credentialOnFile.initialPayment', $params);
    //     $this->assertArrayHasNestedKeys('credentialOnFile.type', $params);
    //     $this->assertArrayHasNestedKeys('credentialOnFile.useCase', $params);
    //     $this->assertArrayHasNestedKeys('order.description', $params);
    //     $this->assertArrayHasNestedKeys('payment.method', $params);
    //     $this->assertArrayHasKey('refNr', $params);
    //     $this->assertArrayHasKey('requestId', $params);
    //     $this->assertArrayHasKey('transId', $params);

    //     $request = $operation['request'];
    //     $response = $request->call();
    //     $json = json_decode($response, true);
    //     self::assertArrayHasKey('code', $json);
    //     self::assertEquals('00000000', $json['code']);
    //     self::assertArrayHasKey('paymentId', $json);
    // }

    /**
     * SchemeReferenceID non disponible en mode TEST
     * Direct payment ne fonctionne pas en mode DEMO, [responseCode] => 22943002 [responseDescription] => Invalid parameter browserInfo.
     */
    // public function testPaymentSubscription()
    // {
    //     $payment = self::performDirectPayment('amx', false, true, false, false);

    //     $this->assertArrayHasNestedKeys('payment.card.number', $payment);

    //     [$prefilledConfiguration, $actualMissingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys('amx', OperationType::SIMPLE_PAYMENT, PaymentRenderingMode::DIRECT);
    //     $expectedMissingConfigurationKeys = [
    //         'amount.value',
    //         'amount.currency',
    //         'api_access_token',
    //         'capture',
    //         'cartId',
    //         'iso2CountryCode',
    //         'orderId',
    //         'orderReference',
    //         'payment.card.card.brand',
    //         'payment.card.card.expiryDate',
    //         'payment.card.card.number',
    //         'paymentMode',
    //         'shopName',
    //         'transId',
    //     ];

    //     self::assertEqualsCanonicalizing($expectedMissingConfigurationKeys, $actualMissingConfigurationKeys);

    //     $configuration = [
    //         'amount.value' => '1234',
    //         'amount.currency' => 'EUR',
    //         'api_access_token' => self::$accessToken,
    //         'capture' => CaptureMode::AUTO,
    //         'cartId' => Utils::randomString(),
    //         'iso2CountryCode' => 'FR',
    //         'operationType' => OperationType::RECURRING_PAYMENT_SUBSCRIPTION,
    //         'orderId' => '1234567890-1234567890',
    //         'orderReference' => '1234567890',
    //         // TODO: should be PaymentMode::TEST
    //         'paymentMode' => PaymentMode::DEMO,
    //         'paymentRenderingMode' => PaymentRenderingMode::DIRECT,
    //         'shopName' => 'My Test Shop',
    //         'transId' => '123456789',
    //     ];

    //     // Special AMEX params
    //     $configuration['trigram'] = 'amx';

    //     // Subscription Card data
    //     $configuration['payment.card.card.brand'] = $payment['payment']['card']['brand'];
    //     $configuration['payment.card.card.expiryDate'] = $payment['payment']['card']['expiryDate'];
    //     $configuration['payment.card.card.number'] = $payment['payment']['card']['number'];

    //     AxeptaPaygate::init($configuration);

    //     $operation = AxeptaPaygate::buildOperation();

    //     $this->assertIsArray($operation);
    //     $this->assertArrayHasKey('request', $operation);
    //     $this->assertArrayHasKey('params', $operation);

    //     $params = $operation['params'];

    //     $this->assertArrayHasNestedKeys('amount.currency', $params);
    //     $this->assertArrayHasNestedKeys('amount.value', $params);
    //     $this->assertArrayHasNestedKeys('credentialOnFile.initialPayment', $params);
    //     $this->assertArrayHasNestedKeys('credentialOnFile.type', $params);
    //     $this->assertArrayHasNestedKeys('credentialOnFile.useCase', $params);
    //     $this->assertArrayHasNestedKeys('order.description', $params);
    //     $this->assertArrayHasNestedKeys('payment.card.accountVerification', $params);
    //     $this->assertArrayHasNestedKeys('payment.card.card', $params);
    //     $this->assertArrayHasNestedKeys('payment.method', $params);
    //     $this->assertArrayHasKey('refNr', $params);
    //     $this->assertArrayHasKey('requestId', $params);
    //     $this->assertArrayHasKey('transId', $params);

    //     $request = $operation['request'];
    //     $response = $request->call();
    //     $json = json_decode($response, true);
    //     self::assertArrayHasKey('code', $json);
    //     self::assertEquals('00000000', $json['code']);
    //     self::assertArrayHasKey('paymentId', $json);
    // }

    public function testPaymentRefund()
    {
        $payment = self::performDirectPayment('amx', false, false, true, true);
        self::assertArrayHasKey('payId', $payment);
        $paymentId = $payment['payId'];

        [$prefilledConfiguration, $actualMissingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys('amx', OperationType::PAYMENT_REFUND);
        $expectedMissingConfigurationKeys = [
            'amount.currency',
            'amount.value',
            'api_access_token',
            'orderReference',
            'paymentMode',
            'paymentId',
            'transId',
        ];
        self::assertEqualsCanonicalizing($expectedMissingConfigurationKeys, $actualMissingConfigurationKeys);

        $configuration = [
            'amount.value' => '1234',
            'amount.currency' => 'EUR',
            'api_access_token' => self::$accessToken,
            'operationType' => OperationType::PAYMENT_REFUND,
            'orderReference' => '1234567890',
            'paymentId' => $paymentId,
            'paymentMode' => self::$paymentMode,
            'transId' => '123456789',
        ];

        // Special AMEX params
        $configuration['trigram'] = 'amx';

        AxeptaPaygate::init($configuration);

        $operation = AxeptaPaygate::buildOperation();

        $this->assertIsArray($operation);
        $this->assertArrayHasKey('request', $operation);
        $this->assertArrayHasKey('params', $operation);

        $params = $operation['params'];

        $this->assertArrayHasNestedKeys('amount.currency', $params);
        $this->assertArrayHasNestedKeys('amount.value', $params);
        $this->assertArrayHasKey('refNr', $params);
        $this->assertArrayHasKey('transId', $params);

        $request = $operation['request'];
        $response = $request->call();
        $json = json_decode($response, true);
        self::assertArrayHasKey('responseCode', $json);
        self::assertEquals('00000000', $json['responseCode']);
    }

    public function testPaymentReversal()
    {
        $payment = self::performDirectPayment('amx', false, false, true, false);
        self::assertArrayHasKey('payId', $payment);
        $paymentId = $payment['payId'];

        [$prefilledConfiguration, $actualMissingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys('amx', OperationType::PAYMENT_REVERSAL);
        $expectedMissingConfigurationKeys = [
            'amount.currency',
            'amount.value',
            'api_access_token',
            'orderReference',
            'paymentMode',
            'paymentId',
            'transId',
        ];
        self::assertEqualsCanonicalizing($expectedMissingConfigurationKeys, $actualMissingConfigurationKeys);

        $configuration = [
            'amount.value' => '1234',
            'amount.currency' => 'EUR',
            'api_access_token' => self::$accessToken,
            'operationType' => OperationType::PAYMENT_REVERSAL,
            'orderReference' => '1234567890',
            'paymentId' => $paymentId,
            'paymentMode' => self::$paymentMode,
            'transId' => '123456789',
        ];

        // Special AMEX params
        $configuration['trigram'] = 'amx';

        AxeptaPaygate::init($configuration);

        $operation = AxeptaPaygate::buildOperation();

        $this->assertIsArray($operation);
        $this->assertArrayHasKey('request', $operation);
        $this->assertArrayHasKey('params', $operation);

        $params = $operation['params'];

        $this->assertArrayHasNestedKeys('amount.currency', $params);
        $this->assertArrayHasNestedKeys('amount.value', $params);
        $this->assertArrayHasKey('refNr', $params);
        $this->assertArrayHasKey('transId', $params);

        $request = $operation['request'];
        $response = $request->call();

        $json = json_decode($response, true);
        self::assertArrayHasKey('responseCode', $json);
        self::assertEquals('00000000', $json['responseCode']);
    }
}
