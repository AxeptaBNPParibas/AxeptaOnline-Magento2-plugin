<?php

declare(strict_types=1);

namespace AxeptaPaygate\Tests;

use AxeptaPaygate\Logger;

class LoggerTest extends CustomTestCase
{
    private $logFilePath;

    protected function setUp(): void
    {
        $this->logFilePath = __DIR__ . '/test.log'; // Log file path for testing
        // Remove the log file if it exists from previous tests
        if (file_exists($this->logFilePath)) {
            unlink($this->logFilePath);
        }
    }

    public function testDebugLogging()
    {
        $logger = new Logger($this->logFilePath);
        $logger->debug('This is a debug message.');

        // Assert that the log file exists
        $this->assertFileExists($this->logFilePath);

        // Assert that the content of the log file is correct
        $logContent = file_get_contents($this->logFilePath);
        $this->assertStringContainsString('This is a debug message.', $logContent);
    }

    public function testInfoLogging()
    {
        $logger = new Logger($this->logFilePath);
        $logger->info('This is an informational message.');

        // Assert that the log file exists
        $this->assertFileExists($this->logFilePath);

        // Assert that the content of the log file is correct
        $logContent = file_get_contents($this->logFilePath);
        $this->assertStringContainsString('This is an informational message.', $logContent);
    }

    public function testWarningLogging()
    {
        $logger = new Logger($this->logFilePath);
        $logger->warning('This is a warning message.');

        // Assert that the log file exists
        $this->assertFileExists($this->logFilePath);

        // Assert that the content of the log file is correct
        $logContent = file_get_contents($this->logFilePath);
        $this->assertStringContainsString('This is a warning message.', $logContent);
    }

    public function testErrorLogging()
    {
        $logger = new Logger($this->logFilePath);
        $logger->error('This is an error message.');

        // Assert that the log file exists
        $this->assertFileExists($this->logFilePath);

        // Assert that the content of the log file is correct
        $logContent = file_get_contents($this->logFilePath);
        $this->assertStringContainsString('This is an error message.', $logContent);
    }
}
