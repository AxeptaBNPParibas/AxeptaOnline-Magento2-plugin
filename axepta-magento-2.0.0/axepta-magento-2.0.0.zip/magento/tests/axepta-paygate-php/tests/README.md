## How to run the tests

### Requirements

- php 8.2
- composer

```bash
composer install
```

### Run all tests

```bash
MERCHANT_ID=... API_KEY=... composer run tests
```

### Run a specific test

```bash
MERCHANT_ID=... API_KEY=... php8.2 ./vendor/bin/phpunit tests --color --filter PhpClassTest::testThisFeature
```
