# BNP Paribas - Module Axepta Magento 2 -v2-

Le développement de ce projet est dirigé par [We+](https://we-plus.fr/).

## 🧃 Contenu des versions

[CHANGELOG.md](/CHANGELOG.md)
