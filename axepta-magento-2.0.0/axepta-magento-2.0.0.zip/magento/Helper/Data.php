<?php

namespace AxeptaBnpparibas\Online\Helper;

use AxeptaBnpparibas\Online\Model\Api\Service;
use AxeptaBnpparibas\Online\Model\TransactionFactory;
use Magento\Customer\Model\Session;
use Magento\Directory\Model\Country;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\DataObject;
use Magento\Framework\UrlInterface;
use Magento\Sales\Model\Order;
use Magento\Store\Model\StoreManagerInterface;

class Data extends AbstractHelper
{
    /**
     * @var Session
     */
    protected $customerSession;

    protected $checkoutSession;

    protected $countryRepository;

    protected $storeManager;

    protected $service;

    protected $scopeConfig;

    protected $transactionFactory;

    public const CUSTOMFIELD_FORBIDDEN_CHAR = ['&', '\'', '>', '<', '%'];

    public function __construct(
        Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        Country $countryRepository,
        StoreManagerInterface $storeManager,
        Service $service,
        ScopeConfigInterface $scopeConfig,
        TransactionFactory $transactionFactory,
    ) {
        $this->customerSession = $customerSession;
        $this->checkoutSession = $checkoutSession;
        $this->countryRepository = $countryRepository;
        $this->storeManager = $storeManager;
        $this->service = $service;
        $this->scopeConfig = $scopeConfig;
        $this->transactionFactory = $transactionFactory;
    }

    public function getFormatMethodOperationParams(DataObject $data, &$paymentInfos)
    {
        $additionalData = $data->getAdditionalData();
        if (empty($additionalData) && $this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation') == 'REDIRECT') {
            return;
        }

        if (!isset($additionalData['id']) && empty($additionalData['id']) && $this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation') == 'REDIRECT') {
            return;
        }

        if ($this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation') == 'REDIRECT') {
            $paymentInfos->setAdditionalInformation('axeptaMethodData', $additionalData);
        }

        $organisation = $this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation');
        $paymentInfos->setAdditionalInformation('paymentRenderingMode', $this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation'));

        $quote = $this->checkoutSession->getQuote();
        $currency = $quote->getData('quote_currency_code');

        if (null !== $quote->getShippingAddress()) {
            $shipping_address = $quote->getShippingAddress()->getLastName() . ' ' . $quote->getShippingAddress()->getFirstName();
        } else {
            $shipping_address = $quote->getBillingAddress()->getLastName() . ' ' . $quote->getBillingAddress()->getFirstName();
        }
        $value = str_replace(self::CUSTOMFIELD_FORBIDDEN_CHAR, '', $shipping_address);
        $paymentInfos->setAdditionalInformation('paysafeCard.accountHolder', $value);

        $value = $quote->getCustomer()->getId();
        $paymentInfos->setAdditionalInformation('paysafeCard.customerId', $value);

        $secureBaseUrl = $this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_WEB, true);

        $paymentInfos->setAdditionalInformation('captureMode', $this->scopeConfig->getValue('payment/axepta_online/capture_mode/capture_mode'));
        
        if ($this->scopeConfig->getValue('payment/axepta_online/capture_mode/capture_mode') == 'deferred') {
            $capture = (int) $this->scopeConfig->getValue('payment/axepta_online/capture_mode/deferred_before_capture');
            date_default_timezone_set('Europe/Paris');
            $captureDate = date('Y-m-d H:i:s', strtotime("+{$capture} hours"));
            $paymentInfos->setAdditionalInformation('captureTimed', $captureDate);
        } elseif ($this->scopeConfig->getValue('payment/axepta_online/capture_mode/capture_mode') == 'manual') {
            $capture = 'MANUAL';
        } else {
            $capture = 'AUTO';
        }

        $paymentInfos->setAdditionalInformation('iso2CountryCode', $this->getIsoCountryCodeA2($quote->getBillingAddress()->getCountryId()));

        $trigram = null;
        if ($this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation') == 'REDIRECT') {
            $trigram = $additionalData['code'];

            if ($quote->getBillingAddress()->getCountryId() != 'FR' && $trigram == 'CVM') {
                $trigram = "VIM";
            }
        }

        [$prefilledConfiguration, $missingConfigurationKeys] = $this->service->getParamsByTrigram($trigram, $organisation);

        foreach ($missingConfigurationKeys as $parameter) {
            $value = '';
            switch ($parameter) {
                case 'trigram':
                    $value = $trigram;
                    break;
                case 'amount.currency':
                    $value = $currency;
                    break;
                case 'amount.value':
                    $value = $quote->getGrandTotal() * 100;
                    break;
                case 'billingAddress.streetName':
                    $value = substr($quote->getBillingAddress()->getStreet()[0], 0, 32);
                    break;
                case 'billingAddress.streetNumber':
                    $value = substr($quote->getBillingAddress()->getStreet()[0], 0, 32);
                    break;
                case 'billingAddress.city':
                    $value = $quote->getBillingAddress()->getCity();
                    break;
                case 'billingAddress.country':
                    $value = $this->getIsoCountryCodeA3($quote->getBillingAddress()->getCountryId());
                    break;
                case 'billingAddress.countryA3':
                    $value = $this->getIsoCountryCodeA3($quote->getBillingAddress()->getCountryId());
                    break;
                case 'billingAddress.postalCode':
                    $value = $quote->getBillingAddress()->getPostcode();
                    break;
                case 'billing.consumer.firstName':
                    $value = $quote->getBillingAddress()->getFirstName();
                    break;
                case 'customerInfo.firstName':
                    $value = $quote->getBillingAddress()->getFirstName();
                    break;
                case 'billing.consumer.lastName':
                    $value = $quote->getBillingAddress()->getLastName();
                    break;
                case 'customerInfo.lastName':
                    $value = $quote->getBillingAddress()->getLastName();
                    break;
                case 'captureMethod':
                    $value = $capture;
                    break;
                case 'cardHolder.city':
                    $value = $quote->getBillingAddress()->getCity();
                    break;
                case 'cardHolder.name':
                    $value = $quote->getBillingAddress()->getLastName() . ' ' . $quote->getBillingAddress()->getFirstName();
                    break;
                case 'cartId':
                    $value = $quote->getId();
                    break;
                case 'orderId':
                    $value = $quote->getId();
                    break;
                case 'orderReference':
                    $value = $quote->getId();
                    break;
                case 'payment.card.card.brand':
                    $value = '';
                    break;
                case 'payment.card.card.expiryDate':
                    $value = '';
                    break;
                case 'payment.card.card.number':
                    $value = '';
                    break;
                case 'paymentId':
                    $value = '';
                    break;
                case 'paymentMode':
                    $value = $this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') ? strtoupper($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode')) : 'DEMO';
                    break;
                case 'shipping.address.streetName':
                    $value = substr($quote->getShippingAddress()->getStreet()[0], 0, 32);
                    break;
                case 'shipping.address.streetNumber':
                    $value = substr($quote->getShippingAddress()->getStreet()[0], 0, 32);
                    break;
                case 'shipping.address.city':
                    $value = $quote->getShippingAddress()->getCity();
                    break;
                case 'shipping.address.country':
                    $value = $this->getIsoCountryCodeA3($quote->getShippingAddress()->getCountryId());
                    break;
                case 'shipping.address.countryA3':
                    $value = $this->getIsoCountryCodeA3($quote->getShippingAddress()->getCountryId());
                    break;
                case 'shipping.address.postalCode':
                    $value = $quote->getShippingAddress()->getPostcode();
                    break;
                case 'shipping.consumer.firstName':
                    $value = $quote->getShippingAddress()->getFirstName();
                    break;
                case 'shipping.consumer.lastName':
                    $value = $quote->getShippingAddress()->getLastName();
                    break;
                case 'shopName':
                    $value = $this->scopeConfig->getValue('general/store_information/name') ? $this->scopeConfig->getValue('general/store_information/name') : 'Magento';
                    break;
                case 'transId':
                    $value = $quote->getId();
                    break;
                case 'urlCancel':
                    if ($this->scopeConfig->getValue('payment/axepta_online/conf_payment/display_mode') === 'iframe' && $this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation') == 'REDIRECT') {
                        $value = "{$secureBaseUrl}axepta_online/payment/cancelIframe?id=" . $quote->getId();
                    } else {
                        $value = "{$secureBaseUrl}axepta_online/payment/cancel";
                    }
                    break;
                case 'urlFailure':
                    $value = "{$secureBaseUrl}axepta_online/payment/failure?id=".$quote->getId();
                    break;
                case 'urlNotify':
                    $value = "{$secureBaseUrl}axepta_online/payment/ipn";
                    break;
                case 'urlWebhook':
                    $value = "{$secureBaseUrl}axepta_online/payment/ipn";
                    break;
                case 'urlSuccess':
                    $value = "{$secureBaseUrl}axepta_online/payment/success?id=".$quote->getId();
                    break;
                case 'urlReturn':
                    $value = "{$secureBaseUrl}axepta_online/payment/success?id=".$quote->getId();
                    break;
                case 'language':
                    $value = $this->getIsoCountryCodeA2($quote->getShippingAddress()->getCountryId());
                    break;
                case 'wirecardConnection.receiver.firstName':
                    $value = '';
                    break;
                case 'wirecardConnection.receiver.lastName':
                    $value = '';
                    break;
                case 'wirecardConnection.refundType':
                    $value = '';
                    break;
                case 'wirecardConnection.sender.accountNumber':
                    $value = '';
                    break;
                case 'wirecardConnection.sender.city':
                    $value = '';
                    break;
                case 'wirecardConnection.sender.country':
                    $value = '';
                    break;
                case 'wirecardConnection.sender.firstName':
                    $value = '';
                    break;
                case 'wirecardConnection.sender.lastName':
                    $value = '';
                    break;
                case 'wirecardConnection.sender.street':
                    $value = '';
                    break;
                case 'wirecardConnection.sender.streetNumber':
                    $value = '';
                    break;
                default:
                    $value = '';
            }

            if ($value !== '') {
                $paymentInfos->setAdditionalInformation($parameter, $value);
            }
        }

        $paymentInfos->setAdditionalInformation('customFields.customField1', $quote->getGrandTotal() . ' ' . $currency);
        $paymentInfos->setAdditionalInformation('customFields.customField2', $quote->getId());
        $paymentInfos->setAdditionalInformation('customFields.customField3', $this->scopeConfig->getValue('payment/axepta_online/personalization/redirect_logo') ? $this->scopeConfig->getValue('payment/axepta_online/personalization/logo_url') : '');
        
        $cart_contents = __('Total number of items:').' '.$quote->getItemsQty().'|';
        foreach ($quote->getAllVisibleItems() as $item) {
            $cart_contents .= $item->getQty().' x '.str_replace(self::CUSTOMFIELD_FORBIDDEN_CHAR, '', $item->getName()).'|';
        }
        if (!$this->scopeConfig->getValue('payment/axepta_online/personalization/view_cart_summary')) {
            $cart_contents = '';
        }
        $paymentInfos->setAdditionalInformation('customFields.customField4', $cart_contents);
        $paymentInfos->setAdditionalInformation('customFields.customField5', $this->scopeConfig->getValue('payment/axepta_online/personalization/view_cart_summary') ? $quote->getBillingAddress()->getLastName() . ' ' . $quote->getBillingAddress()->getFirstName() : '');

        if (null !== $quote->getShippingAddress()) {
            $shipping_address = $quote->getShippingAddress()->getLastName() . ' ' . $quote->getShippingAddress()->getFirstName() . '|' . substr($quote->getShippingAddress()->getStreet()[0], 0, 32) . '|' . $quote->getShippingAddress()->getPostCode() . ' ' . $quote->getShippingAddress()->getCity();
        } else {
            $shipping_address = $quote->getBillingAddress()->getLastName() . ' ' . $quote->getBillingAddress()->getFirstName() . '|' . substr($quote->getBillingAddress()->getStreet()[0], 0, 32) . '|' . $quote->getBillingAddress()->getPostCode() . ' ' . $quote->getBillingAddress()->getCity();
        }
        $paymentInfos->setAdditionalInformation('customFields.customField6', $this->scopeConfig->getValue('payment/axepta_online/personalization/show_delivery_address') ? str_replace(self::CUSTOMFIELD_FORBIDDEN_CHAR, '', $shipping_address) : '');

        $address = $quote->getBillingAddress()->getLastName() . ' ' . $quote->getBillingAddress()->getFirstName() . '|' . substr($quote->getBillingAddress()->getStreet()[0], 0, 32) . '|' . $quote->getBillingAddress()->getPostCode() . ' ' . $quote->getBillingAddress()->getCity();
        $paymentInfos->setAdditionalInformation('customFields.customField7', $this->scopeConfig->getValue('payment/axepta_online/personalization/show_billing_address') ? str_replace(self::CUSTOMFIELD_FORBIDDEN_CHAR, '', $address) : '');
        $paymentInfos->setAdditionalInformation('customFields.customField8', $this->scopeConfig->getValue('payment/axepta_online/personalization/custom_title') ? $this->scopeConfig->getValue('payment/axepta_online/personalization/custom_title') : '');
        $paymentInfos->setAdditionalInformation('customFields.customField9', $this->scopeConfig->getValue('payment/axepta_online/personalization/custom_text') ? $this->scopeConfig->getValue('payment/axepta_online/personalization/custom_text') : '');
    }

    public function getDataFromCollection($collection)
    {
        $return = [];
        foreach ($collection as $item) {
            $return[] = $item->getData();
        }

        return $return;
    }

    public function getIsoCountryCodeA3($countryId)
    {
        $country = $this->countryRepository->loadByCode($countryId);

        return $country->getData('iso3_code');
    }

    public function getIsoCountryCodeA2($countryId)
    {
        $country = $this->countryRepository->loadByCode($countryId);

        return $country->getData('iso2_code');
    }
}
