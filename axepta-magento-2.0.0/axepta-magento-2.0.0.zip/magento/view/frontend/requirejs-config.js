var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/shipping': {
                'AxeptaBnpparibas_Online/js/view/shipping-mixin': true
            },
            'Magento_Checkout/js/view/billing-address': {
                'AxeptaBnpparibas_Online/js/view/billing-address-mixin': true
            }
        }
    }
};
