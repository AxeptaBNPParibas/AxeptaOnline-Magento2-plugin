define(
    [
        'jquery',
        'Magento_Checkout/js/view/payment/default',
        'ko',
        'mage/url',
        'Magento_Checkout/js/model/full-screen-loader',
        'Magento_Customer/js/model/customer',
        'Magento_Checkout/js/model/quote'
    ],
    function ($, Component, ko, url, fullScreenLoader, customer, quote) {
        'use strict';

        $(document).on('click', '#axepta-methods-list-button  .card-option', function(e) {
            $('#axepta-methods-list-button').find('.card-option').removeClass('selected');
            $(this).addClass('selected');
            $(this).find('input[type="radio"]').prop('checked', true).trigger('change');
        });

        return Component.extend({
            methodName: ko.observable(),
            allowedMethods: ko.observableArray([]),
            displayMethod: ko.observable(),
            displayMode: ko.observable(),
            mode: ko.observable(),
            defaults: {
                template: 'AxeptaBnpparibas_Online/payment/axepta-method',
                redirectAfterPlaceOrder: false,
                paymentReady: false
            },

            initialize: function () {
                var self = this;

                setTimeout(function () {
                    let selectedAddress = quote.billingAddress();

                    // Add default country if not set
                    if (!selectedAddress.countryId) {
                        selectedAddress.countryId = 'FR';
                    }

                    if (!quote.base_currency_code) {
                        quote.base_currency_code = 'EUR';
                    }

                    $.ajax({
                        url: url.build('axepta_online/checkout/ajax/'),
                        type: "POST",
                        dataType: "json",
                        data: {
                            isAjax: true,
                            action: 'getAllowedMethods',
                            countryId: selectedAddress.countryId,
                            currency: quote.base_currency_code
                        },
                        success: function (data) {
                            window.checkoutConfig.axepta = data.axepta;
                            self.loadPaymentMethods(data.axepta);
                        }
                    });
                }, 50);

                this._super();
                return this;
            },

            redirectController: "directlink",
            operation: "payment",
            parent: null,
            event: null,
            methodData: null,

            getCode: function () {
                return 'axepta_online';
            },

            initObservable: function () {
                this._super().observe('paymentReady');

                return this;
            },

            getData: function () {
                return {
                    'method': this.item.method,
                    'po_number': null,
                    'additional_data': this.methodData
                };
            },

            loadPaymentMethods: function (axepta) {
                this.allowedMethods(Object.values(axepta.methods));
                this.methodName(axepta.methodName);
                this.displayMethod(axepta.displayMethod);
                this.displayMode(axepta.displayMode);
                this.mode(axepta.mode);
            },

            getTitle: function () {
                return this.methodName();
            },

            isActive: function () {
                return true;
            },

            getAllowedMethods: function () {
                if (this.allowedMethods().length > 6) {
                    return this.allowedMethods().slice(0, 6);
                }
                return this.allowedMethods();
            },

            getAllowedMethodsHidden: function () {
                return this.allowedMethods().slice(6);
            },

            count: function () {
                return this.allowedMethods().length;
            },

            saveDataChecked: function (parent, event, methodData) {
                this.parent = parent;
                this.event = event;
                this.methodData = methodData;
                if (methodData.idPcnr) {
                    $("#" + methodData.idPcnr).prop("checked", true);
                } else {
                    $("#" + methodData.code).prop("checked", true);
                }
                $("#action-checkout").removeClass("disabled");
            },

            placeOrder: function() {
                if (this.isRedirectDisplay()) {
                    delete this.methodData.images;
                    this.methodData.operation = this.operation;
                }

                return this._super(this.parent, this.event);
            },

            isIframeDisplay: function () {
                return (this.displayMethod() === "iframe" && this.displayMode() === "REDIRECT");
            },

            isRedirectDisplay: function () {
                return (this.displayMode() === "REDIRECT");
            },

            isDemoMode: function () {
                return (this.mode() === "DEMO");
            },

            iframeLoaded: function () {
                fullScreenLoader.stopLoader();
            },

            isPaymentReady: function () {
                return this.paymentReady();
            },

            isCustomerGuest: function () {
                return customer.isLoggedIn();
            },

            afterPlaceOrder: function () {

                if (this.isIframeDisplay) {
                    $("#axepta-methods-list-button").hide();
                }

                var redirectUrl = url.build('axepta_online/payment/' + this.redirectController);
                if (this.isRedirectDisplay()) {
                    if (this.isIframeDisplay()) {
                        this.paymentReady(true);
                        $("#" + this.getCode() + '-iframe').attr('src', redirectUrl);
                        if (this.iframeIsLoaded) {
                            document.getElementById(this.getCode() + '-iframe').contentWindow.location.reload();
                        }
                        this.iframeIsLoaded = true;
                        this.isPlaceOrderActionAllowed(true);
                        fullScreenLoader.stopLoader();
                        $('html, body').animate({
                            scrollTop: $("#" + this.getCode() + '-iframe').offset().top
                        }, 1000);
                    } else {
                        window.location.replace(redirectUrl);
                    }
                } else {
                    if (this.isIframeDisplay()) {
                        this.paymentReady(true);
                        $("#" + this.getCode() + '-iframe').attr('src', redirectUrl);
                        if (this.iframeIsLoaded) {
                            document.getElementById(this.getCode() + '-iframe').contentWindow.location.reload();
                        }
                        this.iframeIsLoaded = true;
                        this.isPlaceOrderActionAllowed(true);
                        fullScreenLoader.stopLoader();
                        $('html, body').animate({
                            scrollTop: $("#" + this.getCode() + '-iframe').offset().top
                        }, 1000);
                    } else {
                        window.location.replace(redirectUrl);
                    }
                }
            }
        });
    }
);
