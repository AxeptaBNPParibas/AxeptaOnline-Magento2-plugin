define([
    'jquery',
    'Magento_Checkout/js/model/quote',
    'ko',
    'mage/url',
    'Magento_Checkout/js/action/select-billing-address',
    'AxeptaBnpparibas_Online/js/view/payment/method-renderer/axepta-method'
], function ($, quote, ko, url, selectBillingAddress, AxeptaMethod) {
    'use strict';
    var mixin = {
        /**
         * @return {Boolean}
         */
        validateShippingInformation: function () {
            var result = this._super();
            selectBillingAddress(quote.shippingAddress());
            var selectedAddress = quote.billingAddress();
            if (selectedAddress === null) {
                selectedAddress = quote.shippingAddress();
            }

            var countryId = (selectedAddress.countryId !== undefined) ?
                selectedAddress.countryId : $("[name='country_id']").val();

            if (!selectedAddress.countryId) {
                selectedAddress.countryId = 'FR';
            }

            if (!quote.base_currency_code) {
                quote.base_currency_code = 'EUR';
            }

            $.ajax({
                url: url.build('axepta_online/checkout/ajax/'),
                type: "POST",
                dataType: "json",
                data: {
                    isAjax: true,
                    action: 'getAllowedMethods',
                    countryId: countryId,
                    currency: quote.base_currency_code
                },
                success: function (data) {
                    window.checkoutConfig.axepta = data.axepta;
                    AxeptaMethod.call().loadPaymentMethods(data.axepta);
                }
            });

            return result;
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
