define([
    'jquery',
    'Magento_Checkout/js/model/quote',
    'ko',
    'mage/url',
    'AxeptaBnpparibas_Online/js/view/payment/method-renderer/axepta-method'
], function ($, quote, ko, url, AxeptaMethod) {
    'use strict';
    var mixin = {

        changePaymentMethod: function(countryId) {
            var body = $('body').loader();
            body.loader('show');
            if (!quote.base_currency_code) {
                quote.base_currency_code = 'EUR';
            }

            $.ajax({
                url: url.build('axepta_online/checkout/ajax/'),
                type: "POST",
                dataType: "json",
                data: {
                    isAjax: true,
                    action: 'getAllowedMethods',
                    countryId: countryId,
                    currency: quote.base_currency_code
                },
                success: function (data) {
                    body.loader('hide');
                    window.checkoutConfig.axepta = data.axepta;
                    AxeptaMethod.call().loadPaymentMethods(data.axepta);
                },
                error: function(data) {
                    body.loader('hide');
                }
            });
        },

        useShippingAddress: function () {
            let self = this;
            let returnValue = this._super();
            let selectedAddress = quote.billingAddress();
            if (selectedAddress !== null) {
                self.changePaymentMethod(selectedAddress.countryId);
            }

            return returnValue;
        },
        updateAddress: function () {
            this._super();
            let self = this;
            let selectedAddress = quote.billingAddress();
            if (selectedAddress !== null) {
                self.changePaymentMethod(selectedAddress.countryId);
            }
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
