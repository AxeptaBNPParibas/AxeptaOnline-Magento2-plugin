<?php

namespace AxeptaBnpparibas\Online\Model;

use AxeptaBnpparibas\Online\Model\ResourceModel\AxeptaMethodCountry as AxeptaMethodCountryResource;
use Magento\Framework\Model\AbstractModel;

class AxeptaMethodCountry extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(AxeptaMethodCountryResource::class);
    }
}
