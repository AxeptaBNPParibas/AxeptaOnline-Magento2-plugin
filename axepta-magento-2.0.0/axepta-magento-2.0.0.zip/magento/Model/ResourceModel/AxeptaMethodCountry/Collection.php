<?php

namespace AxeptaBnpparibas\Online\Model\ResourceModel\AxeptaMethodCountry;

use AxeptaBnpparibas\Online\Model\AxeptaMethodCountry;
use AxeptaBnpparibas\Online\Model\ResourceModel\AxeptaMethodCountry as AxeptaMethodCountryResource;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'id';

    protected function _construct()
    {
        $this->_init(AxeptaMethodCountry::class, AxeptaMethodCountryResource::class);
    }
}
