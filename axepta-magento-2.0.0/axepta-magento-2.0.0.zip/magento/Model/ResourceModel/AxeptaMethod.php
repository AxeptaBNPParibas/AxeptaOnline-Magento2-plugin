<?php

namespace AxeptaBnpparibas\Online\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class AxeptaMethod extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('axepta_online_method', 'id');
    }
}
