<?php

namespace AxeptaBnpparibas\Online\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class AxeptaMethodCountry extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('axepta_online_method_allowed_country', 'id');
    }
}
