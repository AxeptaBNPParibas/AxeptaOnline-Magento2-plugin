<?php

namespace AxeptaBnpparibas\Online\Model\ResourceModel\Transaction;

use AxeptaBnpparibas\Online\Model\ResourceModel\Transaction as ResourceModelTransaction;
use AxeptaBnpparibas\Online\Model\Transaction;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = Transaction::TRANSACTION_ID;

    /**
     * Define resource model.
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(Transaction::class, ResourceModelTransaction::class);
    }
}
