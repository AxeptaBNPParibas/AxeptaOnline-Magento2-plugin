<?php

namespace AxeptaBnpparibas\Online\Model\ResourceModel\AxeptaMethod;

use AxeptaBnpparibas\Online\Model\AxeptaMethod;
use AxeptaBnpparibas\Online\Model\ResourceModel\AxeptaMethod as AxeptaMethodResource;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'id';

    protected function _construct()
    {
        $this->_init(AxeptaMethod::class, AxeptaMethodResource::class);
    }
}
