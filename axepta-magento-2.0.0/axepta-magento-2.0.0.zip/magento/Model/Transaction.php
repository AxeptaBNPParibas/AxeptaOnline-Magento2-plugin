<?php

namespace AxeptaBnpparibas\Online\Model;

use AxeptaBnpparibas\Online\Model\ResourceModel\Transaction as ResourceModelTransaction;
use Magento\Framework\Model\AbstractModel;

class Transaction extends AbstractModel
{
    public const TRANSACTION_ID = 'id';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'transactions';

    /**
     * Name of the event object.
     *
     * @var string
     */
    protected $_eventObject = 'transaction';

    /**
     * Name of object id field.
     *
     * @var string
     */
    protected $_idFieldName = self::TRANSACTION_ID;

    /**
     * Initialize resource model.
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(ResourceModelTransaction::class);
    }
}
