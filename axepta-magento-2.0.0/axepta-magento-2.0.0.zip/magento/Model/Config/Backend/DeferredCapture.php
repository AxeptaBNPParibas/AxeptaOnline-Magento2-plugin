<?php

namespace AxeptaBnpparibas\Online\Model\Config\Backend;

use Magento\Framework\Exception\ValidatorException;

class DeferredCapture extends \Magento\Framework\App\Config\Value
{
    public function beforeSave()
    {
        $value = trim($this->getValue());

        if ($value === '' || !ctype_digit($value)) {
            throw new ValidatorException(__("The value: 'Number of hours before capture request' must be an integer between 0 and 696."));
        }

        $value = (int)$value;

        if ($value < 0 || $value > 696) {
            throw new ValidatorException(__("The value: 'Number of hours before capture request' must be between 0 and 696."));
        }

        return parent::beforeSave();
    }
}
