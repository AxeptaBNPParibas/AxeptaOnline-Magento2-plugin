<?php

namespace AxeptaBnpparibas\Online\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class Mode implements ArrayInterface
{
    /**
     * Retrieve Mode Option array.
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'DEMO', 'label' => __('Demo')],
            ['value' => 'test', 'label' => __('Test')],
            ['value' => 'production', 'label' => __('Production')],
        ];
    }
}
