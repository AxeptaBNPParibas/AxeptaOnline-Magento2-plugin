<?php

namespace AxeptaBnpparibas\Online\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class DisplayMode implements ArrayInterface
{
    /**
     * Retrieve ModeAffichage Option array.
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'redirect', 'label' => __('Redirect')],
        ];
    }
}
