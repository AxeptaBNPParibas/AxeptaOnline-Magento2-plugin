<?php

namespace AxeptaBnpparibas\Online\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class Organisation implements ArrayInterface
{
    /**
     * Retrieve ModeAffichage Option array.
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'HPP', 'label' => __('Selecting a payment method on the Axepta BNP Paribas page')],
            ['value' => 'REDIRECT', 'label' => __('Choice of payment method on the merchant site')],
        ];
    }
}
