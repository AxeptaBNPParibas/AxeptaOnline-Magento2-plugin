<?php

namespace AxeptaBnpparibas\Online\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class CaptureMethod implements ArrayInterface
{
    /**
     * Retrieve Mode Option array.
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'automatic', 'label' => __('Automatic')],
            ['value' => 'deferred', 'label' => __('Deferred')],
            ['value' => 'manual', 'label' => __('Manual')],
        ];
    }
}
