<?php

namespace AxeptaBnpparibas\Online\Model\Method;

use AxeptaBnpparibas\Online\Model\Api\Service;
use AxeptaBnpparibas\Online\Model\TransactionFactory;
use Magento\Checkout\Model\Session;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Registry;
use Magento\Framework\UrlInterface;
use Magento\Payment\Helper\Data;
use Magento\Payment\Model\InfoInterface;
use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Payment\Model\Method\Logger;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Sales\Model\Order\Payment\Transaction;
use Psr\Log\LoggerInterface;

class Axepta extends AbstractMethod
{
    public const METHOD_CODE = 'axepta_online';
    public const OPERATION_TYPE_PAYMENT = 'payment';
    public const OPERATION_TYPE_AUTH = 'authorization';
    public const OPERATION_TYPE_CAPTURE = 'capture';
    public const OPERATION_TYPE_REFUND = 'refund';

    protected $checkoutSession;
    protected $_currentOperationType = '';
    protected $_isGateway = true;
    protected $_canCapture = true;
    protected $_canCapturePartial = true;
    protected $_canRefund = true;
    protected $_canRefundInvoicePartial = true;

    /**
     * Payment code.
     *
     * @var string
     */
    protected $_code = self::METHOD_CODE;

    protected $logger;

    protected $psrLogger;

    protected $helper;

    /** @var UrlInterface */
    protected $urlBuilder;

    protected $curl;

    protected $scopeConfig;

    protected $transactionFactory;

    protected $service;

    protected $messageManager;

    public function __construct(
        Context $context,
        Registry $registry,
        ExtensionAttributesFactory $extensionFactory,
        AttributeValueFactory $customAttributeFactory,
        Data $paymentData,
        ScopeConfigInterface $scopeConfig,
        Logger $logger,
        LoggerInterface $psrLogger,
        Session $checkoutSession,
        \AxeptaBnpparibas\Online\Helper\Data $axeptaHelper,
        UrlInterface $urlBuilder,
        Curl $curl,
        TransactionFactory $transactionFactory,
        Service $service,
        ManagerInterface $messageManager,
        ?AbstractResource $resource = null,
        ?AbstractDb $resourceCollection = null,
        array $data = [],
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->helper = $axeptaHelper;
        $this->urlBuilder = $urlBuilder;
        $this->logger = $logger;
        $this->psrLogger = $psrLogger;
        $this->curl = $curl;
        $this->scopeConfig = $scopeConfig;
        $this->transactionFactory = $transactionFactory;
        $this->service = $service;
        $this->messageManager = $messageManager;

        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data
        );
    }

    /**
     * @return string payment action
     */
    public function getConfigPaymentAction()
    {
        return $this->getInfoInstance()->getAdditionalInformation('action');
    }

    public function authorize(InfoInterface $payment, $amount)
    {
        parent::authorize($payment, $amount);
        if ($this->getConfigPaymentAction() == self::ACTION_AUTHORIZE) {
            $payment->setIsTransactionPending(1);
        }

        return $this;
    }

    /**
     * Check refund availability.
     *
     * @return bool
     */
    public function canRefund()
    {
        return true;
    }

    /**
     * Check partial refund availability for invoice.
     *
     * @return bool
     */
    public function canRefundPartialPerInvoice()
    {
        return true;
    }

    public function capture(InfoInterface $payment, $amount)
    {
        $paymentInformations = $payment->getAdditionalInformation();

        if (array_key_exists('captureMode', $paymentInformations)) {
            if ($paymentInformations['captureMode'] === 'manual') {
                $orderId = $payment->getOrder()->getId();

                $transactions = $this->transactionFactory->create();
                $transaction = $transactions->getCollection()->addFieldToFilter('order_id', ['eq' => $orderId])->getFirstItem();

                $data = [];
                try {
                    $data = $this->service->getPaymentDetails($transaction->getPayId(), $this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') ? strtoupper($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode')) : 'DEMO', $this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation'));
                } catch (\Exception $e) {
                    $this->psrLogger->critical($e);
                }

                if ($data['status'] !== 'Failed' && $data['amount']['capturedValue'] < $amount * 100) {
                    try {
                        $this->service->capturePayment($this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key'), $transaction->getPayId(), $this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') ? strtoupper($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode')) : 'DEMO', $amount * 100, $paymentInformations['amount.currency'], $paymentInformations['billingAddress.country'], $paymentInformations['transId']);
                    } catch (\Exception $e) {
                        $this->psrLogger->critical($e);
                    }

                    $payment->setTransactionId($payment->getId());
                    $payment->setLastTransId($payment->getId());
                    $payment->setTransactionAdditionalInfo(
                        Transaction::RAW_DETAILS,
                        (array) $transaction->getData()
                    );
                } else {
                    $order = $payment->getOrder();
                    $order->addStatusHistoryComment(__('The order has already been captured from Axepta BNP Paribas. - Invoice created'))
                    ->setIsCustomerNotified(false);
                    $this->messageManager->addWarning(__('The order has already been captured from Axepta BNP Paribas.'));
                }
            }
        }
        parent::capture($payment, $amount);
    }

    /**
     * Assign data to info model instance.
     *
     * @param array|DataObject $data
     *
     * @return $this
     *
     * @throws LocalizedException
     *
     * @api
     */
    public function assignData(DataObject $data, $recurring = false)
    {
        parent::assignData($data);
        $paymentInfos = $this->getInfoInstance();

        // Security check
        if ($data['method'] != self::METHOD_CODE && $recurring === false) {
            $this->messageManager->addWarning(__('Axepta BNP Paribas Error'));
            $this->psrLogger->critical(__('Axepta BNP Paribas Error'));
        }
        $this->helper->getFormatMethodOperationParams($data, $paymentInfos);

        return $this;
    }

    /**
     * Check whether payment method can be used.
     *
     * @return bool
     *
     * @deprecated 100.2.0
     */
    public function isAvailable(?CartInterface $quote = null)
    {
        if (!$this->scopeConfig->getValue('payment/axepta_online/conf_account/front_active')) {
            return false;
        }

        if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') == 'test') {
            if (!$this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key') || !$this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key')) {
                return false;
            }
        }

        if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') == 'production') {
            if (!$this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key') || !$this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key')) {
                return false;
            }
        }

        return true;
    }

    public function refund(InfoInterface $payment, $amount)
    {
        parent::refund($payment, $amount);

        $orderId = $payment->getOrder()->getId();

        $transactions = $this->transactionFactory->create();
        $transaction = $transactions->getCollection()->addFieldToFilter('order_id', ['eq' => $orderId])->getFirstItem();

        $method = $payment->getMethod();

        if ($method != 'axepta_online') {
            return true;
        }

        $data = [];
        try {
            $data = $this->service->getPaymentDetails($transaction->getPayId(), $this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') ? strtoupper($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode')) : 'DEMO', $this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation'));
        } catch (\Exception $e) {
            $this->psrLogger->critical($e);
        }

        $json = json_encode($data);
        if ($json === false) {
            $this->psrLogger->critical('JSON encode error: ' . json_last_error_msg());
        } else {
            $this->psrLogger->critical($json);
        }

        if ($data['status'] == 'Failed') {
            throw new \Magento\Framework\Validator\Exception(__('You cannot refund this order.'));
        }

        $operation = 'refund';

        $date_transaction = new \DateTime($transaction->getTransaction_date());
        $date_now = new \DateTime('now');
        $diff = $date_transaction->diff($date_now);

        $nb_months = $diff->m;

        if ($nb_months > 11) {
            throw new \Magento\Framework\Validator\Exception(__('This order is too old to be refunded.'));
        }

        $paymentInformations = $payment->getAdditionalInformation();

        $trigram = $paymentInformations['axeptaMethodData']['code'];

        if ($payment->getOrder()->getBillingAddress()->getCountryId() != 'FR' && $trigram == 'CVM') {
            $trigram = 'VIM';
        }

        try {
            $refund = $this->service->refundPayment($this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key'), $transaction->getPayId(), $this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') ? strtoupper($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode')) : 'DEMO', $amount * 100, $paymentInformations['amount.currency'], $paymentInformations['billingAddress.country'], $paymentInformations['transId'], $trigram, $paymentInformations['orderReference'], $paymentInformations['cartId'], $paymentInformations['shopName'], $paymentInformations['customerInfo.lastName'], $paymentInformations['billingAddress.city']);
            $refund = json_decode($refund, true);
        } catch (\Exception $e) {
            $this->psrLogger->critical($e);
        }

        $newTransaction = $this->transactionFactory->create();
        $newTransaction->setData([
            'order_id' => $transaction->getOrderId(),
            'merchant_id' => array_key_exists('merchantId', $data) ? $data['merchantId'] : '',
            'transaction_reference' => array_key_exists('transId', $data) ? $data['transId'] : '',
            'transaction_date' => date('Y-m-d H:i:s'),
            'pay_id' => array_key_exists('payId', $data) ? $data['payId'] : '',
            'bid' => '',
            'xid' => array_key_exists('xId', $data) ? $data['xId'] : '',
            'transaction_type' => $operation,
            'payment_mean_brand' => array_key_exists('card', $data['paymentMethods']) ? $data['paymentMethods']['card']['brand'] : '',
            'response_code' => array_key_exists('responseCode', $refund) ? $refund['responseCode'] : '',
            'pcnr' => array_key_exists('card', $data['paymentMethods']) ? $data['paymentMethods']['card']['first6Digits'] : '',
            'ccexpiry' => array_key_exists('card', $data['paymentMethods']) ? $data['paymentMethods']['card']['expiryDate'] : '',
            'status' => array_key_exists('status', $refund) ? $refund['status'] : '',
            'description' => array_key_exists('responseDescription', $refund) ? $refund['responseDescription'] : '',
            'amount' => '-' . $amount,
            'raw_data' => json_encode($data),
            'ref_nr' => array_key_exists('refNr', $data) ? $data['refNr'] : '',
            'scheme_reference_id' => '',
            'holder_name' => array_key_exists('card', $data['paymentMethods']) ? $data['paymentMethods']['card']['cardHolderName'] : '',
        ]);
        $newTransaction->save();
    }
}
