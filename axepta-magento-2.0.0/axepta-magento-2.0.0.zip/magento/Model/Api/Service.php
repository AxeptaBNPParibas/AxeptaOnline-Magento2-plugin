<?php

namespace AxeptaBnpparibas\Online\Model\Api;

require_once __DIR__ . '/../../tests/axepta-paygate-php/lib/init.php';

use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\Exception\ApiCallException;
use AxeptaPaygate\Exception\AxeptaPaygateException;
use Psr\Log\LoggerInterface;
use Magento\Framework\Component\ComponentRegistrarInterface;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Service
{
    protected $logger;
    protected $componentRegistrar;
    protected $json;
    protected $scopeConfig;

    private const DEMO_PUBLIC_KEY = 'BNP_AXE_STD_DEMO';
    private const DEMO_PRIVATE_KEY = 'a831e0b6-1342-4449-b030-1126dc1afc4d';

    public function __construct(
        LoggerInterface $logger,
        ComponentRegistrarInterface $componentRegistrar,
        Json $json,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->logger = $logger;
        $this->componentRegistrar = $componentRegistrar;
        $this->json = $json;
        $this->scopeConfig = $scopeConfig;
    }

    public function buildOperation($isRecurringPaymentInit, $trigram, $merchantId, $apiKey, $paymentData, $paymentMode = 'REDIRECT', $idOrder = 0)
    {
        if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') === 'DEMO') {
            $merchantId = self::DEMO_PUBLIC_KEY;
            $apiKey = self::DEMO_PRIVATE_KEY;
        }

        [$prefilledConfiguration, $missingConfigurationKeys] = $this->getParamsByTrigram($trigram, $paymentMode);

        foreach ($missingConfigurationKeys as $key) {
            switch ($key) {
                case 'amount.currency':
                    $prefilledConfiguration[$key] = $paymentData['amount.currency'];
                    break;
                case 'amount.value':
                    $prefilledConfiguration[$key] = $paymentData['amount.value'];
                    break;
                case 'api_access_token':
                    $prefilledConfiguration[$key] = $this->getToken($merchantId, $apiKey, $paymentData['paymentMode']);
                    break;
                case 'billingAddress.streetName':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.streetName'];
                    break;
                case 'billingAddress.streetNumber':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.streetNumber'];
                    break;
                case 'billingAddress.city':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.city'];
                    break;
                case 'billingAddress.country':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.country'];
                    break;
                case 'billingAddress.countryA3':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.countryA3'];
                    break;
                case 'billingAddress.postalCode':
                    $prefilledConfiguration[$key] = $paymentData['billingAddress.postalCode'];
                    break;
                case 'billing.consumer.firstName':
                    $prefilledConfiguration[$key] = $paymentData['billing.consumer.firstName'];
                    break;
                case 'customerInfo.firstName':
                    $prefilledConfiguration[$key] = $paymentData['customerInfo.firstName'];
                    break;
                case 'customerInfo.lastName':
                    $prefilledConfiguration[$key] = $paymentData['customerInfo.lastName'];
                    break;
                case 'billing.consumer.lastName':
                    $prefilledConfiguration[$key] = $paymentData['billing.consumer.lastName'];
                    break;
                case 'captureMethod':
                    $prefilledConfiguration[$key] = $paymentData['captureMethod'];
                    break;
                case 'cardHolder.city':
                    $prefilledConfiguration[$key] = $paymentData['cardHolder.city'];
                    break;
                case 'cardHolder.name':
                    $prefilledConfiguration[$key] = $paymentData['cardHolder.name'];
                    break;
                case 'cartId':
                    $prefilledConfiguration[$key] = $paymentData['cartId'];
                    break;
                case 'orderId':
                    $prefilledConfiguration[$key] = $paymentData['orderId'];
                    break;
                case 'orderReference':
                    $prefilledConfiguration[$key] = $paymentData['orderReference'];
                    break;
                case 'paymentId':
                    $prefilledConfiguration[$key] = $paymentData['paymentId'];
                    break;
                case 'paymentMode':
                    $prefilledConfiguration[$key] = $paymentData['paymentMode'];
                    break;
                case 'shipping.address.streetName':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.streetName'];
                    break;
                case 'shipping.address.streetNumber':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.streetNumber'];
                    break;
                case 'shipping.address.city':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.city'];
                    break;
                case 'shipping.address.country':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.country'];
                    break;
                case 'shipping.address.countryA3':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.countryA3'];
                    break;
                case 'shipping.address.postalCode':
                    $prefilledConfiguration[$key] = $paymentData['shipping.address.postalCode'];
                    break;
                case 'shipping.consumer.firstName':
                    $prefilledConfiguration[$key] = $paymentData['shipping.consumer.firstName'];
                    break;
                case 'shipping.consumer.lastName':
                    $prefilledConfiguration[$key] = $paymentData['shipping.consumer.lastName'];
                    break;
                case 'shopName':
                    $prefilledConfiguration[$key] = $paymentData['shopName'];
                    break;
                case 'transId':
                    $prefilledConfiguration[$key] = $paymentData['transId'];
                    break;
                case 'urlCancel':
                    $prefilledConfiguration[$key] = $paymentData['urlCancel'];
                    break;
                case 'urlFailure':
                    $prefilledConfiguration[$key] = $paymentData['urlFailure'];
                    break;
                case 'urlNotify':
                    $prefilledConfiguration[$key] = $paymentData['urlNotify'];
                    break;
                case 'urlWebhook':
                    $prefilledConfiguration[$key] = $paymentData['urlWebhook'];
                    break;
                case 'urlSuccess':
                    $prefilledConfiguration[$key] = $paymentData['urlSuccess'];
                    break;
                case 'urlReturn':
                    $prefilledConfiguration[$key] = $paymentData['urlReturn'];
                    break;
                case 'wirecardConnection.receiver.firstName':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.receiver.firstName'];
                    break;
                case 'wirecardConnection.receiver.lastName':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.receiver.lastName'];
                    break;
                case 'wirecardConnection.refundType':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.refundType'];
                    break;
                case 'wirecardConnection.sender.accountNumber':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.accountNumber'];
                    break;
                case 'wirecardConnection.sender.city':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.city'];
                    break;
                case 'wirecardConnection.sender.country':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.country'];
                    break;
                case 'wirecardConnection.sender.firstName':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.firstName'];
                    break;
                case 'wirecardConnection.sender.lastName':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.lastName'];
                    break;
                case 'wirecardConnection.sender.street':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.street'];
                    break;
                case 'wirecardConnection.sender.streetNumber':
                    $prefilledConfiguration[$key] = $paymentData['wirecardConnection.sender.streetNumber'];
                    break;
                case 'language':
                    $prefilledConfiguration[$key] = $paymentData['language'];
                    break;
                default:
                    $this->logger->critical('Missing configuration key: ' . $key);
            }
        }
        $prefilledConfiguration['externalIntegrationId'] = 'M2_' . $this->getModuleVersion();
        $prefilledConfiguration['statementDescriptor'] = 'Magento 2';

        $prefilledConfiguration['iso2CountryCode'] = $paymentData['iso2CountryCode'];
        $prefilledConfiguration['paymentRenderingMode'] = $paymentData['paymentRenderingMode'];
        $prefilledConfiguration['paysafeCard.accountHolder'] = $paymentData['paysafeCard.accountHolder'];
        $prefilledConfiguration['paysafeCard.customerId'] = $paymentData['paysafeCard.customerId'];
        $prefilledConfiguration['initializeSubscription'] = false;

        $prefilledConfiguration['metadata.userData'] = 'idOrder|' . $idOrder;

        $prefilledConfiguration['saveCard'] = false;

        $prefilledConfiguration['trigram'] = $trigram;

        $prefilledConfiguration['customFields.customField1'] = $paymentData['customFields.customField1'];
        $prefilledConfiguration['customFields.customField2'] = $paymentData['customFields.customField2'];
        $prefilledConfiguration['customFields.customField3'] = $paymentData['customFields.customField3'];
        $prefilledConfiguration['customFields.customField4'] = $paymentData['customFields.customField4'];
        $prefilledConfiguration['customFields.customField5'] = $paymentData['customFields.customField5'];
        $prefilledConfiguration['customFields.customField6'] = $paymentData['customFields.customField6'];
        $prefilledConfiguration['customFields.customField7'] = $paymentData['customFields.customField7'];
        $prefilledConfiguration['customFields.customField8'] = $paymentData['customFields.customField8'];
        $prefilledConfiguration['customFields.customField9'] = $paymentData['customFields.customField9'];
        AxeptaPaygate::init($prefilledConfiguration);

        $operation = [];
        try {
            $operation = AxeptaPaygate::buildOperation();
        } catch (AxeptaPaygateException $e) {
            $this->logger->critical($e);
        }

        $request = $operation['request'];

        $response = [];
        try {
            $response = $request->call();
        } catch (ApiCallException $e) {
            $this->logger->critical($e);
        }

        return $response;
    }

    public function getParamsByTrigram($trigram, $paymentMode = 'REDIRECT')
    {
        $operationType = OperationType::SIMPLE_PAYMENT;
        [$prefilledConfiguration, $missingConfigurationKeys] = AxeptaPaygate::getRequiredConfigurationKeys($trigram, $operationType, $paymentMode);

        return [$prefilledConfiguration, $missingConfigurationKeys];
    }

    public function getToken($merchantId, $apiKey, $paymentMode = "PRODUCTION")
    {
        if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') === 'DEMO') {
            $merchantId = self::DEMO_PUBLIC_KEY;
            $apiKey = self::DEMO_PRIVATE_KEY;
        }

        $tokenData = [];
        try {
            $tokenData = AxeptaPaygate::getAccessToken($merchantId, $apiKey, $paymentMode);
        } catch (ApiCallException $e) {
            $this->logger->critical($e);
        }

        return $tokenData['access_token'];
    }

    public function getPaymentDetails($paymentId, $paymentMode, $merchantId, $apiKey, $paymentType = 'REDIRECT')
    {
        if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') === 'DEMO') {
            $merchantId = self::DEMO_PUBLIC_KEY;
            $apiKey = self::DEMO_PRIVATE_KEY;
        }

        $paymentDetails = [];
        try {
            $configuration['paymentMode'] = $paymentMode;
            $configuration['paymentRenderingMode'] = $paymentType;
            AxeptaPaygate::init($configuration);

            $paymentDetails = AxeptaPaygate::getPaymentDetails($this->getToken($merchantId, $apiKey, $paymentMode), $paymentId);
        } catch (ApiCallException $e) {
            $this->logger->critical($e);
        }

        return $paymentDetails;
    }

    public function capturePayment($merchantId, $apiKey, $paymentId, $paymentMode, $amount, $currency, $country, $transactionId)
    {
        if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') === 'DEMO') {
            $merchantId = self::DEMO_PUBLIC_KEY;
            $apiKey = self::DEMO_PRIVATE_KEY;
        }

        $configuration = [
            'amount.value' => $amount,
            'amount.currency' => $currency,
            'api_access_token' => $this->getToken($merchantId, $apiKey, $paymentMode),
            'iso2CountryCode' => $country,
            'operationType' => OperationType::CAPTURE_PAYMENT,
            'paymentId' => $paymentId,
            'paymentMode' => $paymentMode,
            'transId' => $transactionId,
        ];

        AxeptaPaygate::init($configuration);

        $operation = [];
        try {
            $operation = AxeptaPaygate::buildOperation();
        } catch (AxeptaPaygateException $e) {
            $this->logger->critical($e);
        }

        $request = $operation['request'];

        $response = [];
        try {
            $response = $request->call();
        } catch (ApiCallException $e) {
            $this->logger->critical($e);
        }

        return $response;
    }

    public function refundPayment($merchantId, $apiKey, $paymentId, $paymentMode, $amount, $currency, $country, $transactionId, $trigram, $orderReference, $cartId, $shopName, $name, $city)
    {
        if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') === 'DEMO') {
            $merchantId = self::DEMO_PUBLIC_KEY;
            $apiKey = self::DEMO_PRIVATE_KEY;
        }

        // @TODO Add wirecardConnection
        $configuration = [
            'amount.value' => $amount,
            'amount.currency' => $currency,
            'api_access_token' => $this->getToken($merchantId, $apiKey, $paymentMode),
            'iso2CountryCode' => $country,
            'operationType' => OperationType::PAYMENT_REFUND,
            'paymentId' => $paymentId,
            'paymentMode' => $paymentMode,
            'transId' => $transactionId,
            'trigram' => $trigram,
            'orderReference' => $orderReference,
            'cartId' => $cartId,
            'shopName' => $shopName,
            'cardHolder.name' => $name,
            'cardHolder.city' => $city,
            'wirecardConnection.refundType' => 'P2P',
            'wirecardConnection.receiver.firstName' => 'John',
            'wirecardConnection.receiver.lastName' => 'Doe',
            'wirecardConnection.sender.accountNumber' => '123',
            'wirecardConnection.sender.city' => 'Madrid',
            'wirecardConnection.sender.country' => 'ES',
            'wirecardConnection.sender.firstName' => 'Jane',
            'wirecardConnection.sender.lastName' => 'Doe',
            'wirecardConnection.sender.street' => 'Some street',
            'wirecardConnection.sender.streetNumber' => '123',
        ];

        AxeptaPaygate::init($configuration);

        $operation = [];
        try {
            $operation = AxeptaPaygate::buildOperation();
        } catch (AxeptaPaygateException $e) {
            $this->logger->critical($e);
        }

        $request = $operation['request'];

        $response = [];
        try {
            $response = $request->call();
        } catch (ApiCallException $e) {
            $this->logger->critical($e);
        }

        return $response;
    }

    public function cancelPayment($merchantId, $apiKey, $paymentId, $paymentMode, $amount, $currency, $country, $transactionId, $trigram, $orderReference, $cartId, $shopName, $name, $city)
    {
        if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') === 'DEMO') {
            $merchantId = self::DEMO_PUBLIC_KEY;
            $apiKey = self::DEMO_PRIVATE_KEY;
        }
        
        // @TODO Add wirecardConnection
        $configuration = [
            'amount.value' => $amount,
            'amount.currency' => $currency,
            'api_access_token' => $this->getToken($merchantId, $apiKey, $paymentMode),
            'iso2CountryCode' => $country,
            'operationType' => OperationType::PAYMENT_REVERSAL,
            'paymentId' => $paymentId,
            'paymentMode' => $paymentMode,
            'transId' => $transactionId,
            'trigram' => $trigram,
            'orderReference' => $orderReference,
            'cartId' => $cartId,
            'shopName' => $shopName,
            'cardHolder.name' => $name,
            'cardHolder.city' => $city,
            'wirecardConnection.refundType' => 'P2P',
            'wirecardConnection.receiver.firstName' => 'John',
            'wirecardConnection.receiver.lastName' => 'Doe',
            'wirecardConnection.sender.accountNumber' => '123',
            'wirecardConnection.sender.city' => 'Madrid',
            'wirecardConnection.sender.country' => 'ES',
            'wirecardConnection.sender.firstName' => 'Jane',
            'wirecardConnection.sender.lastName' => 'Doe',
            'wirecardConnection.sender.street' => 'Some street',
            'wirecardConnection.sender.streetNumber' => '123',
        ];

        AxeptaPaygate::init($configuration);

        $operation = [];
        try {
            $operation = AxeptaPaygate::buildOperation();
        } catch (AxeptaPaygateException $e) {
            $this->logger->critical($e);
        }

        $request = $operation['request'];

        $response = [];
        try {
            $response = $request->call();
        } catch (ApiCallException $e) {
            $this->logger->critical($e);
        }

        return $response;
    }

    /**
     * Get module version from composer.json
     *
     * @return string
     */
    private function getModuleVersion(): string
    {
        try {
            $modulePath = $this->componentRegistrar->getPath(
                \Magento\Framework\Component\ComponentRegistrar::MODULE,
                'AxeptaBnpparibas_Online'
            );

            $composerJsonPath = $modulePath . '/composer.json';
            if (file_exists($composerJsonPath)) {
                $composerJsonData = file_get_contents($composerJsonPath);
                $data = $this->json->unserialize($composerJsonData);
                return $data['version'] ?? '1.0.0';
            }
        } catch (\Exception $e) {
            $this->logger->warning('Unable to get module version: ' . $e->getMessage());
        }

        return '1.0.0';
    }

}
