<?php

namespace AxeptaBnpparibas\Online\Model;

use AxeptaBnpparibas\Online\Model\ResourceModel\AxeptaMethod as AxeptaMethodResource;
use Magento\Framework\Model\AbstractModel;

class AxeptaMethod extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(AxeptaMethodResource::class);
    }
}
