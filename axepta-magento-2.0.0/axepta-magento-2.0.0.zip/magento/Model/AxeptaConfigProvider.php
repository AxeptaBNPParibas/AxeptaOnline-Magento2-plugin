<?php

namespace AxeptaBnpparibas\Online\Model;

use AxeptaBnpparibas\Online\Helper\Data;
use Magento\Backend\Model\Url;
use Magento\Checkout\Model\Cart;
use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Framework\View\Asset\Repository;

class AxeptaConfigProvider implements ConfigProviderInterface
{
    protected $url;
    protected $customer;
    protected $cart;
    protected $date;
    protected $assets;
    protected $request;
    protected $scopeConfig;
    protected $axeptaMethodFactory;
    protected $axeptaMethodCountryFactory;
    protected $helperData;

    public function __construct(
        Url $url,
        Session $customer,
        ScopeConfigInterface $scopeConfig,
        Cart $cart,
        DateTime $date,
        Repository $assets,
        RequestInterface $request,
        AxeptaMethodFactory $axeptaMethodFactory,
        AxeptaMethodCountryFactory $axeptaMethodCountryFactory,
        Data $helperData,
    ) {
        $this->url = $url;
        $this->customer = $customer;
        $this->cart = $cart;
        $this->date = $date;
        $this->assets = $assets;
        $this->request = $request;
        $this->scopeConfig = $scopeConfig;
        $this->axeptaMethodFactory = $axeptaMethodFactory;
        $this->axeptaMethodCountryFactory = $axeptaMethodCountryFactory;
        $this->helperData = $helperData;
    }

    public function getConfig($isoCountry = '', $currency = '')
    {
        if (empty($isoCountry) || empty($currency)) {
            return [];
        }

        $params = ['_secure' => $this->request->isSecure()];

        $axeptaMethodCountry = $this->axeptaMethodCountryFactory->create();
        $allowedMethods = $axeptaMethodCountry->getCollection()
            ->addFieldToFilter(
                'currency',
                [['eq' => $currency], ['eq' => 'ALL']]
            )
           ->addFieldToFilter(
               'country',
               [['eq' => $isoCountry], ['eq' => 'ALL']]
           );

        $allowedMethodsAfterCustomerIso = [];
        foreach ($allowedMethods->getData() as $method) {
            $methodDetails = $this->axeptaMethodFactory->create()->load($method['method_id']);
            $grandTotal = $this->cart->getQuote()->getGrandTotal();

            if (!$this->scopeConfig->getValue('payment/axepta_online/conf_payment/payment_list/' . $methodDetails->getCode())) {
                continue;
            }

            $methodToPush = [];
            switch ($methodDetails->getCode()) {
                default:
                    $methodToPush[$method['method_id']]['id'] = $methodDetails->getId();
                    $methodToPush[$method['method_id']]['code'] = $methodDetails->getCode();
                    $methodToPush[$method['method_id']]['libelle'] = $methodDetails->getLibelle();
                    break;
            }
            $allowedMethodsAfterCustomerIso += $methodToPush;
        }

        foreach ($allowedMethodsAfterCustomerIso as &$method) {
            if ($isoCountry != 'FR' && $method['libelle'] == 'CB/VISA/Mastercard') {
                $method['libelle'] = 'VISA/Mastercard';

                if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/show_applepay')) {
                    $method['libelle'] .= '/Apple';
                }

                if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/show_googlepay')) {
                    $method['libelle'] .= '/Google';
                }

            } elseif ($isoCountry == 'FR' && $method['libelle'] == 'CB/VISA/Mastercard') {
                $method['libelle'] = 'CB/VISA/Mastercard';

                if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/show_applepay')) {
                    $method['libelle'] .= '/Apple';
                }

                if ($this->scopeConfig->getValue('payment/axepta_online/conf_account/show_googlepay')) {
                    $method['libelle'] .= '/Google';
                }
            }

            $listImages = explode('/', $method['libelle'] ?? '');
            foreach ($listImages as $img) {
                if ($isoCountry != 'FR' && $listImages == 'CB') {
                    continue;
                }
                $method['images'][] = $this->assets->getUrlWithParams('AxeptaBnpparibas_Online::images/' . preg_replace('/\s+/', '_', strtoupper($img)) . '.png', $params);
            }
        }

        return [
            'axepta' => [
                'methods' => (count($allowedMethodsAfterCustomerIso) > 0) ? $allowedMethodsAfterCustomerIso : false,
                'methodName' => $this->scopeConfig->getValue('payment/axepta_online/conf_payment/libelle_front'),
                'is3dSecureActive' => $this->scopeConfig->getValue('payment/axepta_online/features/3d_secure/activate_3d_secure'),
                'displayMethod' => $this->scopeConfig->getValue('payment/axepta_online/conf_payment/display_mode'),
                'displayMode' => $this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation'),
                'mode' => $this->scopeConfig->getValue('payment/axepta_online/conf_account/mode'),
            ],
        ];
    }
}
