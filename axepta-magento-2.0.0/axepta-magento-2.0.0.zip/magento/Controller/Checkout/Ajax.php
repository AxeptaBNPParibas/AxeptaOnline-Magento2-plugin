<?php

namespace AxeptaBnpparibas\Online\Controller\Checkout;

use AxeptaBnpparibas\Online\Model\AxeptaConfigProvider;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Page;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\Controller\Result\JsonFactory;

class Ajax extends \Magento\Framework\App\Action\Action
{
    /** @var JsonFactory */
    protected $resultJsonFactory;
    private $configProvider;

    /**
     * @param Action\Context $context
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        AxeptaConfigProvider $configProvider,
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->configProvider = $configProvider;

        parent::__construct($context);
    }

    protected function _isAllowed()
    {
        return true;
    }

    /**
     * Execute Ajax.
     *
     * @return Page|Redirect
     *
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
        // Ajax
        $isAjax = $this->getRequest()->getParam('isAjax');
        if ($isAjax == true) {
            $action = $this->getRequest()->getParam('action');
            $resultAction = $this->$action();
            $result = $this->resultJsonFactory->create();

            return $result->setData($resultAction);
        }
    }

    /* AJAX CALL */
    public function getAllowedMethods()
    {
        $isoCountry = $this->getRequest()->getParam('countryId');
        $currency = $this->getRequest()->getParam('currency');
        $allowedMethod = $this->configProvider->getConfig($isoCountry, $currency);

        return $allowedMethod;
    }
}
