<?php

namespace AxeptaBnpparibas\Online\Controller;

use AxeptaBnpparibas\Online\Helper\Data;
use AxeptaBnpparibas\Online\Model\Api\Service;
use AxeptaBnpparibas\Online\Model\TransactionFactory;
use Magento\Checkout\Model\Session;
use Magento\Checkout\Model\Type\Onepage;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Request\Http;
use Magento\Framework\DB\Transaction;
use Magento\Framework\HTTP\PhpEnvironment\RemoteAddress;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderFactory;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;

abstract class Payment extends Action
{
    /** @var Page */
    protected $resultPageFactory;

    /** @var OrderFactory */
    protected $orderFactory;

    protected $quoteRepository;

    /** @var LoggerInterface */
    protected $logger;

    /** @var Session */
    protected $checkoutSession;

    /** @var ManagerInterface */
    protected $messageManager;

    /** @var ScopeConfigInterface */
    protected $scopeConfig;

    /** @var RemoteAddress */
    protected $remoteAddress;

    /** @var Http */
    protected $_request;

    protected $helper;

    protected $transactionFactory;

    protected $orderCollectionFactory;

    protected $transaction;

    protected $orderSender;

    protected $invoiceSender;

    protected $storeManagerInterface;

    protected $service;

    protected $orderResourceModel;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        Session $checkoutSession,
        OrderFactory $orderFactory,
        CollectionFactory $orderCollectionFactory,
        CartRepositoryInterface $quoteRepository,
        ScopeConfigInterface $scopeConfig,
        RemoteAddress $remoteAddress,
        Data $helper,
        TransactionFactory $transactionFactory,
        LoggerInterface $logger,
        Transaction $transaction,
        Order\Email\Sender\OrderSender $orderSender,
        Order\Email\Sender\InvoiceSender $invoiceSender,
        StoreManagerInterface $storeManagerInterface,
        Service $service,
        \Magento\Sales\Model\ResourceModel\Order $orderResourceModel,
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->messageManager = $context->getMessageManager();
        $this->orderFactory = $orderFactory;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->quoteRepository = $quoteRepository;
        $this->checkoutSession = $checkoutSession;
        $this->logger = $logger;
        $this->helper = $helper;
        $this->transactionFactory = $transactionFactory;
        $this->scopeConfig = $scopeConfig;
        $this->remoteAddress = $remoteAddress;
        $this->transaction = $transaction;
        $this->orderSender = $orderSender;
        $this->invoiceSender = $invoiceSender;
        $this->storeManagerInterface = $storeManagerInterface;
        $this->service = $service;
        $this->orderResourceModel = $orderResourceModel;
        parent::__construct($context);
    }

    /**
     * Get Computop API url for payment with encrypted GET parameter.
     */
    protected function getPayment()
    {
        $order = $this->orderFactory->create()->loadByIncrementId($this->checkoutSession->getLastRealOrderId());

        $paymentInfos = $order->getPayment();
        $additionalInformation = $paymentInfos->getAdditionalInformation();

        $trigram = null;
        $type = $this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation');
        if ($this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation') == 'REDIRECT') {
            $trigram = $additionalInformation['axeptaMethodData']['code'];
            
            if ($order->getBillingAddress()->getCountryId() != 'FR' && $trigram == 'CVM') {
                $trigram = "VIM";
            }
        }

        $returnApi = json_decode($this->service->buildOperation(false, $trigram, $this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key'), $additionalInformation, $type, $order->getId()), true);

        // Redirect to payment page avec le result de l'api
        if (isset($returnApi['_links']['redirect']['href'])) {
            return $this->resultRedirectFactory->create()->setUrl($returnApi['_links']['redirect']['href']);
        } elseif (isset($returnApi['paymentId'], $returnApi['status']) 
                && $returnApi['paymentId'] !== '00000000000000000000000000000000' 
                && $returnApi['status'] === 'OK') {
            return $this->apiReturnAction($returnApi['paymentId']);
        } else {
            $this->messageManager->addErrorMessage(__('An error occurred during the payment process. Please try again later.'));
            return $this->cancelAction();
        }
    }

    /**
     * Get checkout session.
     *
     * @return Onepage
     *
     * @codeCoverageIgnore
     */
    public function getCheckout()
    {
        return $this->checkoutSession;
    }

    public function restoreQuoteOrder()
    {
        $session = $this->getCheckout();
        $order = null;

        if ($this->_request->getParam('id')) {
            $order = $this->orderFactory->create()->loadByAttribute('quote_id', $this->_request->getParam('id'));
            $collection = $this->orderCollectionFactory->create()
                ->addAttributeToSelect('*')
                ->addFieldToFilter('quote_id', $this->_request->getParam('id'))
                ->addFieldToFilter('state', 'new')
                ->addFieldToFilter('status', 'pending');
            foreach ($collection as $order) {
                $session->setLastRealOrderId($order->getIncrementId());
            }
        }

        if ($session->getLastRealOrderId()) {
            $order = $this->orderFactory->create()->loadByIncrementId($session->getLastRealOrderId());
            if ($order->getId()) {
                $session->restoreQuote($order);
            }
        }

        return $order;
    }

    public function getOrderByQuote()
    {
        $session = $this->getCheckout();
        $order = null;

        if ($this->_request->getParam('id')) {
            $order = $this->orderFactory->create()->loadByAttribute('quote_id', $this->_request->getParam('id'));
        }

        if ($session->getLastRealOrderId()) {
            $order = $this->orderFactory->create()->loadByIncrementId($session->getLastRealOrderId());
        }

        return $order;
    }

    /**
     * When a customer cancel payment from Axepta.
     */
    public function cancelIframeAction()
    {
        $this->getResponse()->setBody(
            '<script type="text/javascript">' .
                'window.top.location.href="' . $this->_url->getUrl('axepta_online/payment/cancel?id=' . (int) $this->_request->getParam('id')) . '";' .
                '</script>'
        );

        return;
    }

    /**
     * When a customer cancel payment from Axepta.
     */
    public function cancelAction()
    {
        $order = $this->getOrderByQuote();
        $this->restoreQuoteOrder();

        if ($order) {
            $order->addStatusToHistory(
                $order->getStatus(),
                // keep order status/state cancel
                __('The customer cancelled the payment')
            )->cancel()->save();
        }

        return $this->resultRedirectFactory->create()->setPath('checkout/cart');
    }

    /**
     * when Axepta returns via ipn
     * cannot have any output here
     * validate IPN data
     * if data is valid need to update the database that the user has.
     */
    public function ipnAction()
    {
        $this->getResponse()->setBody('OK');
    }

    /**
     * Check axepta response.
     *
     * @return type
     */
    public function apiReturnAction($payId)
    {
        $result = $this->resultRedirectFactory->create();

        $session = $this->getCheckout();
        
        $order = null;

        if ($this->_request->getParam('id')) {
            $order = $this->orderFactory->create()->loadByAttribute('quote_id', $this->_request->getParam('id'));
            $collection = $this->orderCollectionFactory->create()
                ->addAttributeToSelect('*')
                ->addFieldToFilter('quote_id', $this->_request->getParam('id'))
                ->addFieldToFilter('state', 'new')
                ->addFieldToFilter('status', 'pending');
            foreach ($collection as $order) {
                $session->setLastRealOrderId($order->getIncrementId());
            }
        }

        if ($session->getLastRealOrderId()) {
            $order = $this->orderFactory->create()->loadByIncrementId($session->getLastRealOrderId());
            $paymentInformations = $order->getPayment()->getAdditionalInformation();
            $axeptaMethodData = isset($paymentInformations['axeptaMethodData']) ? $paymentInformations['axeptaMethodData'] : [];
            $order->getPayment()->setAdditionalInformation('payId', $payId);
            $this->orderResourceModel->save($order);
        }

        $returnData = [];
        try {
            $returnData = $this->service->getPaymentDetails($payId, $this->scopeConfig->getValue('payment/axepta_online/conf_account/mode') ? strtoupper($this->scopeConfig->getValue('payment/axepta_online/conf_account/mode')) : 'DEMO', $this->scopeConfig->getValue('payment/axepta_online/conf_account/public_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_account/private_key'), $this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation'));
        } catch (\Exception $e) {
            $this->logger->critical($e);
        }

        $paymentType = __('PAYMENT');

        $newTransaction = $this->transactionFactory->create();
        $newTransaction->setData([
            'order_id' => isset($order) ? $order->getId() : '',
            'merchant_id' => array_key_exists('merchantId', $returnData) ? $returnData['merchantId'] : '',
            'transaction_reference' => array_key_exists('transId', $returnData) ? $returnData['transId'] : '',
            'transaction_date' => date('Y-m-d H:i:s'),
            'pay_id' => array_key_exists('payId', $returnData) ? $returnData['payId'] : '',
            'bid' => '',
            'xid' => array_key_exists('xId', $returnData) ? $returnData['xId'] : '',
            'transaction_type' => $paymentType,
            'payment_mean_brand' => array_key_exists('card', $returnData['paymentMethods']) ? $returnData['paymentMethods']['card']['brand'] : '',
            'response_code' => array_key_exists('responseCode', $returnData) ? $returnData['responseCode'] : '',
            'pcnr' => array_key_exists('card', $returnData['paymentMethods']) ? $returnData['paymentMethods']['card']['first6Digits'] : '',
            'ccexpiry' => array_key_exists('card', $returnData['paymentMethods']) ? $returnData['paymentMethods']['card']['expiryDate'] : '',
            'status' => array_key_exists('status', $returnData) ? $returnData['status'] : '',
            'description' => array_key_exists('responseDescription', $returnData) ? $returnData['responseDescription'] : '',
            'amount' => isset($order) ? $order->getBaseGrandTotal() : '',
            'raw_data' => json_encode($returnData),
            'ref_nr' => array_key_exists('refNr', $returnData) ? $returnData['refNr'] : '',
            'scheme_reference_id' => '',
            'holder_name' => array_key_exists('card', $returnData['paymentMethods']) ? $returnData['paymentMethods']['card']['cardHolderName'] : '',
        ]);
        $newTransaction->save();

        $order->getPayment()->setTransactionId($order->getPayment()->getId());
        $order->getPayment()->setLastTransId($order->getPayment()->getId());
        $order->getPayment()->setTransactionAdditionalInfo(
            Order\Payment\Transaction::RAW_DETAILS,
            (array) $newTransaction->getData()
        );
        
        $statusCode = (string) substr($returnData['responseCode'], 0, 1);

        switch ($statusCode) {
            case '0':
                $path = 'checkout/onepage/success';

                $newOrderStatus = Order::STATE_PROCESSING;
                $order->setState(Order::STATE_PROCESSING)
                    ->setStatus($newOrderStatus);
                $order->addStatusHistoryComment(__('Capture mode: %1', $paymentInformations['captureMode']))
                    ->setIsCustomerNotified(false);

                if (!$order->getEmailSent() && $order->getCanSendNewEmailFlag() && $newOrderStatus === Order::STATE_PROCESSING && $paymentInformations['captureMode'] != 'manual') {
                    $invoice = $order->prepareInvoice();
                    $invoice->register()->capture();
                    $this->transaction->addObject($invoice)->addObject($invoice->getOrder())->save();
                    $order->addStatusHistoryComment(__('Invoice #%1 created', $invoice->getIncrementId()))
                        ->setIsCustomerNotified(true);
                    try {
                        $this->orderSender->send($order);
                    } catch (\Exception $e) {
                        $this->logger->critical($e);
                    }
                    try {
                        $this->invoiceSender->send($invoice);
                    } catch (\Exception $e) {
                        $this->logger->critical($e);
                    }
                }

                $order->save();
                break;
            case '2':
            case '4':
                $this->restoreQuoteOrder();
                $path = 'checkout/onepage/failure';

                $cancelOrder = true;

                // Timeout code check list
                $timeoutCodeList = ['0051', '0056', '0368', '0931', '2206', '9040', '110A', '0402', '4005'];
                // Timeout
                if (in_array(substr($returnData['code'], -4), $timeoutCodeList)) {
                    $checkTransaction = $this->transactionFactory->create()
                        ->getCollection()
                        ->addFieldToFilter('order_id', ['eq' => $order->getId()])
                        ->getFirstItem();
                    if (
                        strtoupper($checkTransaction->getTransactionType()) === 'PAIEMENT'
                        && $checkTransaction->getResponseCode() == '00000000'
                    ) {
                        $cancelOrder = false;
                    }
                }

                if ($cancelOrder) {
                    $order->setState(Order::STATE_CANCELED)->setStatus(Order::STATE_CANCELED)->save();
                }
                break;
            case '6':
            default:
                $path = 'checkout/cart';
                $order->setState(Order::STATE_PENDING_PAYMENT)->setStatus(Order::STATE_PENDING_PAYMENT)->save();
                break;
        }

        switch (substr($returnData['responseCode'], -4)) {
            case '0053':
            case '0073':
            case '0723':
            case '0946':
                $path = 'checkout/cart';
                $order = $this->restoreQuoteOrder();
                if ($order) {
                    $order->addStatusToHistory(
                        $order->getStatus(),
                        // keep order status/state cancel
                        __('The customer cancelled the payment')
                    )->cancel()->save();
                }
                break;
            default:
                break;
        }

        switch ($this->scopeConfig->getValue('payment/axepta_online/conf_payment/display_mode')) {
            case 'iframe':
                if ($this->scopeConfig->getValue('payment/axepta_online/conf_payment/organisation') == 'HPP') {
                    $result->setPath($path);

                    return $result;
                }
                if (isset($axeptaMethodData['code'])) {
                    if (in_array($axeptaMethodData['code'], ['FC3', 'FC4'])) {
                        $result->setPath($path);

                        return $result;
                    }
                }
                $this->getResponse()->setBody(
                    '<script type="text/javascript">' .
                        'window.top.location.href="' . $this->_url->getUrl($path, ['_secure' => true]) . '";' .
                        '</script>'
                );

                return;
            default:
                $result->setPath($path);

                return $result;
        }
    }
}
