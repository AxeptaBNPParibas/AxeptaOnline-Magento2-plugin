<?php

namespace AxeptaBnpparibas\Online\Controller\Payment;

use AxeptaBnpparibas\Online\Controller\Payment;
use Magento\Framework\View\Result\PageFactory;

class Directlink extends Payment
{
    /**
     * Redirect to payment page.
     *
     * @return PageFactory
     */
    public function execute()
    {
        return $this->getPayment();
    }
}
