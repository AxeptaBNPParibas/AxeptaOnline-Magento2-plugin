<?php

namespace AxeptaBnpparibas\Online\Controller\Payment;

use AxeptaBnpparibas\Online\Controller\Payment;
use Magento\Framework\View\Result\PageFactory;

class Ipn extends Payment
{
    /**
     * Ipn action.
     *
     * @return PageFactory
     */
    public function execute()
    {
        return $this->ipnAction();
    }
}
