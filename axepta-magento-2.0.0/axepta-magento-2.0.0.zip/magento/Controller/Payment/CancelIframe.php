<?php

namespace AxeptaBnpparibas\Online\Controller\Payment;

use AxeptaBnpparibas\Online\Controller\Payment;
use Magento\Framework\View\Result\PageFactory;

class CancelIframe extends Payment
{
    /**
     * Cancel payment.
     *
     * @return PageFactory
     */
    public function execute()
    {
        return $this->cancelIframeAction();
    }
}
