<?php

namespace AxeptaBnpparibas\Online\Controller\Payment;

use AxeptaBnpparibas\Online\Controller\Payment;
use Magento\Framework\View\Result\PageFactory;

class Success extends Payment
{
    /**
     * Success payment.
     *
     * @return PageFactory
     */
    public function execute()
    {
        $payId = $this->getRequest()->getParam('PayID');

        return $this->apiReturnAction($payId);
    }
}
