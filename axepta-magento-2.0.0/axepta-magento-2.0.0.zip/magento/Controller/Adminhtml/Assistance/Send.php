<?php

namespace AxeptaBnpparibas\Online\Controller\Adminhtml\Assistance;

use Magento\Backend\App\Action;
use Magento\Framework\App\Area;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Module\PackageInfo;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;

class Send extends Action
{
    protected $scopeConfig;
    protected $packageInfos;
    protected $productMetadata;
    protected $transportBuilder;
    protected $logger;
    protected $storeManager;

    public function __construct(
        Action\Context $context,
        ScopeConfigInterface $scopeConfig,
        PackageInfo $packageInfos,
        ProductMetadataInterface $productMetadata,
        TransportBuilder $transportBuilder,
        LoggerInterface $logger,
        StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        $this->scopeConfig = $scopeConfig;
        $this->packageInfos = $packageInfos;
        $this->productMetadata = $productMetadata;
        $this->transportBuilder = $transportBuilder;
        $this->logger = $logger;
        $this->storeManager = $storeManager;
    }

    public function execute()
    {
        $templateId = 'assistance_axepta';
        $fromEmail = $this->scopeConfig->getValue('trans_email/ident_support/email');
        $fromName = $this->scopeConfig->getValue('trans_email/ident_support/name');
        $toEmail = 'assistance.ecommerce@bnpparibas.com';

        try {
            $mid = $this->scopeConfig->getValue(
                'payment/axepta_online/conf_account/public_key',
                ScopeInterface::SCOPE_STORE
            );

            $url = $this->storeManager->getStore()->getBaseUrl();

            $templateVars = [
                'name' => $this->getRequest()->getParam('name'),
                'email' => $this->getRequest()->getParam('email'),
                'description' => $this->getRequest()->getParam('description'),
                'moduleVersion' => $this->packageInfos->getVersion('AxeptaBnpparibas_Online'),
                'versionCms' => $this->productMetadata->getVersion(),
                'versionPhp' => PHP_VERSION,
                'mid' => $mid,
                'url' => $url,
            ];

            $from = ['email' => $fromEmail, 'name' => $fromName];

            $templateOptions = [
                'area' => Area::AREA_ADMINHTML,
                'store' => 1,
            ];

            $transport = $this->transportBuilder
                ->setTemplateIdentifier($templateId)
                ->setTemplateOptions($templateOptions)
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($toEmail)
                ->getTransport();

            $transport->sendMessage();

            $this->messageManager->addSuccessMessage(__('Message sent successfully.'));

            return $this->resultRedirectFactory->create()
                ->setPath('adminhtml/system_config/edit/section/payment/');
        } catch (\Exception $e) {
            $this->logger->error($e->getMessage());
            $this->messageManager->addErrorMessage(__('Message not sent, see logs for details.'));

            return $this->resultRedirectFactory->create()
                ->setPath('adminhtml/system_config/edit/section/payment/');
        }
    }
}
