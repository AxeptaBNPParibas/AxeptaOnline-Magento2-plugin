<?php

namespace AxeptaBnpparibas\Online\Controller\Adminhtml\Transaction;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;

class Index extends Action
{
    public const ADMIN_RESOURCE = 'AxeptaBnpparibas_Online::transaction';

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Index action.
     *
     * @return Page
     */
    public function execute()
    {
        /** @var Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('AxeptaBnpparibas_Online::transaction');
        $resultPage->addBreadcrumb(__('Axepta BNP Paribas'), __('Transactions'));
        $resultPage->getConfig()->getTitle()->prepend(__('Transaction'));

        return $resultPage;
    }
}
