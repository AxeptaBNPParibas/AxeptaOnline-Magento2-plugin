<?php

namespace AxeptaBnpparibas\Online\Controller\Adminhtml\Transaction;

use AxeptaBnpparibas\Online\Model\Transaction;
use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\Page;
use Magento\Framework\Registry;

class View extends Action
{
    protected $model;
    protected $resultPageFactory;

    protected $coreRegistry;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        Transaction $model,
        Registry $registry,
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->model = $model;
        $this->coreRegistry = $registry;
    }

    protected function _isAllowed()
    {
        return true;
    }

    /**
     * Index action.
     *
     * @return Page
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');

        $transaction = $this->model;

        if ($id) {
            $transaction->load($id);
            if (!$transaction->getId()) {
                $this->messageManager->addError(__('This merchant account does not exists.'));
                /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();

                return $resultRedirect->setPath('*/*/');
            }
        }

        $resultPage = $this->_initAction();

        $resultPage->getConfig()->getTitle()->prepend(__('Transaction'));
        $resultPage->getConfig()->getTitle()
            ->prepend(__('Trans ID #%1', $transaction->getTransactionReference()));

        return $resultPage;
    }

    /**
     * Init actions.
     *
     * @return Page
     */
    protected function _initAction()
    {
        // load layout, set active menu and breadcrumbs
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Bnpparibas_Axepta::transaction')
            ->addBreadcrumb(__('Bnp'), __('Bnp'))
            ->addBreadcrumb(__('Transaction'), __('Transaction'));

        return $resultPage;
    }
}
