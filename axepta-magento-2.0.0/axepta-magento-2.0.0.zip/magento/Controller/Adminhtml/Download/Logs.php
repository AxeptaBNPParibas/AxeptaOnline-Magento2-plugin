<?php

namespace AxeptaBnpparibas\Online\Controller\Adminhtml\Download;

use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Backend\App\Action\Context;

class Logs extends \Magento\Backend\App\Action implements HttpGetActionInterface
{
    const ADMIN_RESOURCE = 'AxeptaBnpparibas_Online::config';

    protected $fileFactory;
    protected $directoryList;

    public function __construct(
        Context $context,
        FileFactory $fileFactory,
        DirectoryList $directoryList
    ) {
        parent::__construct($context);
        $this->fileFactory = $fileFactory;
        $this->directoryList = $directoryList;
    }

    public function execute()
    {
        $logFile = $this->directoryList->getPath('log') . '/system.log';

        if (!file_exists($logFile)) {
            $this->messageManager->addErrorMessage(__('No log file found (system.log).'));
            return $this->_redirect($this->_redirect->getRefererUrl());
        }

        $fileName = 'magento_system_log_' . date('Y-m-d_His') . '.log';

        return $this->fileFactory->create(
            $fileName,
            [
                'type'  => 'filename',
                'value' => 'system.log',
                'rm'    => false,
            ],
            DirectoryList::LOG,
            'application/octet-stream'
        );
    }
}
