<?php

namespace AxeptaBnpparibas\Online\Controller\Adminhtml\Download;

class GetFile extends GetChangeLog
{
    protected function getFilePathWithFile()
    {
        return 'app/code/AxeptaBnpparibas/Online/CHANGELOG.md';
    }
}
