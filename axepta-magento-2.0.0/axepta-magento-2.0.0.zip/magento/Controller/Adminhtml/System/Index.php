<?php
namespace AxeptaBnpparibas\Online\Controller\Adminhtml\System;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\RedirectFactory;

class Index extends Action
{
    const ADMIN_RESOURCE = 'Magento_Config::config';

    protected $resultRedirectFactory;

    public function __construct(Context $context, RedirectFactory $resultRedirectFactory)
    {
        parent::__construct($context);
        $this->resultRedirectFactory = $resultRedirectFactory;
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setUrl(
            $this->getUrl('adminhtml/system_config/edit/section/payment') . '#row_payment_fr_axepta_online'
        );
        return $resultRedirect;
    }
}
