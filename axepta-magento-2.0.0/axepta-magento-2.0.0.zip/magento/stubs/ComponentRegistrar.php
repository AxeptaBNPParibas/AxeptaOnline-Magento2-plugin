<?php

namespace Magento\Framework\Component;

class ComponentRegistrar
{
    const MODULE = 'MODULE';
    const LIBRARY = 'LIBRARY';
    const THEME = 'THEME';
    const LANGUAGE = 'LANGUAGE';
    const SETUP = 'SETUP';

    public static function register($componentType, $componentName, $path)
    {
    }
}
