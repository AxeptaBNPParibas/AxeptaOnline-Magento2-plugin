# Changelog

Ce format est une version adaptée de [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) pour We+.
