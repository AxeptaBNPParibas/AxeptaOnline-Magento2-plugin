<?php

use Magento\Framework\Component\ComponentRegistrar;

if (!class_exists('Magento\Framework\Component\ComponentRegistrar')) {
    require_once __DIR__ . '/stubs/ComponentRegistrar.php';
}
ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'AxeptaBnpparibas_Online',
    __DIR__
);
