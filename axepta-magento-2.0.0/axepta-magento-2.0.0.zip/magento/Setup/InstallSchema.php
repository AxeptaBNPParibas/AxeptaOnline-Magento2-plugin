<?php

namespace AxeptaBnpparibas\Online\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface
{
    /**
     * Installs DB schema for a module.
     *
     * @return void
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        // Feature Transactions
        $installer->getConnection()->createTable(
            $installer->getConnection()
                ->newTable($installer->getTable('axepta_online_transaction'))
                ->addColumn('id', Table::TYPE_INTEGER, 11, ['identity' => true, 'nullable' => false, 'primary' => true])
                ->addColumn('order_id', Table::TYPE_INTEGER, 10, ['unsigned' => true, 'nullable' => false, 'index' => true])
                ->addColumn('merchant_id', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('transaction_reference', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('transaction_date', Table::TYPE_DATE, 255, ['default' => null])
                ->addColumn('pay_id', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('bid', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('xid', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('transaction_type', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('payment_mean_brand', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('payment_mean_type', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('response_code', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('pcnr', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('ccexpiry', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('status', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('description', Table::TYPE_TEXT, 255, ['default' => null])
                ->addColumn('amount', Table::TYPE_DECIMAL, [10, 4], ['default' => null])
                ->addColumn('raw_data', Table::TYPE_TEXT, null, ['default' => null])
                ->addColumn('ref_nr', Table::TYPE_TEXT, 32, ['default' => null])
                ->addColumn('scheme_reference_id', Table::TYPE_TEXT, 128, ['default' => null])
                ->addColumn('holder_name', Table::TYPE_TEXT, 128, ['default' => null])
                ->addForeignKey($installer->getFkName('axepta_online_transaction', 'order_id', 'sales_order', 'entity_id'), 'order_id', $installer->getTable('sales_order'), 'entity_id', Table::ACTION_CASCADE)
        );

        $installer->getConnection()->createTable($installer->getConnection()
            ->newTable($installer->getTable('axepta_online_method'))
            ->addColumn('id', Table::TYPE_INTEGER, 11, ['identity' => true, 'nullable' => false, 'primary' => true])
            ->addColumn('code', Table::TYPE_TEXT, 255, ['default' => null])
            ->addColumn('libelle', Table::TYPE_TEXT, 255, ['default' => null]));

        $installer->getConnection()->createTable($installer->getConnection()
            ->newTable($installer->getTable('axepta_online_method_allowed_country'))
            ->addColumn('id', Table::TYPE_INTEGER, 11, ['identity' => true, 'nullable' => false, 'primary' => true])
            ->addColumn('method_id', Table::TYPE_INTEGER, 11, ['nullable' => false])
            ->addColumn('currency', Table::TYPE_TEXT, 255, ['default' => null])
            ->addColumn('country', Table::TYPE_TEXT, 255, ['default' => null]));

        // End Setup
        $installer->endSetup();
    }
}
