<?php

namespace AxeptaBnpparibas\Online\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface
{
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        $dataMethod[] = ['code' => 'CVM', 'libelle' => 'CB/VISA/Mastercard'];
        $dataMethod[] = ['code' => 'AMX', 'libelle' => 'AMEX'];
        $dataMethod[] = ['code' => 'PAL', 'libelle' => 'PAYPAL'];
        $setup->getConnection()->insertArray($setup->getTable('axepta_online_method'), ['code', 'libelle'], $dataMethod);

        $dataMethodCountry[] = ['method_id' => '1', 'currency' => 'ALL', 'country' => 'ALL'];
        $dataMethodCountry[] = ['method_id' => '2', 'currency' => 'ALL', 'country' => 'ALL'];
        $dataMethodCountry[] = ['method_id' => '3', 'currency' => 'ALL', 'country' => 'ALL'];
        $setup->getConnection()->insertArray($setup->getTable('axepta_online_method_allowed_country'), ['method_id', 'currency', 'country'], $dataMethodCountry);
        $setup->endSetup();
    }
}
